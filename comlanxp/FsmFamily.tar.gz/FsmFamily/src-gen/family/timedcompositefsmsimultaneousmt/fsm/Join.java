/**
 */
package family.timedcompositefsmsimultaneousmt.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Join</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see family.timedcompositefsmsimultaneousmt.fsm.FsmPackage#getJoin()
 * @model
 * @generated
 */
public interface Join extends Pseudostate {
} // Join
