/**
 */
package family.timedcompositefsmsimultaneousmt.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Final State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see family.timedcompositefsmsimultaneousmt.fsm.FsmPackage#getFinalState()
 * @model
 * @generated
 */
public interface FinalState extends State {
} // FinalState
