package family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt;

import family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory;
import family.flatfsmsimultaneousmt.fsm.FinalState;
import family.flatfsmsimultaneousmt.fsm.Fork;
import family.flatfsmsimultaneousmt.fsm.FsmFactory;
import family.flatfsmsimultaneousmt.fsm.FsmPackage;
import family.flatfsmsimultaneousmt.fsm.InitialState;
import family.flatfsmsimultaneousmt.fsm.Join;
import family.flatfsmsimultaneousmt.fsm.NamedElement;
import family.flatfsmsimultaneousmt.fsm.Pseudostate;
import family.flatfsmsimultaneousmt.fsm.State;
import family.flatfsmsimultaneousmt.fsm.StateMachine;
import family.flatfsmsimultaneousmt.fsm.TimedTransition;
import family.flatfsmsimultaneousmt.fsm.Transition;
import family.flatfsmsimultaneousmt.fsm.Trigger;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;

@SuppressWarnings("all")
public class FlatFsmSimultaneousMTFactoryAdapter extends EFactoryImpl implements FsmFactory {
  private FlatFsmSimultaneousMTAdaptersFactory adaptersFactory = family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory.getInstance();
  
  private flatfsm.fsm.FsmFactory fsmAdaptee = flatfsm.fsm.FsmFactory.eINSTANCE;
  
  @Override
  public NamedElement createNamedElement() {
    return adaptersFactory.createNamedElementAdapter(fsmAdaptee.createNamedElement(), null) ;
  }
  
  @Override
  public StateMachine createStateMachine() {
    return adaptersFactory.createStateMachineAdapter(fsmAdaptee.createStateMachine(), null) ;
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(fsmAdaptee.createState(), null) ;
  }
  
  @Override
  public FinalState createFinalState() {
    return adaptersFactory.createFinalStateAdapter(fsmAdaptee.createFinalState(), null) ;
  }
  
  @Override
  public InitialState createInitialState() {
    return adaptersFactory.createInitialStateAdapter(fsmAdaptee.createInitialState(), null) ;
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(fsmAdaptee.createTransition(), null) ;
  }
  
  @Override
  public TimedTransition createTimedTransition() {
    return adaptersFactory.createTimedTransitionAdapter(fsmAdaptee.createTimedTransition(), null) ;
  }
  
  @Override
  public Trigger createTrigger() {
    return adaptersFactory.createTriggerAdapter(fsmAdaptee.createTrigger(), null) ;
  }
  
  @Override
  public Pseudostate createPseudostate() {
    return adaptersFactory.createPseudostateAdapter(fsmAdaptee.createPseudostate(), null) ;
  }
  
  @Override
  public Fork createFork() {
    return adaptersFactory.createForkAdapter(fsmAdaptee.createFork(), null) ;
  }
  
  @Override
  public Join createJoin() {
    return adaptersFactory.createJoinAdapter(fsmAdaptee.createJoin(), null) ;
  }
  
  @Override
  public EPackage getEPackage() {
    return getFsmPackage();
  }
  
  public FsmPackage getFsmPackage() {
    return family.flatfsmsimultaneousmt.fsm.FsmPackage.eINSTANCE;
  }
}
