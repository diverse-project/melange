package family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt;

import family.timedcompositefsmmt.fsm.CompositeState;
import family.timedcompositefsmmt.fsm.FinalState;
import family.timedcompositefsmmt.fsm.Fork;
import family.timedcompositefsmmt.fsm.FsmFactory;
import family.timedcompositefsmmt.fsm.FsmPackage;
import family.timedcompositefsmmt.fsm.InitialState;
import family.timedcompositefsmmt.fsm.Join;
import family.timedcompositefsmmt.fsm.NamedElement;
import family.timedcompositefsmmt.fsm.Pseudostate;
import family.timedcompositefsmmt.fsm.Region;
import family.timedcompositefsmmt.fsm.State;
import family.timedcompositefsmmt.fsm.StateMachine;
import family.timedcompositefsmmt.fsm.TimedTransition;
import family.timedcompositefsmmt.fsm.Transition;
import family.timedcompositefsmmt.fsm.Trigger;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedCompositeFsmMTAdaptersFactory;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;

@SuppressWarnings("all")
public class TimedCompositeFsmMTFactoryAdapter extends EFactoryImpl implements FsmFactory {
  private TimedCompositeFsmMTAdaptersFactory adaptersFactory = family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedCompositeFsmMTAdaptersFactory.getInstance();
  
  private timedcompositefsm.fsm.FsmFactory fsmAdaptee = timedcompositefsm.fsm.FsmFactory.eINSTANCE;
  
  @Override
  public NamedElement createNamedElement() {
    return adaptersFactory.createNamedElementAdapter(fsmAdaptee.createNamedElement(), null) ;
  }
  
  @Override
  public StateMachine createStateMachine() {
    return adaptersFactory.createStateMachineAdapter(fsmAdaptee.createStateMachine(), null) ;
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(fsmAdaptee.createState(), null) ;
  }
  
  @Override
  public FinalState createFinalState() {
    return adaptersFactory.createFinalStateAdapter(fsmAdaptee.createFinalState(), null) ;
  }
  
  @Override
  public InitialState createInitialState() {
    return adaptersFactory.createInitialStateAdapter(fsmAdaptee.createInitialState(), null) ;
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(fsmAdaptee.createTransition(), null) ;
  }
  
  @Override
  public TimedTransition createTimedTransition() {
    return adaptersFactory.createTimedTransitionAdapter(fsmAdaptee.createTimedTransition(), null) ;
  }
  
  @Override
  public Trigger createTrigger() {
    return adaptersFactory.createTriggerAdapter(fsmAdaptee.createTrigger(), null) ;
  }
  
  @Override
  public Pseudostate createPseudostate() {
    return adaptersFactory.createPseudostateAdapter(fsmAdaptee.createPseudostate(), null) ;
  }
  
  @Override
  public Fork createFork() {
    return adaptersFactory.createForkAdapter(fsmAdaptee.createFork(), null) ;
  }
  
  @Override
  public Join createJoin() {
    return adaptersFactory.createJoinAdapter(fsmAdaptee.createJoin(), null) ;
  }
  
  @Override
  public CompositeState createCompositeState() {
    return adaptersFactory.createCompositeStateAdapter(fsmAdaptee.createCompositeState(), null) ;
  }
  
  @Override
  public Region createRegion() {
    return adaptersFactory.createRegionAdapter(fsmAdaptee.createRegion(), null) ;
  }
  
  @Override
  public EPackage getEPackage() {
    return getFsmPackage();
  }
  
  public FsmPackage getFsmPackage() {
    return family.timedcompositefsmmt.fsm.FsmPackage.eINSTANCE;
  }
}
