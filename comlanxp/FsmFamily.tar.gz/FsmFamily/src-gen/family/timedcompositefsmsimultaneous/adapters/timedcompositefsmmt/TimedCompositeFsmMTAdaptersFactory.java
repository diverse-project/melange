package family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt;

import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.CompositeStateAdapter;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.FinalStateAdapter;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.ForkAdapter;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.InitialStateAdapter;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.JoinAdapter;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.NamedElementAdapter;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.PseudostateAdapter;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.RegionAdapter;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.StateAdapter;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.StateMachineAdapter;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedTransitionAdapter;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TransitionAdapter;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TriggerAdapter;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.WeakHashMap;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import timedcompositefsm.fsm.CompositeState;
import timedcompositefsm.fsm.FinalState;
import timedcompositefsm.fsm.Fork;
import timedcompositefsm.fsm.InitialState;
import timedcompositefsm.fsm.Join;
import timedcompositefsm.fsm.NamedElement;
import timedcompositefsm.fsm.Pseudostate;
import timedcompositefsm.fsm.Region;
import timedcompositefsm.fsm.State;
import timedcompositefsm.fsm.StateMachine;
import timedcompositefsm.fsm.TimedTransition;
import timedcompositefsm.fsm.Transition;
import timedcompositefsm.fsm.Trigger;

@SuppressWarnings("all")
public class TimedCompositeFsmMTAdaptersFactory implements AdaptersFactory {
  private static TimedCompositeFsmMTAdaptersFactory instance;
  
  private WeakHashMap<EObject, EObjectAdapter> register;
  
  public TimedCompositeFsmMTAdaptersFactory() {
    register = new WeakHashMap();
  }
  
  public static TimedCompositeFsmMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedCompositeFsmMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o, final Resource res) {
    if (o instanceof timedcompositefsm.fsm.StateMachine){
    	return createStateMachineAdapter((timedcompositefsm.fsm.StateMachine) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.FinalState){
    	return createFinalStateAdapter((timedcompositefsm.fsm.FinalState) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.InitialState){
    	return createInitialStateAdapter((timedcompositefsm.fsm.InitialState) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.State){
    	return createStateAdapter((timedcompositefsm.fsm.State) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.TimedTransition){
    	return createTimedTransitionAdapter((timedcompositefsm.fsm.TimedTransition) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Transition){
    	return createTransitionAdapter((timedcompositefsm.fsm.Transition) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Fork){
    	return createForkAdapter((timedcompositefsm.fsm.Fork) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Join){
    	return createJoinAdapter((timedcompositefsm.fsm.Join) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Pseudostate){
    	return createPseudostateAdapter((timedcompositefsm.fsm.Pseudostate) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.NamedElement){
    	return createNamedElementAdapter((timedcompositefsm.fsm.NamedElement) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Trigger){
    	return createTriggerAdapter((timedcompositefsm.fsm.Trigger) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.CompositeState){
    	return createCompositeStateAdapter((timedcompositefsm.fsm.CompositeState) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Region){
    	return createRegionAdapter((timedcompositefsm.fsm.Region) o, res) ;
    }
    
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.NamedElementAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.NamedElementAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.NamedElementAdapter) adapter ;
    }
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.StateMachineAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.StateMachineAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.StateMachineAdapter) adapter ;
    }
  }
  
  public StateAdapter createStateAdapter(final State adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.StateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.StateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.StateAdapter) adapter ;
    }
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.FinalStateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.FinalStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.FinalStateAdapter) adapter ;
    }
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.InitialStateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.InitialStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.InitialStateAdapter) adapter ;
    }
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TransitionAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TransitionAdapter) adapter ;
    }
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedTransitionAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedTransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedTransitionAdapter) adapter ;
    }
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TriggerAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TriggerAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TriggerAdapter) adapter ;
    }
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.PseudostateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.PseudostateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.PseudostateAdapter) adapter ;
    }
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.ForkAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.ForkAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.ForkAdapter) adapter ;
    }
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.JoinAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.JoinAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.JoinAdapter) adapter ;
    }
  }
  
  public CompositeStateAdapter createCompositeStateAdapter(final CompositeState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.CompositeStateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.CompositeStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.CompositeStateAdapter) adapter ;
    }
  }
  
  public RegionAdapter createRegionAdapter(final Region adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.RegionAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.RegionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.RegionAdapter) adapter ;
    }
  }
}
