package family.timedcompositefsmsimultaneous.adapters.timedcompositefsmsimultaneousmt;

import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmsimultaneousmt.TimedCompositeFsmSimultaneousMTAdaptersFactory;
import family.timedcompositefsmsimultaneousmt.fsm.CompositeState;
import family.timedcompositefsmsimultaneousmt.fsm.FinalState;
import family.timedcompositefsmsimultaneousmt.fsm.Fork;
import family.timedcompositefsmsimultaneousmt.fsm.FsmFactory;
import family.timedcompositefsmsimultaneousmt.fsm.FsmPackage;
import family.timedcompositefsmsimultaneousmt.fsm.InitialState;
import family.timedcompositefsmsimultaneousmt.fsm.Join;
import family.timedcompositefsmsimultaneousmt.fsm.NamedElement;
import family.timedcompositefsmsimultaneousmt.fsm.Pseudostate;
import family.timedcompositefsmsimultaneousmt.fsm.Region;
import family.timedcompositefsmsimultaneousmt.fsm.State;
import family.timedcompositefsmsimultaneousmt.fsm.StateMachine;
import family.timedcompositefsmsimultaneousmt.fsm.TimedTransition;
import family.timedcompositefsmsimultaneousmt.fsm.Transition;
import family.timedcompositefsmsimultaneousmt.fsm.Trigger;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;

@SuppressWarnings("all")
public class TimedCompositeFsmSimultaneousMTFactoryAdapter extends EFactoryImpl implements FsmFactory {
  private TimedCompositeFsmSimultaneousMTAdaptersFactory adaptersFactory = family.timedcompositefsmsimultaneous.adapters.timedcompositefsmsimultaneousmt.TimedCompositeFsmSimultaneousMTAdaptersFactory.getInstance();
  
  private timedcompositefsm.fsm.FsmFactory fsmAdaptee = timedcompositefsm.fsm.FsmFactory.eINSTANCE;
  
  @Override
  public NamedElement createNamedElement() {
    return adaptersFactory.createNamedElementAdapter(fsmAdaptee.createNamedElement(), null) ;
  }
  
  @Override
  public StateMachine createStateMachine() {
    return adaptersFactory.createStateMachineAdapter(fsmAdaptee.createStateMachine(), null) ;
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(fsmAdaptee.createState(), null) ;
  }
  
  @Override
  public FinalState createFinalState() {
    return adaptersFactory.createFinalStateAdapter(fsmAdaptee.createFinalState(), null) ;
  }
  
  @Override
  public InitialState createInitialState() {
    return adaptersFactory.createInitialStateAdapter(fsmAdaptee.createInitialState(), null) ;
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(fsmAdaptee.createTransition(), null) ;
  }
  
  @Override
  public TimedTransition createTimedTransition() {
    return adaptersFactory.createTimedTransitionAdapter(fsmAdaptee.createTimedTransition(), null) ;
  }
  
  @Override
  public Trigger createTrigger() {
    return adaptersFactory.createTriggerAdapter(fsmAdaptee.createTrigger(), null) ;
  }
  
  @Override
  public Pseudostate createPseudostate() {
    return adaptersFactory.createPseudostateAdapter(fsmAdaptee.createPseudostate(), null) ;
  }
  
  @Override
  public Fork createFork() {
    return adaptersFactory.createForkAdapter(fsmAdaptee.createFork(), null) ;
  }
  
  @Override
  public Join createJoin() {
    return adaptersFactory.createJoinAdapter(fsmAdaptee.createJoin(), null) ;
  }
  
  @Override
  public CompositeState createCompositeState() {
    return adaptersFactory.createCompositeStateAdapter(fsmAdaptee.createCompositeState(), null) ;
  }
  
  @Override
  public Region createRegion() {
    return adaptersFactory.createRegionAdapter(fsmAdaptee.createRegion(), null) ;
  }
  
  @Override
  public EPackage getEPackage() {
    return getFsmPackage();
  }
  
  public FsmPackage getFsmPackage() {
    return family.timedcompositefsmsimultaneousmt.fsm.FsmPackage.eINSTANCE;
  }
}
