package family.compositefsm.adapters.compositefsmmt;

import compositefsm.fsm.Action;
import compositefsm.fsm.Choice;
import compositefsm.fsm.CompositeState;
import compositefsm.fsm.FinalState;
import compositefsm.fsm.Fork;
import compositefsm.fsm.Guard;
import compositefsm.fsm.InitialState;
import compositefsm.fsm.Join;
import compositefsm.fsm.NamedElement;
import compositefsm.fsm.Pseudostate;
import compositefsm.fsm.Region;
import compositefsm.fsm.State;
import compositefsm.fsm.StateMachine;
import compositefsm.fsm.TimedTransition;
import compositefsm.fsm.Transition;
import compositefsm.fsm.Trigger;
import compositefsm.fsm.Variable;
import family.compositefsm.adapters.compositefsmmt.ActionAdapter;
import family.compositefsm.adapters.compositefsmmt.ChoiceAdapter;
import family.compositefsm.adapters.compositefsmmt.CompositeStateAdapter;
import family.compositefsm.adapters.compositefsmmt.FinalStateAdapter;
import family.compositefsm.adapters.compositefsmmt.ForkAdapter;
import family.compositefsm.adapters.compositefsmmt.GuardAdapter;
import family.compositefsm.adapters.compositefsmmt.InitialStateAdapter;
import family.compositefsm.adapters.compositefsmmt.JoinAdapter;
import family.compositefsm.adapters.compositefsmmt.NamedElementAdapter;
import family.compositefsm.adapters.compositefsmmt.PseudostateAdapter;
import family.compositefsm.adapters.compositefsmmt.RegionAdapter;
import family.compositefsm.adapters.compositefsmmt.StateAdapter;
import family.compositefsm.adapters.compositefsmmt.StateMachineAdapter;
import family.compositefsm.adapters.compositefsmmt.TimedTransitionAdapter;
import family.compositefsm.adapters.compositefsmmt.TransitionAdapter;
import family.compositefsm.adapters.compositefsmmt.TriggerAdapter;
import family.compositefsm.adapters.compositefsmmt.VariableAdapter;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.WeakHashMap;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class CompositeFsmMTAdaptersFactory implements AdaptersFactory {
  private static CompositeFsmMTAdaptersFactory instance;
  
  private WeakHashMap<EObject, EObjectAdapter> register;
  
  public CompositeFsmMTAdaptersFactory() {
    register = new WeakHashMap();
  }
  
  public static CompositeFsmMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new family.compositefsm.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o, final Resource res) {
    if (o instanceof compositefsm.fsm.StateMachine){
    	return createStateMachineAdapter((compositefsm.fsm.StateMachine) o, res) ;
    }
    if (o instanceof compositefsm.fsm.FinalState){
    	return createFinalStateAdapter((compositefsm.fsm.FinalState) o, res) ;
    }
    if (o instanceof compositefsm.fsm.InitialState){
    	return createInitialStateAdapter((compositefsm.fsm.InitialState) o, res) ;
    }
    if (o instanceof compositefsm.fsm.State){
    	return createStateAdapter((compositefsm.fsm.State) o, res) ;
    }
    if (o instanceof compositefsm.fsm.TimedTransition){
    	return createTimedTransitionAdapter((compositefsm.fsm.TimedTransition) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Transition){
    	return createTransitionAdapter((compositefsm.fsm.Transition) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Fork){
    	return createForkAdapter((compositefsm.fsm.Fork) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Join){
    	return createJoinAdapter((compositefsm.fsm.Join) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Pseudostate){
    	return createPseudostateAdapter((compositefsm.fsm.Pseudostate) o, res) ;
    }
    if (o instanceof compositefsm.fsm.NamedElement){
    	return createNamedElementAdapter((compositefsm.fsm.NamedElement) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Trigger){
    	return createTriggerAdapter((compositefsm.fsm.Trigger) o, res) ;
    }
    if (o instanceof compositefsm.fsm.CompositeState){
    	return createCompositeStateAdapter((compositefsm.fsm.CompositeState) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Region){
    	return createRegionAdapter((compositefsm.fsm.Region) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Action){
    	return createActionAdapter((compositefsm.fsm.Action) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Variable){
    	return createVariableAdapter((compositefsm.fsm.Variable) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Choice){
    	return createChoiceAdapter((compositefsm.fsm.Choice) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Guard){
    	return createGuardAdapter((compositefsm.fsm.Guard) o, res) ;
    }
    
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.NamedElementAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.NamedElementAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.NamedElementAdapter) adapter ;
    }
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.StateMachineAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.StateMachineAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.StateMachineAdapter) adapter ;
    }
  }
  
  public StateAdapter createStateAdapter(final State adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.StateAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.StateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.StateAdapter) adapter ;
    }
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.FinalStateAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.FinalStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.FinalStateAdapter) adapter ;
    }
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.InitialStateAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.InitialStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.InitialStateAdapter) adapter ;
    }
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.TransitionAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.TransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.TransitionAdapter) adapter ;
    }
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.TimedTransitionAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.TimedTransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.TimedTransitionAdapter) adapter ;
    }
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.TriggerAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.TriggerAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.TriggerAdapter) adapter ;
    }
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.PseudostateAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.PseudostateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.PseudostateAdapter) adapter ;
    }
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.ForkAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.ForkAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.ForkAdapter) adapter ;
    }
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.JoinAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.JoinAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.JoinAdapter) adapter ;
    }
  }
  
  public CompositeStateAdapter createCompositeStateAdapter(final CompositeState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.CompositeStateAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.CompositeStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.CompositeStateAdapter) adapter ;
    }
  }
  
  public RegionAdapter createRegionAdapter(final Region adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.RegionAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.RegionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.RegionAdapter) adapter ;
    }
  }
  
  public ActionAdapter createActionAdapter(final Action adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.ActionAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.ActionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.ActionAdapter) adapter ;
    }
  }
  
  public VariableAdapter createVariableAdapter(final Variable adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.VariableAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.VariableAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.VariableAdapter) adapter ;
    }
  }
  
  public ChoiceAdapter createChoiceAdapter(final Choice adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.ChoiceAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.ChoiceAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.ChoiceAdapter) adapter ;
    }
  }
  
  public GuardAdapter createGuardAdapter(final Guard adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.compositefsmmt.GuardAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.compositefsmmt.GuardAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.compositefsmmt.GuardAdapter) adapter ;
    }
  }
}
