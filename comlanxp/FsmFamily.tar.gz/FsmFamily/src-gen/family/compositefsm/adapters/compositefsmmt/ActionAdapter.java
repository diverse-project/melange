package family.compositefsm.adapters.compositefsmmt;

import compositefsm.fsm.Action;
import family.compositefsm.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EClass;

@SuppressWarnings("all")
public class ActionAdapter extends EObjectAdapter<Action> implements family.compositefsmmt.fsm.Action {
  private CompositeFsmMTAdaptersFactory adaptersFactory;
  
  public ActionAdapter() {
    super(family.compositefsm.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.compositefsm.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getVariable() {
    return adaptee.getVariable() ;
  }
  
  @Override
  public void setVariable(final String o) {
    adaptee.setVariable(o) ;
  }
  
  @Override
  public boolean isValue() {
    return adaptee.isValue() ;
  }
  
  @Override
  public void setValue(final boolean o) {
    adaptee.setValue(o) ;
  }
  
  protected final static String VARIABLE_EDEFAULT = null;
  
  protected final static boolean VALUE_EDEFAULT = false;
  
  @Override
  public EClass eClass() {
    return family.compositefsmmt.fsm.FsmPackage.eINSTANCE.getAction();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.ACTION__VARIABLE:
    		return getVariable();
    	case family.compositefsmmt.fsm.FsmPackage.ACTION__VALUE:
    		return isValue() ? Boolean.TRUE : Boolean.FALSE;
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.ACTION__VARIABLE:
    		setVariable(VARIABLE_EDEFAULT);
    	case family.compositefsmmt.fsm.FsmPackage.ACTION__VALUE:
    		setValue(VALUE_EDEFAULT);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.ACTION__VARIABLE:
    		return getVariable() != VARIABLE_EDEFAULT;
    	case family.compositefsmmt.fsm.FsmPackage.ACTION__VALUE:
    		return isValue() != VALUE_EDEFAULT;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.ACTION__VARIABLE:
    		setVariable((java.lang.String) newValue);
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.ACTION__VALUE:
    		setValue(((java.lang.Boolean) newValue).booleanValue());
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
