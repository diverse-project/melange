package family.compositefsm.adapters.compositefsmmt;

import family.CompositeFsmMT;
import family.compositefsmmt.fsm.FsmFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;
import org.eclipse.emf.common.util.URI;

@SuppressWarnings("all")
public class CompositeFsmAdapter extends ResourceAdapter implements CompositeFsmMT {
  public CompositeFsmAdapter() {
    super(family.compositefsm.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FsmFactory getFactory() {
    return new family.compositefsm.adapters.compositefsmmt.CompositeFsmMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(URI.createURI(uri));
    this.adaptee.save(null);
  }
}
