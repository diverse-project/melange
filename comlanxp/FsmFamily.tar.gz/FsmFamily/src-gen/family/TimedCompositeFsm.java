package family;

import family.FlatFsmMT;
import family.TimedCompositeFsmMT;
import family.TimedFsmMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;

@SuppressWarnings("all")
public class TimedCompositeFsm implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static TimedCompositeFsm load(final String uri) {
    ResourceSet rs = new ResourceSetImpl() ;
    Resource res = rs.getResource(URI.createURI(uri), true) ;
    TimedCompositeFsm mm = new TimedCompositeFsm() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FlatFsmMT toFlatFsmMT() {
    family.timedcompositefsm.adapters.flatfsmmt.TimedCompositeFsmAdapter adaptee = new family.timedcompositefsm.adapters.flatfsmmt.TimedCompositeFsmAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public TimedFsmMT toTimedFsmMT() {
    family.timedcompositefsm.adapters.timedfsmmt.TimedCompositeFsmAdapter adaptee = new family.timedcompositefsm.adapters.timedfsmmt.TimedCompositeFsmAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public TimedCompositeFsmMT toTimedCompositeFsmMT() {
    family.timedcompositefsm.adapters.timedcompositefsmmt.TimedCompositeFsmAdapter adaptee = new family.timedcompositefsm.adapters.timedcompositefsmmt.TimedCompositeFsmAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
