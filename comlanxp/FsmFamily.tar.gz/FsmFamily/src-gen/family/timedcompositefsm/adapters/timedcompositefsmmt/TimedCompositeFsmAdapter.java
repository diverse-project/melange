package family.timedcompositefsm.adapters.timedcompositefsmmt;

import family.TimedCompositeFsmMT;
import family.timedcompositefsmmt.fsm.FsmFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;
import org.eclipse.emf.common.util.URI;

@SuppressWarnings("all")
public class TimedCompositeFsmAdapter extends ResourceAdapter implements TimedCompositeFsmMT {
  public TimedCompositeFsmAdapter() {
    super(family.timedcompositefsm.adapters.timedcompositefsmmt.TimedCompositeFsmMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FsmFactory getFactory() {
    return new family.timedcompositefsm.adapters.timedcompositefsmmt.TimedCompositeFsmMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(URI.createURI(uri));
    this.adaptee.save(null);
  }
}
