package family.timedcompositefsm.adapters.flatfsmmt;

import family.FlatFsmMT;
import family.flatfsmmt.fsm.FsmFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;
import org.eclipse.emf.common.util.URI;

@SuppressWarnings("all")
public class TimedCompositeFsmAdapter extends ResourceAdapter implements FlatFsmMT {
  public TimedCompositeFsmAdapter() {
    super(family.timedcompositefsm.adapters.flatfsmmt.FlatFsmMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FsmFactory getFactory() {
    return new family.timedcompositefsm.adapters.flatfsmmt.FlatFsmMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(URI.createURI(uri));
    this.adaptee.save(null);
  }
}
