/**
 */
package family.compositefsmmt.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see family.compositefsmmt.fsm.FsmPackage#getInitialState()
 * @model
 * @generated
 */
public interface InitialState extends State {
} // InitialState
