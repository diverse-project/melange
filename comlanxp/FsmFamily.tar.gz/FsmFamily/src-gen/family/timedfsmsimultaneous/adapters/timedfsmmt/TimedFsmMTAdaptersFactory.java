package family.timedfsmsimultaneous.adapters.timedfsmmt;

import family.timedfsmsimultaneous.adapters.timedfsmmt.FinalStateAdapter;
import family.timedfsmsimultaneous.adapters.timedfsmmt.ForkAdapter;
import family.timedfsmsimultaneous.adapters.timedfsmmt.InitialStateAdapter;
import family.timedfsmsimultaneous.adapters.timedfsmmt.JoinAdapter;
import family.timedfsmsimultaneous.adapters.timedfsmmt.NamedElementAdapter;
import family.timedfsmsimultaneous.adapters.timedfsmmt.PseudostateAdapter;
import family.timedfsmsimultaneous.adapters.timedfsmmt.StateAdapter;
import family.timedfsmsimultaneous.adapters.timedfsmmt.StateMachineAdapter;
import family.timedfsmsimultaneous.adapters.timedfsmmt.TimedTransitionAdapter;
import family.timedfsmsimultaneous.adapters.timedfsmmt.TransitionAdapter;
import family.timedfsmsimultaneous.adapters.timedfsmmt.TriggerAdapter;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.WeakHashMap;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import timedfsm.fsm.FinalState;
import timedfsm.fsm.Fork;
import timedfsm.fsm.InitialState;
import timedfsm.fsm.Join;
import timedfsm.fsm.NamedElement;
import timedfsm.fsm.Pseudostate;
import timedfsm.fsm.State;
import timedfsm.fsm.StateMachine;
import timedfsm.fsm.TimedTransition;
import timedfsm.fsm.Transition;
import timedfsm.fsm.Trigger;

@SuppressWarnings("all")
public class TimedFsmMTAdaptersFactory implements AdaptersFactory {
  private static TimedFsmMTAdaptersFactory instance;
  
  private WeakHashMap<EObject, EObjectAdapter> register;
  
  public TimedFsmMTAdaptersFactory() {
    register = new WeakHashMap();
  }
  
  public static TimedFsmMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new family.timedfsmsimultaneous.adapters.timedfsmmt.TimedFsmMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o, final Resource res) {
    if (o instanceof timedfsm.fsm.StateMachine){
    	return createStateMachineAdapter((timedfsm.fsm.StateMachine) o, res) ;
    }
    if (o instanceof timedfsm.fsm.FinalState){
    	return createFinalStateAdapter((timedfsm.fsm.FinalState) o, res) ;
    }
    if (o instanceof timedfsm.fsm.InitialState){
    	return createInitialStateAdapter((timedfsm.fsm.InitialState) o, res) ;
    }
    if (o instanceof timedfsm.fsm.State){
    	return createStateAdapter((timedfsm.fsm.State) o, res) ;
    }
    if (o instanceof timedfsm.fsm.TimedTransition){
    	return createTimedTransitionAdapter((timedfsm.fsm.TimedTransition) o, res) ;
    }
    if (o instanceof timedfsm.fsm.Transition){
    	return createTransitionAdapter((timedfsm.fsm.Transition) o, res) ;
    }
    if (o instanceof timedfsm.fsm.Fork){
    	return createForkAdapter((timedfsm.fsm.Fork) o, res) ;
    }
    if (o instanceof timedfsm.fsm.Join){
    	return createJoinAdapter((timedfsm.fsm.Join) o, res) ;
    }
    if (o instanceof timedfsm.fsm.Pseudostate){
    	return createPseudostateAdapter((timedfsm.fsm.Pseudostate) o, res) ;
    }
    if (o instanceof timedfsm.fsm.NamedElement){
    	return createNamedElementAdapter((timedfsm.fsm.NamedElement) o, res) ;
    }
    if (o instanceof timedfsm.fsm.Trigger){
    	return createTriggerAdapter((timedfsm.fsm.Trigger) o, res) ;
    }
    
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsmsimultaneous.adapters.timedfsmmt.NamedElementAdapter) adapter;
    else {
    	adapter = new family.timedfsmsimultaneous.adapters.timedfsmmt.NamedElementAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsmsimultaneous.adapters.timedfsmmt.NamedElementAdapter) adapter ;
    }
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsmsimultaneous.adapters.timedfsmmt.StateMachineAdapter) adapter;
    else {
    	adapter = new family.timedfsmsimultaneous.adapters.timedfsmmt.StateMachineAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsmsimultaneous.adapters.timedfsmmt.StateMachineAdapter) adapter ;
    }
  }
  
  public StateAdapter createStateAdapter(final State adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsmsimultaneous.adapters.timedfsmmt.StateAdapter) adapter;
    else {
    	adapter = new family.timedfsmsimultaneous.adapters.timedfsmmt.StateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsmsimultaneous.adapters.timedfsmmt.StateAdapter) adapter ;
    }
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsmsimultaneous.adapters.timedfsmmt.FinalStateAdapter) adapter;
    else {
    	adapter = new family.timedfsmsimultaneous.adapters.timedfsmmt.FinalStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsmsimultaneous.adapters.timedfsmmt.FinalStateAdapter) adapter ;
    }
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsmsimultaneous.adapters.timedfsmmt.InitialStateAdapter) adapter;
    else {
    	adapter = new family.timedfsmsimultaneous.adapters.timedfsmmt.InitialStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsmsimultaneous.adapters.timedfsmmt.InitialStateAdapter) adapter ;
    }
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsmsimultaneous.adapters.timedfsmmt.TransitionAdapter) adapter;
    else {
    	adapter = new family.timedfsmsimultaneous.adapters.timedfsmmt.TransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsmsimultaneous.adapters.timedfsmmt.TransitionAdapter) adapter ;
    }
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsmsimultaneous.adapters.timedfsmmt.TimedTransitionAdapter) adapter;
    else {
    	adapter = new family.timedfsmsimultaneous.adapters.timedfsmmt.TimedTransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsmsimultaneous.adapters.timedfsmmt.TimedTransitionAdapter) adapter ;
    }
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsmsimultaneous.adapters.timedfsmmt.TriggerAdapter) adapter;
    else {
    	adapter = new family.timedfsmsimultaneous.adapters.timedfsmmt.TriggerAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsmsimultaneous.adapters.timedfsmmt.TriggerAdapter) adapter ;
    }
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsmsimultaneous.adapters.timedfsmmt.PseudostateAdapter) adapter;
    else {
    	adapter = new family.timedfsmsimultaneous.adapters.timedfsmmt.PseudostateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsmsimultaneous.adapters.timedfsmmt.PseudostateAdapter) adapter ;
    }
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsmsimultaneous.adapters.timedfsmmt.ForkAdapter) adapter;
    else {
    	adapter = new family.timedfsmsimultaneous.adapters.timedfsmmt.ForkAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsmsimultaneous.adapters.timedfsmmt.ForkAdapter) adapter ;
    }
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsmsimultaneous.adapters.timedfsmmt.JoinAdapter) adapter;
    else {
    	adapter = new family.timedfsmsimultaneous.adapters.timedfsmmt.JoinAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsmsimultaneous.adapters.timedfsmmt.JoinAdapter) adapter ;
    }
  }
}
