package family.timedfsmsimultaneous.adapters.flatfsmsimultaneousmt;

import family.flatfsmsimultaneousmt.fsm.State;
import family.flatfsmsimultaneousmt.fsm.Transition;
import family.timedfsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.Collection;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import semantics.common.Context;
import timedfsm.fsm.StateMachine;

@SuppressWarnings("all")
public class StateMachineAdapter extends EObjectAdapter<StateMachine> implements family.flatfsmsimultaneousmt.fsm.StateMachine {
  private FlatFsmSimultaneousMTAdaptersFactory adaptersFactory;
  
  public StateMachineAdapter() {
    super(family.timedfsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.timedfsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  private EList<State> states;
  
  @Override
  public EList<State> getStates() {
    if (states == null)
    	states = fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), adaptersFactory) ;
    return states;
  }
  
  private EList<Transition> transitions;
  
  @Override
  public EList<Transition> getTransitions() {
    if (transitions == null)
    	transitions = fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getTransitions(), adaptersFactory) ;
    return transitions;
  }
  
  @Override
  public void eval(final Context context, final String filePath) {
    semantics.timed.simultaneous.StateMachineAspect.eval(adaptee, context
    , filePath
    ) ;
  }
  
  @Override
  public void step(final Context context, final org.eclipse.emf.common.util.EList<java.lang.String> eventsGroup) {
    semantics.timed.simultaneous.StateMachineAspect.step(adaptee, context
    , eventsGroup
    ) ;
  }
  
  @Override
  public void removeCurrentStates(final EList<State> statesToRemove) {
    semantics.timed.simultaneous.StateMachineAspect.removeCurrentStates(adaptee, ((fr.inria.diverse.melange.adapters.EListAdapter) statesToRemove).getAdaptee()
    ) ;
  }
  
  @Override
  public void addCurrentStates(final EList<State> statesToAdd) {
    semantics.timed.simultaneous.StateMachineAspect.addCurrentStates(adaptee, ((fr.inria.diverse.melange.adapters.EListAdapter) statesToAdd).getAdaptee()
    ) ;
  }
  
  @Override
  public EList<State> getCurrentState() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(semantics.timed.simultaneous.StateMachineAspect.currentState(adaptee), adaptersFactory) ;
  }
  
  protected final static String NAME_EDEFAULT = null;
  
  @Override
  public EClass eClass() {
    return family.flatfsmsimultaneousmt.fsm.FsmPackage.eINSTANCE.getStateMachine();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__NAME:
    		return getName();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__STATES:
    		return getStates();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__TRANSITIONS:
    		return getTransitions();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__CURRENT_STATE:
    		return getCurrentState();
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__NAME:
    		setName(NAME_EDEFAULT);
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__STATES:
    		getStates().clear();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__TRANSITIONS:
    		getTransitions().clear();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__CURRENT_STATE:
    		getCurrentState().clear();
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__NAME:
    		return getName() != NAME_EDEFAULT;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__STATES:
    		return getStates() != null && !getStates().isEmpty();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__TRANSITIONS:
    		return getTransitions() != null && !getTransitions().isEmpty();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__CURRENT_STATE:
    		return getCurrentState() != null && !getCurrentState().isEmpty();
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__NAME:
    		setName((java.lang.String) newValue);
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__STATES:
    		getStates().clear();
    		getStates().addAll((Collection) newValue);
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__TRANSITIONS:
    		getTransitions().clear();
    		getTransitions().addAll((Collection) newValue);
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE_MACHINE__CURRENT_STATE:
    		getCurrentState().clear();
    		getCurrentState().addAll((Collection) newValue);
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
