package family.flatfsm.adapters.flatfsmmt;

import family.flatfsm.adapters.flatfsmmt.FlatFsmMTAdaptersFactory;
import flatfsm.fsm.Trigger;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EClass;

@SuppressWarnings("all")
public class TriggerAdapter extends EObjectAdapter<Trigger> implements family.flatfsmmt.fsm.Trigger {
  private FlatFsmMTAdaptersFactory adaptersFactory;
  
  public TriggerAdapter() {
    super(family.flatfsm.adapters.flatfsmmt.FlatFsmMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.flatfsm.adapters.flatfsmmt.FlatFsmMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
  
  protected final static String EXPRESSION_EDEFAULT = null;
  
  @Override
  public EClass eClass() {
    return family.flatfsmmt.fsm.FsmPackage.eINSTANCE.getTrigger();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.flatfsmmt.fsm.FsmPackage.TRIGGER__EXPRESSION:
    		return getExpression();
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.flatfsmmt.fsm.FsmPackage.TRIGGER__EXPRESSION:
    		setExpression(EXPRESSION_EDEFAULT);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.flatfsmmt.fsm.FsmPackage.TRIGGER__EXPRESSION:
    		return getExpression() != EXPRESSION_EDEFAULT;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.flatfsmmt.fsm.FsmPackage.TRIGGER__EXPRESSION:
    		setExpression((java.lang.String) newValue);
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
