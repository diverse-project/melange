package family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt;

import compositefsm.fsm.FinalState;
import compositefsm.fsm.Fork;
import compositefsm.fsm.InitialState;
import compositefsm.fsm.Join;
import compositefsm.fsm.NamedElement;
import compositefsm.fsm.Pseudostate;
import compositefsm.fsm.State;
import compositefsm.fsm.StateMachine;
import compositefsm.fsm.TimedTransition;
import compositefsm.fsm.Transition;
import compositefsm.fsm.Trigger;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.FinalStateAdapter;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.ForkAdapter;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.InitialStateAdapter;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.JoinAdapter;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.NamedElementAdapter;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.PseudostateAdapter;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.StateAdapter;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.StateMachineAdapter;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedTransitionAdapter;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TransitionAdapter;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TriggerAdapter;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.WeakHashMap;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FlatFsmSimultaneousMTAdaptersFactory implements AdaptersFactory {
  private static FlatFsmSimultaneousMTAdaptersFactory instance;
  
  private WeakHashMap<EObject, EObjectAdapter> register;
  
  public FlatFsmSimultaneousMTAdaptersFactory() {
    register = new WeakHashMap();
  }
  
  public static FlatFsmSimultaneousMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o, final Resource res) {
    if (o instanceof compositefsm.fsm.StateMachine){
    	return createStateMachineAdapter((compositefsm.fsm.StateMachine) o, res) ;
    }
    if (o instanceof compositefsm.fsm.FinalState){
    	return createFinalStateAdapter((compositefsm.fsm.FinalState) o, res) ;
    }
    if (o instanceof compositefsm.fsm.InitialState){
    	return createInitialStateAdapter((compositefsm.fsm.InitialState) o, res) ;
    }
    if (o instanceof compositefsm.fsm.State){
    	return createStateAdapter((compositefsm.fsm.State) o, res) ;
    }
    if (o instanceof compositefsm.fsm.TimedTransition){
    	return createTimedTransitionAdapter((compositefsm.fsm.TimedTransition) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Transition){
    	return createTransitionAdapter((compositefsm.fsm.Transition) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Fork){
    	return createForkAdapter((compositefsm.fsm.Fork) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Join){
    	return createJoinAdapter((compositefsm.fsm.Join) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Pseudostate){
    	return createPseudostateAdapter((compositefsm.fsm.Pseudostate) o, res) ;
    }
    if (o instanceof compositefsm.fsm.NamedElement){
    	return createNamedElementAdapter((compositefsm.fsm.NamedElement) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Trigger){
    	return createTriggerAdapter((compositefsm.fsm.Trigger) o, res) ;
    }
    
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.NamedElementAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.NamedElementAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.NamedElementAdapter) adapter ;
    }
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.StateMachineAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.StateMachineAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.StateMachineAdapter) adapter ;
    }
  }
  
  public StateAdapter createStateAdapter(final State adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.StateAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.StateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.StateAdapter) adapter ;
    }
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.FinalStateAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.FinalStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.FinalStateAdapter) adapter ;
    }
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.InitialStateAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.InitialStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.InitialStateAdapter) adapter ;
    }
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TransitionAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TransitionAdapter) adapter ;
    }
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedTransitionAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedTransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedTransitionAdapter) adapter ;
    }
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TriggerAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TriggerAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TriggerAdapter) adapter ;
    }
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.PseudostateAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.PseudostateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.PseudostateAdapter) adapter ;
    }
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.ForkAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.ForkAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.ForkAdapter) adapter ;
    }
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.JoinAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.JoinAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.JoinAdapter) adapter ;
    }
  }
}
