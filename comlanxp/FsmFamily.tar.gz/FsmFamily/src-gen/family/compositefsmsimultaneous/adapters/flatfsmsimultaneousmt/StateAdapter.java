package family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt;

import compositefsm.fsm.State;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory;
import family.flatfsmsimultaneousmt.fsm.StateMachine;
import family.flatfsmsimultaneousmt.fsm.Transition;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.Collection;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import semantics.common.Context;

@SuppressWarnings("all")
public class StateAdapter extends EObjectAdapter<State> implements family.flatfsmsimultaneousmt.fsm.State {
  private FlatFsmSimultaneousMTAdaptersFactory adaptersFactory;
  
  public StateAdapter() {
    super(family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  private EList<Transition> outgoing;
  
  @Override
  public EList<Transition> getOutgoing() {
    if (outgoing == null)
    	outgoing = fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getOutgoing(), adaptersFactory) ;
    return outgoing;
  }
  
  private EList<Transition> incoming;
  
  @Override
  public EList<Transition> getIncoming() {
    if (incoming == null)
    	incoming = fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getIncoming(), adaptersFactory) ;
    return incoming;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return (StateMachine) adaptersFactory.createAdapter(adaptee.getStateMachine(), eResource) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    if (o != null)
    	adaptee.setStateMachine(((family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.StateMachineAdapter) o).getAdaptee()) ;
    else adaptee.setStateMachine(null) ;
  }
  
  @Override
  public void eval(final Context context) {
    semantics.composite.simultaneous.StateAspect.eval(adaptee, context
    ) ;
  }
  
  protected final static String NAME_EDEFAULT = null;
  
  protected final static int INITIAL_TIME_EDEFAULT = 0;
  
  protected final static int FINAL_TIME_EDEFAULT = 0;
  
  @Override
  public EClass eClass() {
    return family.flatfsmsimultaneousmt.fsm.FsmPackage.eINSTANCE.getState();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__NAME:
    		return getName();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__OUTGOING:
    		return getOutgoing();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__INCOMING:
    		return getIncoming();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__STATE_MACHINE:
    		return getStateMachine();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__INITIAL_TIME:
    		return new java.lang.Integer(getInitialTime());
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__FINAL_TIME:
    		return new java.lang.Integer(getFinalTime());
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__NAME:
    		setName(NAME_EDEFAULT);
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__OUTGOING:
    		getOutgoing().clear();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__INCOMING:
    		getIncoming().clear();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__STATE_MACHINE:
    		setStateMachine((family.flatfsmsimultaneousmt.fsm.StateMachine) null);
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__INITIAL_TIME:
    		setInitialTime(INITIAL_TIME_EDEFAULT);
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__FINAL_TIME:
    		setFinalTime(FINAL_TIME_EDEFAULT);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__NAME:
    		return getName() != NAME_EDEFAULT;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__OUTGOING:
    		return getOutgoing() != null && !getOutgoing().isEmpty();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__INCOMING:
    		return getIncoming() != null && !getIncoming().isEmpty();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__STATE_MACHINE:
    		return getStateMachine() != null;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__INITIAL_TIME:
    		return getInitialTime() != INITIAL_TIME_EDEFAULT;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__FINAL_TIME:
    		return getFinalTime() != FINAL_TIME_EDEFAULT;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__NAME:
    		setName((java.lang.String) newValue);
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__OUTGOING:
    		getOutgoing().clear();
    		getOutgoing().addAll((Collection) newValue);
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__INCOMING:
    		getIncoming().clear();
    		getIncoming().addAll((Collection) newValue);
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__STATE_MACHINE:
    		setStateMachine((family.flatfsmsimultaneousmt.fsm.StateMachine) newValue);
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__INITIAL_TIME:
    		setInitialTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.STATE__FINAL_TIME:
    		setFinalTime(((java.lang.Integer) newValue).intValue());
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
