package family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt;

import compositefsm.fsm.Variable;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeFsmSimultaneousMTAdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EClass;

@SuppressWarnings("all")
public class VariableAdapter extends EObjectAdapter<Variable> implements family.compositefsmsimultaneousmt.fsm.Variable {
  private CompositeFsmSimultaneousMTAdaptersFactory adaptersFactory;
  
  public VariableAdapter() {
    super(family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeFsmSimultaneousMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeFsmSimultaneousMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public boolean isValue() {
    return adaptee.isValue() ;
  }
  
  @Override
  public void setValue(final boolean o) {
    adaptee.setValue(o) ;
  }
  
  protected final static String NAME_EDEFAULT = null;
  
  protected final static boolean VALUE_EDEFAULT = false;
  
  @Override
  public EClass eClass() {
    return family.compositefsmsimultaneousmt.fsm.FsmPackage.eINSTANCE.getVariable();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.VARIABLE__NAME:
    		return getName();
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.VARIABLE__VALUE:
    		return isValue() ? Boolean.TRUE : Boolean.FALSE;
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.VARIABLE__NAME:
    		setName(NAME_EDEFAULT);
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.VARIABLE__VALUE:
    		setValue(VALUE_EDEFAULT);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.VARIABLE__NAME:
    		return getName() != NAME_EDEFAULT;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.VARIABLE__VALUE:
    		return isValue() != VALUE_EDEFAULT;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.VARIABLE__NAME:
    		setName((java.lang.String) newValue);
    		return;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.VARIABLE__VALUE:
    		setValue(((java.lang.Boolean) newValue).booleanValue());
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
