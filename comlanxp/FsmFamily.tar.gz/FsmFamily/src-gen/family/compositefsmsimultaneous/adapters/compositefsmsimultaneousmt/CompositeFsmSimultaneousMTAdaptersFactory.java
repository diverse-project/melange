package family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt;

import compositefsm.fsm.Action;
import compositefsm.fsm.Choice;
import compositefsm.fsm.CompositeState;
import compositefsm.fsm.FinalState;
import compositefsm.fsm.Fork;
import compositefsm.fsm.Guard;
import compositefsm.fsm.InitialState;
import compositefsm.fsm.Join;
import compositefsm.fsm.NamedElement;
import compositefsm.fsm.Pseudostate;
import compositefsm.fsm.Region;
import compositefsm.fsm.State;
import compositefsm.fsm.StateMachine;
import compositefsm.fsm.TimedTransition;
import compositefsm.fsm.Transition;
import compositefsm.fsm.Trigger;
import compositefsm.fsm.Variable;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ActionAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ChoiceAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeStateAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.FinalStateAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ForkAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.GuardAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.InitialStateAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.JoinAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.NamedElementAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.PseudostateAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.RegionAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.StateAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.StateMachineAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TimedTransitionAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TransitionAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TriggerAdapter;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.VariableAdapter;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.WeakHashMap;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class CompositeFsmSimultaneousMTAdaptersFactory implements AdaptersFactory {
  private static CompositeFsmSimultaneousMTAdaptersFactory instance;
  
  private WeakHashMap<EObject, EObjectAdapter> register;
  
  public CompositeFsmSimultaneousMTAdaptersFactory() {
    register = new WeakHashMap();
  }
  
  public static CompositeFsmSimultaneousMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeFsmSimultaneousMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o, final Resource res) {
    if (o instanceof compositefsm.fsm.StateMachine){
    	return createStateMachineAdapter((compositefsm.fsm.StateMachine) o, res) ;
    }
    if (o instanceof compositefsm.fsm.FinalState){
    	return createFinalStateAdapter((compositefsm.fsm.FinalState) o, res) ;
    }
    if (o instanceof compositefsm.fsm.InitialState){
    	return createInitialStateAdapter((compositefsm.fsm.InitialState) o, res) ;
    }
    if (o instanceof compositefsm.fsm.State){
    	return createStateAdapter((compositefsm.fsm.State) o, res) ;
    }
    if (o instanceof compositefsm.fsm.TimedTransition){
    	return createTimedTransitionAdapter((compositefsm.fsm.TimedTransition) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Transition){
    	return createTransitionAdapter((compositefsm.fsm.Transition) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Fork){
    	return createForkAdapter((compositefsm.fsm.Fork) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Join){
    	return createJoinAdapter((compositefsm.fsm.Join) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Pseudostate){
    	return createPseudostateAdapter((compositefsm.fsm.Pseudostate) o, res) ;
    }
    if (o instanceof compositefsm.fsm.NamedElement){
    	return createNamedElementAdapter((compositefsm.fsm.NamedElement) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Trigger){
    	return createTriggerAdapter((compositefsm.fsm.Trigger) o, res) ;
    }
    if (o instanceof compositefsm.fsm.CompositeState){
    	return createCompositeStateAdapter((compositefsm.fsm.CompositeState) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Region){
    	return createRegionAdapter((compositefsm.fsm.Region) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Action){
    	return createActionAdapter((compositefsm.fsm.Action) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Variable){
    	return createVariableAdapter((compositefsm.fsm.Variable) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Choice){
    	return createChoiceAdapter((compositefsm.fsm.Choice) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Guard){
    	return createGuardAdapter((compositefsm.fsm.Guard) o, res) ;
    }
    
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.NamedElementAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.NamedElementAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.NamedElementAdapter) adapter ;
    }
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.StateMachineAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.StateMachineAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.StateMachineAdapter) adapter ;
    }
  }
  
  public StateAdapter createStateAdapter(final State adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.StateAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.StateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.StateAdapter) adapter ;
    }
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.FinalStateAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.FinalStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.FinalStateAdapter) adapter ;
    }
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.InitialStateAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.InitialStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.InitialStateAdapter) adapter ;
    }
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TransitionAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TransitionAdapter) adapter ;
    }
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TimedTransitionAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TimedTransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TimedTransitionAdapter) adapter ;
    }
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TriggerAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TriggerAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TriggerAdapter) adapter ;
    }
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.PseudostateAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.PseudostateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.PseudostateAdapter) adapter ;
    }
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ForkAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ForkAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ForkAdapter) adapter ;
    }
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.JoinAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.JoinAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.JoinAdapter) adapter ;
    }
  }
  
  public CompositeStateAdapter createCompositeStateAdapter(final CompositeState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeStateAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeStateAdapter) adapter ;
    }
  }
  
  public RegionAdapter createRegionAdapter(final Region adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.RegionAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.RegionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.RegionAdapter) adapter ;
    }
  }
  
  public ActionAdapter createActionAdapter(final Action adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ActionAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ActionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ActionAdapter) adapter ;
    }
  }
  
  public VariableAdapter createVariableAdapter(final Variable adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.VariableAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.VariableAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.VariableAdapter) adapter ;
    }
  }
  
  public ChoiceAdapter createChoiceAdapter(final Choice adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ChoiceAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ChoiceAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ChoiceAdapter) adapter ;
    }
  }
  
  public GuardAdapter createGuardAdapter(final Guard adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.GuardAdapter) adapter;
    else {
    	adapter = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.GuardAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.GuardAdapter) adapter ;
    }
  }
}
