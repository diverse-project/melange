package family.compositefsmsimultaneous.adapters.compositefsmmt;

import family.CompositeFsmMT;
import family.compositefsmmt.fsm.FsmFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;
import org.eclipse.emf.common.util.URI;

@SuppressWarnings("all")
public class CompositeFsmSimultaneousAdapter extends ResourceAdapter implements CompositeFsmMT {
  public CompositeFsmSimultaneousAdapter() {
    super(family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FsmFactory getFactory() {
    return new family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(URI.createURI(uri));
    this.adaptee.save(null);
  }
}
