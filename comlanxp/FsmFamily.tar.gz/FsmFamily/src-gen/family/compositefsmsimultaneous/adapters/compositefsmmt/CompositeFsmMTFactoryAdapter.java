package family.compositefsmsimultaneous.adapters.compositefsmmt;

import family.compositefsmmt.fsm.Action;
import family.compositefsmmt.fsm.Choice;
import family.compositefsmmt.fsm.CompositeState;
import family.compositefsmmt.fsm.FinalState;
import family.compositefsmmt.fsm.Fork;
import family.compositefsmmt.fsm.FsmFactory;
import family.compositefsmmt.fsm.FsmPackage;
import family.compositefsmmt.fsm.Guard;
import family.compositefsmmt.fsm.InitialState;
import family.compositefsmmt.fsm.Join;
import family.compositefsmmt.fsm.NamedElement;
import family.compositefsmmt.fsm.Pseudostate;
import family.compositefsmmt.fsm.Region;
import family.compositefsmmt.fsm.State;
import family.compositefsmmt.fsm.StateMachine;
import family.compositefsmmt.fsm.TimedTransition;
import family.compositefsmmt.fsm.Transition;
import family.compositefsmmt.fsm.Trigger;
import family.compositefsmmt.fsm.Variable;
import family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;

@SuppressWarnings("all")
public class CompositeFsmMTFactoryAdapter extends EFactoryImpl implements FsmFactory {
  private CompositeFsmMTAdaptersFactory adaptersFactory = family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance();
  
  private compositefsm.fsm.FsmFactory fsmAdaptee = compositefsm.fsm.FsmFactory.eINSTANCE;
  
  @Override
  public NamedElement createNamedElement() {
    return adaptersFactory.createNamedElementAdapter(fsmAdaptee.createNamedElement(), null) ;
  }
  
  @Override
  public StateMachine createStateMachine() {
    return adaptersFactory.createStateMachineAdapter(fsmAdaptee.createStateMachine(), null) ;
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(fsmAdaptee.createState(), null) ;
  }
  
  @Override
  public FinalState createFinalState() {
    return adaptersFactory.createFinalStateAdapter(fsmAdaptee.createFinalState(), null) ;
  }
  
  @Override
  public InitialState createInitialState() {
    return adaptersFactory.createInitialStateAdapter(fsmAdaptee.createInitialState(), null) ;
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(fsmAdaptee.createTransition(), null) ;
  }
  
  @Override
  public TimedTransition createTimedTransition() {
    return adaptersFactory.createTimedTransitionAdapter(fsmAdaptee.createTimedTransition(), null) ;
  }
  
  @Override
  public Trigger createTrigger() {
    return adaptersFactory.createTriggerAdapter(fsmAdaptee.createTrigger(), null) ;
  }
  
  @Override
  public Pseudostate createPseudostate() {
    return adaptersFactory.createPseudostateAdapter(fsmAdaptee.createPseudostate(), null) ;
  }
  
  @Override
  public Fork createFork() {
    return adaptersFactory.createForkAdapter(fsmAdaptee.createFork(), null) ;
  }
  
  @Override
  public Join createJoin() {
    return adaptersFactory.createJoinAdapter(fsmAdaptee.createJoin(), null) ;
  }
  
  @Override
  public CompositeState createCompositeState() {
    return adaptersFactory.createCompositeStateAdapter(fsmAdaptee.createCompositeState(), null) ;
  }
  
  @Override
  public Region createRegion() {
    return adaptersFactory.createRegionAdapter(fsmAdaptee.createRegion(), null) ;
  }
  
  @Override
  public Action createAction() {
    return adaptersFactory.createActionAdapter(fsmAdaptee.createAction(), null) ;
  }
  
  @Override
  public Variable createVariable() {
    return adaptersFactory.createVariableAdapter(fsmAdaptee.createVariable(), null) ;
  }
  
  @Override
  public Choice createChoice() {
    return adaptersFactory.createChoiceAdapter(fsmAdaptee.createChoice(), null) ;
  }
  
  @Override
  public Guard createGuard() {
    return adaptersFactory.createGuardAdapter(fsmAdaptee.createGuard(), null) ;
  }
  
  @Override
  public EPackage getEPackage() {
    return getFsmPackage();
  }
  
  public FsmPackage getFsmPackage() {
    return family.compositefsmmt.fsm.FsmPackage.eINSTANCE;
  }
}
