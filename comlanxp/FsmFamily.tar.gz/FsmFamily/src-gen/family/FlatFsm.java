package family;

import family.FlatFsmMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;

@SuppressWarnings("all")
public class FlatFsm implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static FlatFsm load(final String uri) {
    ResourceSet rs = new ResourceSetImpl() ;
    Resource res = rs.getResource(URI.createURI(uri), true) ;
    FlatFsm mm = new FlatFsm() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FlatFsmMT toFlatFsmMT() {
    family.flatfsm.adapters.flatfsmmt.FlatFsmAdapter adaptee = new family.flatfsm.adapters.flatfsmmt.FlatFsmAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
