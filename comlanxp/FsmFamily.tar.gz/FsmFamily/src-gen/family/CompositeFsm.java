package family;

import family.CompositeFsmMT;
import family.FlatFsmMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;

@SuppressWarnings("all")
public class CompositeFsm implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static CompositeFsm load(final String uri) {
    ResourceSet rs = new ResourceSetImpl() ;
    Resource res = rs.getResource(URI.createURI(uri), true) ;
    CompositeFsm mm = new CompositeFsm() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FlatFsmMT toFlatFsmMT() {
    family.compositefsm.adapters.flatfsmmt.CompositeFsmAdapter adaptee = new family.compositefsm.adapters.flatfsmmt.CompositeFsmAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public CompositeFsmMT toCompositeFsmMT() {
    family.compositefsm.adapters.compositefsmmt.CompositeFsmAdapter adaptee = new family.compositefsm.adapters.compositefsmmt.CompositeFsmAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
