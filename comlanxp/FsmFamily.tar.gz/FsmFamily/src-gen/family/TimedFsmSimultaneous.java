package family;

import family.FlatFsmMT;
import family.FlatFsmSimultaneousMT;
import family.TimedFsmMT;
import family.TimedFsmSimultaneousMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;

@SuppressWarnings("all")
public class TimedFsmSimultaneous implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static TimedFsmSimultaneous load(final String uri) {
    ResourceSet rs = new ResourceSetImpl() ;
    Resource res = rs.getResource(URI.createURI(uri), true) ;
    TimedFsmSimultaneous mm = new TimedFsmSimultaneous() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FlatFsmMT toFlatFsmMT() {
    family.timedfsmsimultaneous.adapters.flatfsmmt.TimedFsmSimultaneousAdapter adaptee = new family.timedfsmsimultaneous.adapters.flatfsmmt.TimedFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FlatFsmSimultaneousMT toFlatFsmSimultaneousMT() {
    family.timedfsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedFsmSimultaneousAdapter adaptee = new family.timedfsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public TimedFsmMT toTimedFsmMT() {
    family.timedfsmsimultaneous.adapters.timedfsmmt.TimedFsmSimultaneousAdapter adaptee = new family.timedfsmsimultaneous.adapters.timedfsmmt.TimedFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public TimedFsmSimultaneousMT toTimedFsmSimultaneousMT() {
    family.timedfsmsimultaneous.adapters.timedfsmsimultaneousmt.TimedFsmSimultaneousAdapter adaptee = new family.timedfsmsimultaneous.adapters.timedfsmsimultaneousmt.TimedFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
