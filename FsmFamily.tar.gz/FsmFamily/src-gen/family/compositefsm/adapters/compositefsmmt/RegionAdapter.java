package family.compositefsm.adapters.compositefsmmt;

import compositefsm.fsm.Region;
import family.compositefsm.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory;
import family.compositefsmmt.fsm.CompositeState;
import family.compositefsmmt.fsm.State;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.Collection;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;

@SuppressWarnings("all")
public class RegionAdapter extends EObjectAdapter<Region> implements family.compositefsmmt.fsm.Region {
  private CompositeFsmMTAdaptersFactory adaptersFactory;
  
  public RegionAdapter() {
    super(family.compositefsm.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.compositefsm.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance() ;
  }
  
  private EList<State> states;
  
  @Override
  public EList<State> getStates() {
    if (states == null)
    	states = fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), adaptersFactory) ;
    return states;
  }
  
  @Override
  public CompositeState getParent() {
    return (CompositeState) adaptersFactory.createAdapter(adaptee.getParent(), eResource) ;
  }
  
  @Override
  public void setParent(final CompositeState o) {
    if (o != null)
    	adaptee.setParent(((family.compositefsm.adapters.compositefsmmt.CompositeStateAdapter) o).getAdaptee()) ;
    else adaptee.setParent(null) ;
  }
  
  @Override
  public EClass eClass() {
    return family.compositefsmmt.fsm.FsmPackage.eINSTANCE.getRegion();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.REGION__STATES:
    		return getStates();
    	case family.compositefsmmt.fsm.FsmPackage.REGION__PARENT:
    		return getParent();
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.REGION__STATES:
    		getStates().clear();
    	case family.compositefsmmt.fsm.FsmPackage.REGION__PARENT:
    		setParent((family.compositefsmmt.fsm.CompositeState) null);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.REGION__STATES:
    		return getStates() != null && !getStates().isEmpty();
    	case family.compositefsmmt.fsm.FsmPackage.REGION__PARENT:
    		return getParent() != null;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.REGION__STATES:
    		getStates().clear();
    		getStates().addAll((Collection) newValue);
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.REGION__PARENT:
    		setParent((family.compositefsmmt.fsm.CompositeState) newValue);
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
