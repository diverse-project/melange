package family.compositefsm.adapters.compositefsmmt;

import compositefsm.fsm.InitialState;
import family.compositefsm.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory;
import family.compositefsmmt.fsm.CompositeState;
import family.compositefsmmt.fsm.StateMachine;
import family.compositefsmmt.fsm.Transition;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.Collection;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import semantics.common.Context;

@SuppressWarnings("all")
public class InitialStateAdapter extends EObjectAdapter<InitialState> implements family.compositefsmmt.fsm.InitialState {
  private CompositeFsmMTAdaptersFactory adaptersFactory;
  
  public InitialStateAdapter() {
    super(family.compositefsm.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.compositefsm.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  private EList<Transition> outgoing;
  
  @Override
  public EList<Transition> getOutgoing() {
    if (outgoing == null)
    	outgoing = fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getOutgoing(), adaptersFactory) ;
    return outgoing;
  }
  
  private EList<Transition> incoming;
  
  @Override
  public EList<Transition> getIncoming() {
    if (incoming == null)
    	incoming = fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getIncoming(), adaptersFactory) ;
    return incoming;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return (StateMachine) adaptersFactory.createAdapter(adaptee.getStateMachine(), eResource) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    if (o != null)
    	adaptee.setStateMachine(((family.compositefsm.adapters.compositefsmmt.StateMachineAdapter) o).getAdaptee()) ;
    else adaptee.setStateMachine(null) ;
  }
  
  @Override
  public CompositeState getParentState() {
    return (CompositeState) adaptersFactory.createAdapter(adaptee.getParentState(), eResource) ;
  }
  
  @Override
  public void setParentState(final CompositeState o) {
    if (o != null)
    	adaptee.setParentState(((family.compositefsm.adapters.compositefsmmt.CompositeStateAdapter) o).getAdaptee()) ;
    else adaptee.setParentState(null) ;
  }
  
  @Override
  public void eval(final Context context) {
    semantics.composite.StateAspect.eval(adaptee, context
    ) ;
  }
  
  protected final static String NAME_EDEFAULT = null;
  
  protected final static int INITIAL_TIME_EDEFAULT = 0;
  
  protected final static int FINAL_TIME_EDEFAULT = 0;
  
  @Override
  public EClass eClass() {
    return family.compositefsmmt.fsm.FsmPackage.eINSTANCE.getInitialState();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__NAME:
    		return getName();
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__OUTGOING:
    		return getOutgoing();
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__INCOMING:
    		return getIncoming();
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__STATE_MACHINE:
    		return getStateMachine();
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__INITIAL_TIME:
    		return new java.lang.Integer(getInitialTime());
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__FINAL_TIME:
    		return new java.lang.Integer(getFinalTime());
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__PARENT_STATE:
    		return getParentState();
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__NAME:
    		setName(NAME_EDEFAULT);
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__OUTGOING:
    		getOutgoing().clear();
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__INCOMING:
    		getIncoming().clear();
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__STATE_MACHINE:
    		setStateMachine((family.compositefsmmt.fsm.StateMachine) null);
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__INITIAL_TIME:
    		setInitialTime(INITIAL_TIME_EDEFAULT);
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__FINAL_TIME:
    		setFinalTime(FINAL_TIME_EDEFAULT);
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__PARENT_STATE:
    		setParentState((family.compositefsmmt.fsm.CompositeState) null);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__NAME:
    		return getName() != NAME_EDEFAULT;
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__OUTGOING:
    		return getOutgoing() != null && !getOutgoing().isEmpty();
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__INCOMING:
    		return getIncoming() != null && !getIncoming().isEmpty();
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__STATE_MACHINE:
    		return getStateMachine() != null;
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__INITIAL_TIME:
    		return getInitialTime() != INITIAL_TIME_EDEFAULT;
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__FINAL_TIME:
    		return getFinalTime() != FINAL_TIME_EDEFAULT;
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__PARENT_STATE:
    		return getParentState() != null;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__NAME:
    		setName((java.lang.String) newValue);
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__OUTGOING:
    		getOutgoing().clear();
    		getOutgoing().addAll((Collection) newValue);
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__INCOMING:
    		getIncoming().clear();
    		getIncoming().addAll((Collection) newValue);
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__STATE_MACHINE:
    		setStateMachine((family.compositefsmmt.fsm.StateMachine) newValue);
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__INITIAL_TIME:
    		setInitialTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__FINAL_TIME:
    		setFinalTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.INITIAL_STATE__PARENT_STATE:
    		setParentState((family.compositefsmmt.fsm.CompositeState) newValue);
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
