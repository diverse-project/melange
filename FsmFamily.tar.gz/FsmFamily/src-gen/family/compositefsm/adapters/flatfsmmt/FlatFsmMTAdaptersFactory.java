package family.compositefsm.adapters.flatfsmmt;

import compositefsm.fsm.FinalState;
import compositefsm.fsm.Fork;
import compositefsm.fsm.InitialState;
import compositefsm.fsm.Join;
import compositefsm.fsm.NamedElement;
import compositefsm.fsm.Pseudostate;
import compositefsm.fsm.State;
import compositefsm.fsm.StateMachine;
import compositefsm.fsm.TimedTransition;
import compositefsm.fsm.Transition;
import compositefsm.fsm.Trigger;
import family.compositefsm.adapters.flatfsmmt.FinalStateAdapter;
import family.compositefsm.adapters.flatfsmmt.ForkAdapter;
import family.compositefsm.adapters.flatfsmmt.InitialStateAdapter;
import family.compositefsm.adapters.flatfsmmt.JoinAdapter;
import family.compositefsm.adapters.flatfsmmt.NamedElementAdapter;
import family.compositefsm.adapters.flatfsmmt.PseudostateAdapter;
import family.compositefsm.adapters.flatfsmmt.StateAdapter;
import family.compositefsm.adapters.flatfsmmt.StateMachineAdapter;
import family.compositefsm.adapters.flatfsmmt.TimedTransitionAdapter;
import family.compositefsm.adapters.flatfsmmt.TransitionAdapter;
import family.compositefsm.adapters.flatfsmmt.TriggerAdapter;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.WeakHashMap;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FlatFsmMTAdaptersFactory implements AdaptersFactory {
  private static FlatFsmMTAdaptersFactory instance;
  
  private WeakHashMap<EObject, EObjectAdapter> register;
  
  public FlatFsmMTAdaptersFactory() {
    register = new WeakHashMap();
  }
  
  public static FlatFsmMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new family.compositefsm.adapters.flatfsmmt.FlatFsmMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o, final Resource res) {
    if (o instanceof compositefsm.fsm.StateMachine){
    	return createStateMachineAdapter((compositefsm.fsm.StateMachine) o, res) ;
    }
    if (o instanceof compositefsm.fsm.FinalState){
    	return createFinalStateAdapter((compositefsm.fsm.FinalState) o, res) ;
    }
    if (o instanceof compositefsm.fsm.InitialState){
    	return createInitialStateAdapter((compositefsm.fsm.InitialState) o, res) ;
    }
    if (o instanceof compositefsm.fsm.State){
    	return createStateAdapter((compositefsm.fsm.State) o, res) ;
    }
    if (o instanceof compositefsm.fsm.TimedTransition){
    	return createTimedTransitionAdapter((compositefsm.fsm.TimedTransition) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Transition){
    	return createTransitionAdapter((compositefsm.fsm.Transition) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Fork){
    	return createForkAdapter((compositefsm.fsm.Fork) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Join){
    	return createJoinAdapter((compositefsm.fsm.Join) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Pseudostate){
    	return createPseudostateAdapter((compositefsm.fsm.Pseudostate) o, res) ;
    }
    if (o instanceof compositefsm.fsm.NamedElement){
    	return createNamedElementAdapter((compositefsm.fsm.NamedElement) o, res) ;
    }
    if (o instanceof compositefsm.fsm.Trigger){
    	return createTriggerAdapter((compositefsm.fsm.Trigger) o, res) ;
    }
    
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.flatfsmmt.NamedElementAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.flatfsmmt.NamedElementAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.flatfsmmt.NamedElementAdapter) adapter ;
    }
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.flatfsmmt.StateMachineAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.flatfsmmt.StateMachineAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.flatfsmmt.StateMachineAdapter) adapter ;
    }
  }
  
  public StateAdapter createStateAdapter(final State adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.flatfsmmt.StateAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.flatfsmmt.StateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.flatfsmmt.StateAdapter) adapter ;
    }
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.flatfsmmt.FinalStateAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.flatfsmmt.FinalStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.flatfsmmt.FinalStateAdapter) adapter ;
    }
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.flatfsmmt.InitialStateAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.flatfsmmt.InitialStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.flatfsmmt.InitialStateAdapter) adapter ;
    }
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.flatfsmmt.TransitionAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.flatfsmmt.TransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.flatfsmmt.TransitionAdapter) adapter ;
    }
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.flatfsmmt.TimedTransitionAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.flatfsmmt.TimedTransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.flatfsmmt.TimedTransitionAdapter) adapter ;
    }
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.flatfsmmt.TriggerAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.flatfsmmt.TriggerAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.flatfsmmt.TriggerAdapter) adapter ;
    }
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.flatfsmmt.PseudostateAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.flatfsmmt.PseudostateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.flatfsmmt.PseudostateAdapter) adapter ;
    }
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.flatfsmmt.ForkAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.flatfsmmt.ForkAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.flatfsmmt.ForkAdapter) adapter ;
    }
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.compositefsm.adapters.flatfsmmt.JoinAdapter) adapter;
    else {
    	adapter = new family.compositefsm.adapters.flatfsmmt.JoinAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.compositefsm.adapters.flatfsmmt.JoinAdapter) adapter ;
    }
  }
}
