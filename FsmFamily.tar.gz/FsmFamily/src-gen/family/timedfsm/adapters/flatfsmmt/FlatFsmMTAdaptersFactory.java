package family.timedfsm.adapters.flatfsmmt;

import family.timedfsm.adapters.flatfsmmt.FinalStateAdapter;
import family.timedfsm.adapters.flatfsmmt.ForkAdapter;
import family.timedfsm.adapters.flatfsmmt.InitialStateAdapter;
import family.timedfsm.adapters.flatfsmmt.JoinAdapter;
import family.timedfsm.adapters.flatfsmmt.NamedElementAdapter;
import family.timedfsm.adapters.flatfsmmt.PseudostateAdapter;
import family.timedfsm.adapters.flatfsmmt.StateAdapter;
import family.timedfsm.adapters.flatfsmmt.StateMachineAdapter;
import family.timedfsm.adapters.flatfsmmt.TimedTransitionAdapter;
import family.timedfsm.adapters.flatfsmmt.TransitionAdapter;
import family.timedfsm.adapters.flatfsmmt.TriggerAdapter;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.WeakHashMap;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import timedfsm.fsm.FinalState;
import timedfsm.fsm.Fork;
import timedfsm.fsm.InitialState;
import timedfsm.fsm.Join;
import timedfsm.fsm.NamedElement;
import timedfsm.fsm.Pseudostate;
import timedfsm.fsm.State;
import timedfsm.fsm.StateMachine;
import timedfsm.fsm.TimedTransition;
import timedfsm.fsm.Transition;
import timedfsm.fsm.Trigger;

@SuppressWarnings("all")
public class FlatFsmMTAdaptersFactory implements AdaptersFactory {
  private static FlatFsmMTAdaptersFactory instance;
  
  private WeakHashMap<EObject, EObjectAdapter> register;
  
  public FlatFsmMTAdaptersFactory() {
    register = new WeakHashMap();
  }
  
  public static FlatFsmMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new family.timedfsm.adapters.flatfsmmt.FlatFsmMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o, final Resource res) {
    if (o instanceof timedfsm.fsm.StateMachine){
    	return createStateMachineAdapter((timedfsm.fsm.StateMachine) o, res) ;
    }
    if (o instanceof timedfsm.fsm.FinalState){
    	return createFinalStateAdapter((timedfsm.fsm.FinalState) o, res) ;
    }
    if (o instanceof timedfsm.fsm.InitialState){
    	return createInitialStateAdapter((timedfsm.fsm.InitialState) o, res) ;
    }
    if (o instanceof timedfsm.fsm.State){
    	return createStateAdapter((timedfsm.fsm.State) o, res) ;
    }
    if (o instanceof timedfsm.fsm.TimedTransition){
    	return createTimedTransitionAdapter((timedfsm.fsm.TimedTransition) o, res) ;
    }
    if (o instanceof timedfsm.fsm.Transition){
    	return createTransitionAdapter((timedfsm.fsm.Transition) o, res) ;
    }
    if (o instanceof timedfsm.fsm.Fork){
    	return createForkAdapter((timedfsm.fsm.Fork) o, res) ;
    }
    if (o instanceof timedfsm.fsm.Join){
    	return createJoinAdapter((timedfsm.fsm.Join) o, res) ;
    }
    if (o instanceof timedfsm.fsm.Pseudostate){
    	return createPseudostateAdapter((timedfsm.fsm.Pseudostate) o, res) ;
    }
    if (o instanceof timedfsm.fsm.NamedElement){
    	return createNamedElementAdapter((timedfsm.fsm.NamedElement) o, res) ;
    }
    if (o instanceof timedfsm.fsm.Trigger){
    	return createTriggerAdapter((timedfsm.fsm.Trigger) o, res) ;
    }
    
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsm.adapters.flatfsmmt.NamedElementAdapter) adapter;
    else {
    	adapter = new family.timedfsm.adapters.flatfsmmt.NamedElementAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsm.adapters.flatfsmmt.NamedElementAdapter) adapter ;
    }
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsm.adapters.flatfsmmt.StateMachineAdapter) adapter;
    else {
    	adapter = new family.timedfsm.adapters.flatfsmmt.StateMachineAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsm.adapters.flatfsmmt.StateMachineAdapter) adapter ;
    }
  }
  
  public StateAdapter createStateAdapter(final State adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsm.adapters.flatfsmmt.StateAdapter) adapter;
    else {
    	adapter = new family.timedfsm.adapters.flatfsmmt.StateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsm.adapters.flatfsmmt.StateAdapter) adapter ;
    }
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsm.adapters.flatfsmmt.FinalStateAdapter) adapter;
    else {
    	adapter = new family.timedfsm.adapters.flatfsmmt.FinalStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsm.adapters.flatfsmmt.FinalStateAdapter) adapter ;
    }
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsm.adapters.flatfsmmt.InitialStateAdapter) adapter;
    else {
    	adapter = new family.timedfsm.adapters.flatfsmmt.InitialStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsm.adapters.flatfsmmt.InitialStateAdapter) adapter ;
    }
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsm.adapters.flatfsmmt.TransitionAdapter) adapter;
    else {
    	adapter = new family.timedfsm.adapters.flatfsmmt.TransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsm.adapters.flatfsmmt.TransitionAdapter) adapter ;
    }
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsm.adapters.flatfsmmt.TimedTransitionAdapter) adapter;
    else {
    	adapter = new family.timedfsm.adapters.flatfsmmt.TimedTransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsm.adapters.flatfsmmt.TimedTransitionAdapter) adapter ;
    }
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsm.adapters.flatfsmmt.TriggerAdapter) adapter;
    else {
    	adapter = new family.timedfsm.adapters.flatfsmmt.TriggerAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsm.adapters.flatfsmmt.TriggerAdapter) adapter ;
    }
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsm.adapters.flatfsmmt.PseudostateAdapter) adapter;
    else {
    	adapter = new family.timedfsm.adapters.flatfsmmt.PseudostateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsm.adapters.flatfsmmt.PseudostateAdapter) adapter ;
    }
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsm.adapters.flatfsmmt.ForkAdapter) adapter;
    else {
    	adapter = new family.timedfsm.adapters.flatfsmmt.ForkAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsm.adapters.flatfsmmt.ForkAdapter) adapter ;
    }
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedfsm.adapters.flatfsmmt.JoinAdapter) adapter;
    else {
    	adapter = new family.timedfsm.adapters.flatfsmmt.JoinAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedfsm.adapters.flatfsmmt.JoinAdapter) adapter ;
    }
  }
}
