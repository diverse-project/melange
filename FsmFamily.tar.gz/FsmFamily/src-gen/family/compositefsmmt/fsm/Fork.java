/**
 */
package family.compositefsmmt.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fork</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see family.compositefsmmt.fsm.FsmPackage#getFork()
 * @model
 * @generated
 */
public interface Fork extends Pseudostate {
} // Fork
