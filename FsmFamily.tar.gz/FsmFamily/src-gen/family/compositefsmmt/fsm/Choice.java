/**
 */
package family.compositefsmmt.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Choice</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see family.compositefsmmt.fsm.FsmPackage#getChoice()
 * @model
 * @generated
 */
public interface Choice extends Pseudostate {
} // Choice
