/**
 */
package family.compositefsmmt.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Join</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see family.compositefsmmt.fsm.FsmPackage#getJoin()
 * @model
 * @generated
 */
public interface Join extends Pseudostate {
} // Join
