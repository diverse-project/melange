package family;

import fr.inria.diverse.melange.resource.MelangeRegistry;
import fr.inria.diverse.melange.resource.MelangeRegistryImpl;
import fr.inria.diverse.melange.resource.MelangeResourceFactoryImpl;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

@SuppressWarnings("all")
public class StandaloneSetup {
  public static void doSetup() {
    StandaloneSetup setup = new StandaloneSetup() ;
    setup.doEMFRegistration() ;
    setup.doAdaptersRegistration() ;
  }
  
  public void doEMFRegistration() {
    EPackage.Registry.INSTANCE.put(
    	flatfsm.fsm.FsmPackage.eNS_URI,
    	flatfsm.fsm.FsmPackage.eINSTANCE
    ) ;
    EPackage.Registry.INSTANCE.put(
    	flatfsm.fsm.FsmPackage.eNS_URI,
    	flatfsm.fsm.FsmPackage.eINSTANCE
    ) ;
    EPackage.Registry.INSTANCE.put(
    	timedfsm.fsm.FsmPackage.eNS_URI,
    	timedfsm.fsm.FsmPackage.eINSTANCE
    ) ;
    EPackage.Registry.INSTANCE.put(
    	timedfsm.fsm.FsmPackage.eNS_URI,
    	timedfsm.fsm.FsmPackage.eINSTANCE
    ) ;
    EPackage.Registry.INSTANCE.put(
    	compositefsm.fsm.FsmPackage.eNS_URI,
    	compositefsm.fsm.FsmPackage.eINSTANCE
    ) ;
    EPackage.Registry.INSTANCE.put(
    	compositefsm.fsm.FsmPackage.eNS_URI,
    	compositefsm.fsm.FsmPackage.eINSTANCE
    ) ;
    EPackage.Registry.INSTANCE.put(
    	timedcompositefsm.fsm.FsmPackage.eNS_URI,
    	timedcompositefsm.fsm.FsmPackage.eINSTANCE
    ) ;
    EPackage.Registry.INSTANCE.put(
    	timedcompositefsm.fsm.FsmPackage.eNS_URI,
    	timedcompositefsm.fsm.FsmPackage.eINSTANCE
    ) ;
    
    Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put(
    	"*",
    	new XMIResourceFactoryImpl()
    ) ;
    Resource.Factory.Registry.INSTANCE.getProtocolToFactoryMap().put(
    	"melange",
    	new MelangeResourceFactoryImpl()
    ) ;
  }
  
  public void doAdaptersRegistration() {
    MelangeRegistry.LanguageDescriptor flatFsm = new MelangeRegistryImpl.LanguageDescriptorImpl(
    	"family.FlatFsm", "", "http://fsm/", "family.FlatFsmMT"
    ) ;
    flatFsm.addAdapter("family.FlatFsmMT", family.flatfsm.adapters.flatfsmmt.FlatFsmAdapter.class) ;
    MelangeRegistry.INSTANCE.getLanguageMap().put(
    	"family.FlatFsm",
    	flatFsm
    ) ;
    MelangeRegistry.LanguageDescriptor flatFsmSimultaneous = new MelangeRegistryImpl.LanguageDescriptorImpl(
    	"family.FlatFsmSimultaneous", "", "http://fsm/", "family.FlatFsmSimultaneousMT"
    ) ;
    flatFsmSimultaneous.addAdapter("family.FlatFsmMT", family.flatfsmsimultaneous.adapters.flatfsmmt.FlatFsmSimultaneousAdapter.class) ;
    flatFsmSimultaneous.addAdapter("family.FlatFsmSimultaneousMT", family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousAdapter.class) ;
    MelangeRegistry.INSTANCE.getLanguageMap().put(
    	"family.FlatFsmSimultaneous",
    	flatFsmSimultaneous
    ) ;
    MelangeRegistry.LanguageDescriptor timedFsm = new MelangeRegistryImpl.LanguageDescriptorImpl(
    	"family.TimedFsm", "", "http://timedfsm/", "family.TimedFsmMT"
    ) ;
    timedFsm.addAdapter("family.FlatFsmMT", family.timedfsm.adapters.flatfsmmt.TimedFsmAdapter.class) ;
    timedFsm.addAdapter("family.TimedFsmMT", family.timedfsm.adapters.timedfsmmt.TimedFsmAdapter.class) ;
    MelangeRegistry.INSTANCE.getLanguageMap().put(
    	"family.TimedFsm",
    	timedFsm
    ) ;
    MelangeRegistry.LanguageDescriptor timedFsmSimultaneous = new MelangeRegistryImpl.LanguageDescriptorImpl(
    	"family.TimedFsmSimultaneous", "", "http://timedfsm/", "family.TimedFsmSimultaneousMT"
    ) ;
    timedFsmSimultaneous.addAdapter("family.FlatFsmMT", family.timedfsmsimultaneous.adapters.flatfsmmt.TimedFsmSimultaneousAdapter.class) ;
    timedFsmSimultaneous.addAdapter("family.FlatFsmSimultaneousMT", family.timedfsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedFsmSimultaneousAdapter.class) ;
    timedFsmSimultaneous.addAdapter("family.TimedFsmMT", family.timedfsmsimultaneous.adapters.timedfsmmt.TimedFsmSimultaneousAdapter.class) ;
    timedFsmSimultaneous.addAdapter("family.TimedFsmSimultaneousMT", family.timedfsmsimultaneous.adapters.timedfsmsimultaneousmt.TimedFsmSimultaneousAdapter.class) ;
    MelangeRegistry.INSTANCE.getLanguageMap().put(
    	"family.TimedFsmSimultaneous",
    	timedFsmSimultaneous
    ) ;
    MelangeRegistry.LanguageDescriptor compositeFsm = new MelangeRegistryImpl.LanguageDescriptorImpl(
    	"family.CompositeFsm", "", "http://compositefsm/", "family.CompositeFsmMT"
    ) ;
    compositeFsm.addAdapter("family.FlatFsmMT", family.compositefsm.adapters.flatfsmmt.CompositeFsmAdapter.class) ;
    compositeFsm.addAdapter("family.CompositeFsmMT", family.compositefsm.adapters.compositefsmmt.CompositeFsmAdapter.class) ;
    MelangeRegistry.INSTANCE.getLanguageMap().put(
    	"family.CompositeFsm",
    	compositeFsm
    ) ;
    MelangeRegistry.LanguageDescriptor compositeFsmSimultaneous = new MelangeRegistryImpl.LanguageDescriptorImpl(
    	"family.CompositeFsmSimultaneous", "", "http://compositefsm/", "family.CompositeFsmSimultaneousMT"
    ) ;
    compositeFsmSimultaneous.addAdapter("family.FlatFsmMT", family.compositefsmsimultaneous.adapters.flatfsmmt.CompositeFsmSimultaneousAdapter.class) ;
    compositeFsmSimultaneous.addAdapter("family.FlatFsmSimultaneousMT", family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.CompositeFsmSimultaneousAdapter.class) ;
    compositeFsmSimultaneous.addAdapter("family.CompositeFsmMT", family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmSimultaneousAdapter.class) ;
    compositeFsmSimultaneous.addAdapter("family.CompositeFsmSimultaneousMT", family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeFsmSimultaneousAdapter.class) ;
    MelangeRegistry.INSTANCE.getLanguageMap().put(
    	"family.CompositeFsmSimultaneous",
    	compositeFsmSimultaneous
    ) ;
    MelangeRegistry.LanguageDescriptor timedCompositeFsm = new MelangeRegistryImpl.LanguageDescriptorImpl(
    	"family.TimedCompositeFsm", "", "http://timedcompositefsm/", "family.TimedCompositeFsmMT"
    ) ;
    timedCompositeFsm.addAdapter("family.FlatFsmMT", family.timedcompositefsm.adapters.flatfsmmt.TimedCompositeFsmAdapter.class) ;
    timedCompositeFsm.addAdapter("family.TimedFsmMT", family.timedcompositefsm.adapters.timedfsmmt.TimedCompositeFsmAdapter.class) ;
    timedCompositeFsm.addAdapter("family.TimedCompositeFsmMT", family.timedcompositefsm.adapters.timedcompositefsmmt.TimedCompositeFsmAdapter.class) ;
    MelangeRegistry.INSTANCE.getLanguageMap().put(
    	"family.TimedCompositeFsm",
    	timedCompositeFsm
    ) ;
    MelangeRegistry.LanguageDescriptor timedCompositeFsmSimultaneous = new MelangeRegistryImpl.LanguageDescriptorImpl(
    	"family.TimedCompositeFsmSimultaneous", "", "http://timedcompositefsm/", "family.TimedCompositeFsmSimultaneousMT"
    ) ;
    timedCompositeFsmSimultaneous.addAdapter("family.FlatFsmMT", family.timedcompositefsmsimultaneous.adapters.flatfsmmt.TimedCompositeFsmSimultaneousAdapter.class) ;
    timedCompositeFsmSimultaneous.addAdapter("family.FlatFsmSimultaneousMT", family.timedcompositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedCompositeFsmSimultaneousAdapter.class) ;
    timedCompositeFsmSimultaneous.addAdapter("family.TimedFsmMT", family.timedcompositefsmsimultaneous.adapters.timedfsmmt.TimedCompositeFsmSimultaneousAdapter.class) ;
    timedCompositeFsmSimultaneous.addAdapter("family.TimedFsmSimultaneousMT", family.timedcompositefsmsimultaneous.adapters.timedfsmsimultaneousmt.TimedCompositeFsmSimultaneousAdapter.class) ;
    timedCompositeFsmSimultaneous.addAdapter("family.TimedCompositeFsmMT", family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedCompositeFsmSimultaneousAdapter.class) ;
    timedCompositeFsmSimultaneous.addAdapter("family.TimedCompositeFsmSimultaneousMT", family.timedcompositefsmsimultaneous.adapters.timedcompositefsmsimultaneousmt.TimedCompositeFsmSimultaneousAdapter.class) ;
    MelangeRegistry.INSTANCE.getLanguageMap().put(
    	"family.TimedCompositeFsmSimultaneous",
    	timedCompositeFsmSimultaneous
    ) ;
    MelangeRegistry.ModelTypeDescriptor flatFsmMT = new MelangeRegistryImpl.ModelTypeDescriptorImpl(
    	"family.FlatFsmMT", "", "http://flatfsmmt/"
    ) ;
    MelangeRegistry.INSTANCE.getModelTypeMap().put(
    	"family.FlatFsmMT",
    	flatFsmMT
    ) ;
    MelangeRegistry.ModelTypeDescriptor flatFsmSimultaneousMT = new MelangeRegistryImpl.ModelTypeDescriptorImpl(
    	"family.FlatFsmSimultaneousMT", "", "http://flatfsmsimultaneousmt/"
    ) ;
    flatFsmSimultaneousMT.addSuperType("family.FlatFsmMT") ;
    MelangeRegistry.INSTANCE.getModelTypeMap().put(
    	"family.FlatFsmSimultaneousMT",
    	flatFsmSimultaneousMT
    ) ;
    MelangeRegistry.ModelTypeDescriptor timedFsmMT = new MelangeRegistryImpl.ModelTypeDescriptorImpl(
    	"family.TimedFsmMT", "", "http://timedfsmmt/"
    ) ;
    timedFsmMT.addSuperType("family.FlatFsmMT") ;
    MelangeRegistry.INSTANCE.getModelTypeMap().put(
    	"family.TimedFsmMT",
    	timedFsmMT
    ) ;
    MelangeRegistry.ModelTypeDescriptor timedFsmSimultaneousMT = new MelangeRegistryImpl.ModelTypeDescriptorImpl(
    	"family.TimedFsmSimultaneousMT", "", "http://timedfsmsimultaneousmt/"
    ) ;
    timedFsmSimultaneousMT.addSuperType("family.FlatFsmMT") ;
    timedFsmSimultaneousMT.addSuperType("family.FlatFsmSimultaneousMT") ;
    timedFsmSimultaneousMT.addSuperType("family.TimedFsmMT") ;
    MelangeRegistry.INSTANCE.getModelTypeMap().put(
    	"family.TimedFsmSimultaneousMT",
    	timedFsmSimultaneousMT
    ) ;
    MelangeRegistry.ModelTypeDescriptor compositeFsmMT = new MelangeRegistryImpl.ModelTypeDescriptorImpl(
    	"family.CompositeFsmMT", "", "http://compositefsmmt/"
    ) ;
    compositeFsmMT.addSuperType("family.FlatFsmMT") ;
    MelangeRegistry.INSTANCE.getModelTypeMap().put(
    	"family.CompositeFsmMT",
    	compositeFsmMT
    ) ;
    MelangeRegistry.ModelTypeDescriptor compositeFsmSimultaneousMT = new MelangeRegistryImpl.ModelTypeDescriptorImpl(
    	"family.CompositeFsmSimultaneousMT", "", "http://compositefsmsimultaneousmt/"
    ) ;
    compositeFsmSimultaneousMT.addSuperType("family.FlatFsmMT") ;
    compositeFsmSimultaneousMT.addSuperType("family.FlatFsmSimultaneousMT") ;
    compositeFsmSimultaneousMT.addSuperType("family.CompositeFsmMT") ;
    MelangeRegistry.INSTANCE.getModelTypeMap().put(
    	"family.CompositeFsmSimultaneousMT",
    	compositeFsmSimultaneousMT
    ) ;
    MelangeRegistry.ModelTypeDescriptor timedCompositeFsmMT = new MelangeRegistryImpl.ModelTypeDescriptorImpl(
    	"family.TimedCompositeFsmMT", "", "http://timedcompositefsmmt/"
    ) ;
    timedCompositeFsmMT.addSuperType("family.FlatFsmMT") ;
    timedCompositeFsmMT.addSuperType("family.TimedFsmMT") ;
    MelangeRegistry.INSTANCE.getModelTypeMap().put(
    	"family.TimedCompositeFsmMT",
    	timedCompositeFsmMT
    ) ;
    MelangeRegistry.ModelTypeDescriptor timedCompositeFsmSimultaneousMT = new MelangeRegistryImpl.ModelTypeDescriptorImpl(
    	"family.TimedCompositeFsmSimultaneousMT", "", "http://timedcompositefsmsimultaneousmt/"
    ) ;
    timedCompositeFsmSimultaneousMT.addSuperType("family.FlatFsmMT") ;
    timedCompositeFsmSimultaneousMT.addSuperType("family.FlatFsmSimultaneousMT") ;
    timedCompositeFsmSimultaneousMT.addSuperType("family.TimedFsmMT") ;
    timedCompositeFsmSimultaneousMT.addSuperType("family.TimedFsmSimultaneousMT") ;
    timedCompositeFsmSimultaneousMT.addSuperType("family.TimedCompositeFsmMT") ;
    MelangeRegistry.INSTANCE.getModelTypeMap().put(
    	"family.TimedCompositeFsmSimultaneousMT",
    	timedCompositeFsmSimultaneousMT
    ) ;
  }
}
