/**
 */
package family.flatfsmmt.fsm;

import org.eclipse.emf.common.util.EList;

import semantics.common.Context;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State Machine</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link family.flatfsmmt.fsm.StateMachine#getStates <em>States</em>}</li>
 *   <li>{@link family.flatfsmmt.fsm.StateMachine#getTransitions <em>Transitions</em>}</li>
 * </ul>
 *
 * @see family.flatfsmmt.fsm.FsmPackage#getStateMachine()
 * @model
 * @generated
 */
public interface StateMachine extends NamedElement {
	/**
	 * Returns the value of the '<em><b>States</b></em>' containment reference list.
	 * The list contents are of type {@link family.flatfsmmt.fsm.State}.
	 * It is bidirectional and its opposite is '{@link family.flatfsmmt.fsm.State#getStateMachine <em>State Machine</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>States</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>States</em>' containment reference list.
	 * @see family.flatfsmmt.fsm.FsmPackage#getStateMachine_States()
	 * @see family.flatfsmmt.fsm.State#getStateMachine
	 * @model opposite="stateMachine" containment="true"
	 * @generated
	 */
	EList<State> getStates();

	/**
	 * Returns the value of the '<em><b>Transitions</b></em>' containment reference list.
	 * The list contents are of type {@link family.flatfsmmt.fsm.Transition}.
	 * It is bidirectional and its opposite is '{@link family.flatfsmmt.fsm.Transition#getStateMachine <em>State Machine</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transitions</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transitions</em>' containment reference list.
	 * @see family.flatfsmmt.fsm.FsmPackage#getStateMachine_Transitions()
	 * @see family.flatfsmmt.fsm.Transition#getStateMachine
	 * @model opposite="stateMachine" containment="true"
	 * @generated
	 */
	EList<Transition> getTransitions();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model contextDataType="family.flatfsmmt.fsm.Context"
	 * @generated
	 */
	void eval(Context context, String filePath);

} // StateMachine
