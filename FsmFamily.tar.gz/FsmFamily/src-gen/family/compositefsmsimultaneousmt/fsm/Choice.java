/**
 */
package family.compositefsmsimultaneousmt.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Choice</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see family.compositefsmsimultaneousmt.fsm.FsmPackage#getChoice()
 * @model
 * @generated
 */
public interface Choice extends Pseudostate {
} // Choice
