package family.flatfsmsimultaneous.adapters.flatfsmmt;

import family.flatfsmmt.fsm.FinalState;
import family.flatfsmmt.fsm.Fork;
import family.flatfsmmt.fsm.FsmFactory;
import family.flatfsmmt.fsm.FsmPackage;
import family.flatfsmmt.fsm.InitialState;
import family.flatfsmmt.fsm.Join;
import family.flatfsmmt.fsm.NamedElement;
import family.flatfsmmt.fsm.Pseudostate;
import family.flatfsmmt.fsm.State;
import family.flatfsmmt.fsm.StateMachine;
import family.flatfsmmt.fsm.TimedTransition;
import family.flatfsmmt.fsm.Transition;
import family.flatfsmmt.fsm.Trigger;
import family.flatfsmsimultaneous.adapters.flatfsmmt.FlatFsmMTAdaptersFactory;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;

@SuppressWarnings("all")
public class FlatFsmMTFactoryAdapter extends EFactoryImpl implements FsmFactory {
  private FlatFsmMTAdaptersFactory adaptersFactory = family.flatfsmsimultaneous.adapters.flatfsmmt.FlatFsmMTAdaptersFactory.getInstance();
  
  private flatfsm.fsm.FsmFactory fsmAdaptee = flatfsm.fsm.FsmFactory.eINSTANCE;
  
  @Override
  public NamedElement createNamedElement() {
    return adaptersFactory.createNamedElementAdapter(fsmAdaptee.createNamedElement(), null) ;
  }
  
  @Override
  public StateMachine createStateMachine() {
    return adaptersFactory.createStateMachineAdapter(fsmAdaptee.createStateMachine(), null) ;
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(fsmAdaptee.createState(), null) ;
  }
  
  @Override
  public FinalState createFinalState() {
    return adaptersFactory.createFinalStateAdapter(fsmAdaptee.createFinalState(), null) ;
  }
  
  @Override
  public InitialState createInitialState() {
    return adaptersFactory.createInitialStateAdapter(fsmAdaptee.createInitialState(), null) ;
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(fsmAdaptee.createTransition(), null) ;
  }
  
  @Override
  public TimedTransition createTimedTransition() {
    return adaptersFactory.createTimedTransitionAdapter(fsmAdaptee.createTimedTransition(), null) ;
  }
  
  @Override
  public Trigger createTrigger() {
    return adaptersFactory.createTriggerAdapter(fsmAdaptee.createTrigger(), null) ;
  }
  
  @Override
  public Pseudostate createPseudostate() {
    return adaptersFactory.createPseudostateAdapter(fsmAdaptee.createPseudostate(), null) ;
  }
  
  @Override
  public Fork createFork() {
    return adaptersFactory.createForkAdapter(fsmAdaptee.createFork(), null) ;
  }
  
  @Override
  public Join createJoin() {
    return adaptersFactory.createJoinAdapter(fsmAdaptee.createJoin(), null) ;
  }
  
  @Override
  public EPackage getEPackage() {
    return getFsmPackage();
  }
  
  public FsmPackage getFsmPackage() {
    return family.flatfsmmt.fsm.FsmPackage.eINSTANCE;
  }
}
