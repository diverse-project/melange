package family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt;

import family.FlatFsmSimultaneousMT;
import family.flatfsmsimultaneousmt.fsm.FsmFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;
import org.eclipse.emf.common.util.URI;

@SuppressWarnings("all")
public class FlatFsmSimultaneousAdapter extends ResourceAdapter implements FlatFsmSimultaneousMT {
  public FlatFsmSimultaneousAdapter() {
    super(family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FsmFactory getFactory() {
    return new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(URI.createURI(uri));
    this.adaptee.save(null);
  }
}
