package family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt;

import family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.FinalStateAdapter;
import family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.ForkAdapter;
import family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.InitialStateAdapter;
import family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.JoinAdapter;
import family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.NamedElementAdapter;
import family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.PseudostateAdapter;
import family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.StateAdapter;
import family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.StateMachineAdapter;
import family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedTransitionAdapter;
import family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.TransitionAdapter;
import family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.TriggerAdapter;
import flatfsm.fsm.FinalState;
import flatfsm.fsm.Fork;
import flatfsm.fsm.InitialState;
import flatfsm.fsm.Join;
import flatfsm.fsm.NamedElement;
import flatfsm.fsm.Pseudostate;
import flatfsm.fsm.State;
import flatfsm.fsm.StateMachine;
import flatfsm.fsm.TimedTransition;
import flatfsm.fsm.Transition;
import flatfsm.fsm.Trigger;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.WeakHashMap;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FlatFsmSimultaneousMTAdaptersFactory implements AdaptersFactory {
  private static FlatFsmSimultaneousMTAdaptersFactory instance;
  
  private WeakHashMap<EObject, EObjectAdapter> register;
  
  public FlatFsmSimultaneousMTAdaptersFactory() {
    register = new WeakHashMap();
  }
  
  public static FlatFsmSimultaneousMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o, final Resource res) {
    if (o instanceof flatfsm.fsm.StateMachine){
    	return createStateMachineAdapter((flatfsm.fsm.StateMachine) o, res) ;
    }
    if (o instanceof flatfsm.fsm.FinalState){
    	return createFinalStateAdapter((flatfsm.fsm.FinalState) o, res) ;
    }
    if (o instanceof flatfsm.fsm.InitialState){
    	return createInitialStateAdapter((flatfsm.fsm.InitialState) o, res) ;
    }
    if (o instanceof flatfsm.fsm.State){
    	return createStateAdapter((flatfsm.fsm.State) o, res) ;
    }
    if (o instanceof flatfsm.fsm.TimedTransition){
    	return createTimedTransitionAdapter((flatfsm.fsm.TimedTransition) o, res) ;
    }
    if (o instanceof flatfsm.fsm.Transition){
    	return createTransitionAdapter((flatfsm.fsm.Transition) o, res) ;
    }
    if (o instanceof flatfsm.fsm.Fork){
    	return createForkAdapter((flatfsm.fsm.Fork) o, res) ;
    }
    if (o instanceof flatfsm.fsm.Join){
    	return createJoinAdapter((flatfsm.fsm.Join) o, res) ;
    }
    if (o instanceof flatfsm.fsm.Pseudostate){
    	return createPseudostateAdapter((flatfsm.fsm.Pseudostate) o, res) ;
    }
    if (o instanceof flatfsm.fsm.NamedElement){
    	return createNamedElementAdapter((flatfsm.fsm.NamedElement) o, res) ;
    }
    if (o instanceof flatfsm.fsm.Trigger){
    	return createTriggerAdapter((flatfsm.fsm.Trigger) o, res) ;
    }
    
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.NamedElementAdapter) adapter;
    else {
    	adapter = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.NamedElementAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.NamedElementAdapter) adapter ;
    }
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.StateMachineAdapter) adapter;
    else {
    	adapter = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.StateMachineAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.StateMachineAdapter) adapter ;
    }
  }
  
  public StateAdapter createStateAdapter(final State adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.StateAdapter) adapter;
    else {
    	adapter = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.StateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.StateAdapter) adapter ;
    }
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.FinalStateAdapter) adapter;
    else {
    	adapter = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.FinalStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.FinalStateAdapter) adapter ;
    }
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.InitialStateAdapter) adapter;
    else {
    	adapter = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.InitialStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.InitialStateAdapter) adapter ;
    }
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.TransitionAdapter) adapter;
    else {
    	adapter = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.TransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.TransitionAdapter) adapter ;
    }
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedTransitionAdapter) adapter;
    else {
    	adapter = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedTransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedTransitionAdapter) adapter ;
    }
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.TriggerAdapter) adapter;
    else {
    	adapter = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.TriggerAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.TriggerAdapter) adapter ;
    }
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.PseudostateAdapter) adapter;
    else {
    	adapter = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.PseudostateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.PseudostateAdapter) adapter ;
    }
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.ForkAdapter) adapter;
    else {
    	adapter = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.ForkAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.ForkAdapter) adapter ;
    }
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.JoinAdapter) adapter;
    else {
    	adapter = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.JoinAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.JoinAdapter) adapter ;
    }
  }
}
