/**
 */
package family.timedfsmmt.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Join</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see family.timedfsmmt.fsm.FsmPackage#getJoin()
 * @model
 * @generated
 */
public interface Join extends Pseudostate {
} // Join
