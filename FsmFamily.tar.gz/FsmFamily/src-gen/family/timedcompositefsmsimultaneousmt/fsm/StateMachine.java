/**
 */
package family.timedcompositefsmsimultaneousmt.fsm;

import org.eclipse.emf.common.util.EList;

import semantics.common.Context;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State Machine</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link family.timedcompositefsmsimultaneousmt.fsm.StateMachine#getStates <em>States</em>}</li>
 *   <li>{@link family.timedcompositefsmsimultaneousmt.fsm.StateMachine#getTransitions <em>Transitions</em>}</li>
 *   <li>{@link family.timedcompositefsmsimultaneousmt.fsm.StateMachine#getCurrentState <em>Current State</em>}</li>
 * </ul>
 *
 * @see family.timedcompositefsmsimultaneousmt.fsm.FsmPackage#getStateMachine()
 * @model
 * @generated
 */
public interface StateMachine extends NamedElement {
	/**
	 * Returns the value of the '<em><b>States</b></em>' containment reference list.
	 * The list contents are of type {@link family.timedcompositefsmsimultaneousmt.fsm.State}.
	 * It is bidirectional and its opposite is '{@link family.timedcompositefsmsimultaneousmt.fsm.State#getStateMachine <em>State Machine</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>States</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>States</em>' containment reference list.
	 * @see family.timedcompositefsmsimultaneousmt.fsm.FsmPackage#getStateMachine_States()
	 * @see family.timedcompositefsmsimultaneousmt.fsm.State#getStateMachine
	 * @model opposite="stateMachine" containment="true"
	 * @generated
	 */
	EList<State> getStates();

	/**
	 * Returns the value of the '<em><b>Transitions</b></em>' containment reference list.
	 * The list contents are of type {@link family.timedcompositefsmsimultaneousmt.fsm.Transition}.
	 * It is bidirectional and its opposite is '{@link family.timedcompositefsmsimultaneousmt.fsm.Transition#getStateMachine <em>State Machine</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transitions</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transitions</em>' containment reference list.
	 * @see family.timedcompositefsmsimultaneousmt.fsm.FsmPackage#getStateMachine_Transitions()
	 * @see family.timedcompositefsmsimultaneousmt.fsm.Transition#getStateMachine
	 * @model opposite="stateMachine" containment="true"
	 * @generated
	 */
	EList<Transition> getTransitions();

	/**
	 * Returns the value of the '<em><b>Current State</b></em>' reference list.
	 * The list contents are of type {@link family.timedcompositefsmsimultaneousmt.fsm.State}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Current State</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Current State</em>' reference list.
	 * @see family.timedcompositefsmsimultaneousmt.fsm.FsmPackage#getStateMachine_CurrentState()
	 * @model
	 * @generated
	 */
	EList<State> getCurrentState();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model contextDataType="family.timedcompositefsmsimultaneousmt.fsm.Context"
	 * @generated
	 */
	void eval(Context context, String filePath);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model contextDataType="family.timedcompositefsmsimultaneousmt.fsm.Context" eventsGroupMany="true"
	 * @generated
	 */
	void step(Context context, EList<String> eventsGroup);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model statesToRemoveMany="true"
	 * @generated
	 */
	void removeCurrentStates(EList<State> statesToRemove);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model statesToAddMany="true"
	 * @generated
	 */
	void addCurrentStates(EList<State> statesToAdd);

} // StateMachine
