/**
 */
package family.timedcompositefsmsimultaneousmt.fsm;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pseudostate</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see family.timedcompositefsmsimultaneousmt.fsm.FsmPackage#getPseudostate()
 * @model
 * @generated
 */
public interface Pseudostate extends State {
} // Pseudostate
