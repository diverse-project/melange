package family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt;

import compositefsm.fsm.Transition;
import family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory;
import family.flatfsmsimultaneousmt.fsm.State;
import family.flatfsmsimultaneousmt.fsm.StateMachine;
import family.flatfsmsimultaneousmt.fsm.Trigger;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EClass;

@SuppressWarnings("all")
public class TransitionAdapter extends EObjectAdapter<Transition> implements family.flatfsmsimultaneousmt.fsm.Transition {
  private FlatFsmSimultaneousMTAdaptersFactory adaptersFactory;
  
  public TransitionAdapter() {
    super(family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public State getTarget() {
    return (State) adaptersFactory.createAdapter(adaptee.getTarget(), eResource) ;
  }
  
  @Override
  public void setTarget(final State o) {
    if (o != null)
    	adaptee.setTarget(((family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.StateAdapter) o).getAdaptee()) ;
    else adaptee.setTarget(null) ;
  }
  
  @Override
  public State getSource() {
    return (State) adaptersFactory.createAdapter(adaptee.getSource(), eResource) ;
  }
  
  @Override
  public void setSource(final State o) {
    if (o != null)
    	adaptee.setSource(((family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.StateAdapter) o).getAdaptee()) ;
    else adaptee.setSource(null) ;
  }
  
  @Override
  public Trigger getTrigger() {
    return (Trigger) adaptersFactory.createAdapter(adaptee.getTrigger(), eResource) ;
  }
  
  @Override
  public void setTrigger(final Trigger o) {
    if (o != null)
    	adaptee.setTrigger(((family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TriggerAdapter) o).getAdaptee()) ;
    else adaptee.setTrigger(null) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return (StateMachine) adaptersFactory.createAdapter(adaptee.getStateMachine(), eResource) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    if (o != null)
    	adaptee.setStateMachine(((family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.StateMachineAdapter) o).getAdaptee()) ;
    else adaptee.setStateMachine(null) ;
  }
  
  protected final static String NAME_EDEFAULT = null;
  
  protected final static int INITIAL_TIME_EDEFAULT = 0;
  
  protected final static int FINAL_TIME_EDEFAULT = 0;
  
  @Override
  public EClass eClass() {
    return family.flatfsmsimultaneousmt.fsm.FsmPackage.eINSTANCE.getTransition();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__NAME:
    		return getName();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__TARGET:
    		return getTarget();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__SOURCE:
    		return getSource();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__TRIGGER:
    		return getTrigger();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__STATE_MACHINE:
    		return getStateMachine();
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__INITIAL_TIME:
    		return new java.lang.Integer(getInitialTime());
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__FINAL_TIME:
    		return new java.lang.Integer(getFinalTime());
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__NAME:
    		setName(NAME_EDEFAULT);
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__TARGET:
    		setTarget((family.flatfsmsimultaneousmt.fsm.State) null);
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__SOURCE:
    		setSource((family.flatfsmsimultaneousmt.fsm.State) null);
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__TRIGGER:
    		setTrigger((family.flatfsmsimultaneousmt.fsm.Trigger) null);
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__STATE_MACHINE:
    		setStateMachine((family.flatfsmsimultaneousmt.fsm.StateMachine) null);
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__INITIAL_TIME:
    		setInitialTime(INITIAL_TIME_EDEFAULT);
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__FINAL_TIME:
    		setFinalTime(FINAL_TIME_EDEFAULT);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__NAME:
    		return getName() != NAME_EDEFAULT;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__TARGET:
    		return getTarget() != null;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__SOURCE:
    		return getSource() != null;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__TRIGGER:
    		return getTrigger() != null;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__STATE_MACHINE:
    		return getStateMachine() != null;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__INITIAL_TIME:
    		return getInitialTime() != INITIAL_TIME_EDEFAULT;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__FINAL_TIME:
    		return getFinalTime() != FINAL_TIME_EDEFAULT;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__NAME:
    		setName((java.lang.String) newValue);
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__TARGET:
    		setTarget((family.flatfsmsimultaneousmt.fsm.State) newValue);
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__SOURCE:
    		setSource((family.flatfsmsimultaneousmt.fsm.State) newValue);
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__TRIGGER:
    		setTrigger((family.flatfsmsimultaneousmt.fsm.Trigger) newValue);
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__STATE_MACHINE:
    		setStateMachine((family.flatfsmsimultaneousmt.fsm.StateMachine) newValue);
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__INITIAL_TIME:
    		setInitialTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.flatfsmsimultaneousmt.fsm.FsmPackage.TRANSITION__FINAL_TIME:
    		setFinalTime(((java.lang.Integer) newValue).intValue());
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
