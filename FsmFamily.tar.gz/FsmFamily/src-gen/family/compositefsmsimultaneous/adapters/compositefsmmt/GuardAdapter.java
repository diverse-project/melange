package family.compositefsmsimultaneous.adapters.compositefsmmt;

import compositefsm.fsm.Guard;
import family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EClass;

@SuppressWarnings("all")
public class GuardAdapter extends EObjectAdapter<Guard> implements family.compositefsmmt.fsm.Guard {
  private CompositeFsmMTAdaptersFactory adaptersFactory;
  
  public GuardAdapter() {
    super(family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
  
  protected final static String EXPRESSION_EDEFAULT = null;
  
  @Override
  public EClass eClass() {
    return family.compositefsmmt.fsm.FsmPackage.eINSTANCE.getGuard();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.GUARD__EXPRESSION:
    		return getExpression();
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.GUARD__EXPRESSION:
    		setExpression(EXPRESSION_EDEFAULT);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.GUARD__EXPRESSION:
    		return getExpression() != EXPRESSION_EDEFAULT;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.GUARD__EXPRESSION:
    		setExpression((java.lang.String) newValue);
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
