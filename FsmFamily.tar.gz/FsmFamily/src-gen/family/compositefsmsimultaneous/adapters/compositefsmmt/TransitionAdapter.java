package family.compositefsmsimultaneous.adapters.compositefsmmt;

import compositefsm.fsm.Transition;
import family.compositefsmmt.fsm.Action;
import family.compositefsmmt.fsm.Guard;
import family.compositefsmmt.fsm.State;
import family.compositefsmmt.fsm.StateMachine;
import family.compositefsmmt.fsm.Trigger;
import family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EClass;

@SuppressWarnings("all")
public class TransitionAdapter extends EObjectAdapter<Transition> implements family.compositefsmmt.fsm.Transition {
  private CompositeFsmMTAdaptersFactory adaptersFactory;
  
  public TransitionAdapter() {
    super(family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public State getTarget() {
    return (State) adaptersFactory.createAdapter(adaptee.getTarget(), eResource) ;
  }
  
  @Override
  public void setTarget(final State o) {
    if (o != null)
    	adaptee.setTarget(((family.compositefsmsimultaneous.adapters.compositefsmmt.StateAdapter) o).getAdaptee()) ;
    else adaptee.setTarget(null) ;
  }
  
  @Override
  public State getSource() {
    return (State) adaptersFactory.createAdapter(adaptee.getSource(), eResource) ;
  }
  
  @Override
  public void setSource(final State o) {
    if (o != null)
    	adaptee.setSource(((family.compositefsmsimultaneous.adapters.compositefsmmt.StateAdapter) o).getAdaptee()) ;
    else adaptee.setSource(null) ;
  }
  
  @Override
  public Trigger getTrigger() {
    return (Trigger) adaptersFactory.createAdapter(adaptee.getTrigger(), eResource) ;
  }
  
  @Override
  public void setTrigger(final Trigger o) {
    if (o != null)
    	adaptee.setTrigger(((family.compositefsmsimultaneous.adapters.compositefsmmt.TriggerAdapter) o).getAdaptee()) ;
    else adaptee.setTrigger(null) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return (StateMachine) adaptersFactory.createAdapter(adaptee.getStateMachine(), eResource) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    if (o != null)
    	adaptee.setStateMachine(((family.compositefsmsimultaneous.adapters.compositefsmmt.StateMachineAdapter) o).getAdaptee()) ;
    else adaptee.setStateMachine(null) ;
  }
  
  @Override
  public Guard getGuard() {
    return (Guard) adaptersFactory.createAdapter(adaptee.getGuard(), eResource) ;
  }
  
  @Override
  public void setGuard(final Guard o) {
    if (o != null)
    	adaptee.setGuard(((family.compositefsmsimultaneous.adapters.compositefsmmt.GuardAdapter) o).getAdaptee()) ;
    else adaptee.setGuard(null) ;
  }
  
  @Override
  public Action getAction() {
    return (Action) adaptersFactory.createAdapter(adaptee.getAction(), eResource) ;
  }
  
  @Override
  public void setAction(final Action o) {
    if (o != null)
    	adaptee.setAction(((family.compositefsmsimultaneous.adapters.compositefsmmt.ActionAdapter) o).getAdaptee()) ;
    else adaptee.setAction(null) ;
  }
  
  protected final static String NAME_EDEFAULT = null;
  
  protected final static int INITIAL_TIME_EDEFAULT = 0;
  
  protected final static int FINAL_TIME_EDEFAULT = 0;
  
  @Override
  public EClass eClass() {
    return family.compositefsmmt.fsm.FsmPackage.eINSTANCE.getTransition();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__NAME:
    		return getName();
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__TARGET:
    		return getTarget();
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__SOURCE:
    		return getSource();
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__TRIGGER:
    		return getTrigger();
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__STATE_MACHINE:
    		return getStateMachine();
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__INITIAL_TIME:
    		return new java.lang.Integer(getInitialTime());
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__FINAL_TIME:
    		return new java.lang.Integer(getFinalTime());
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__GUARD:
    		return getGuard();
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__ACTION:
    		return getAction();
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__NAME:
    		setName(NAME_EDEFAULT);
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__TARGET:
    		setTarget((family.compositefsmmt.fsm.State) null);
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__SOURCE:
    		setSource((family.compositefsmmt.fsm.State) null);
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__TRIGGER:
    		setTrigger((family.compositefsmmt.fsm.Trigger) null);
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__STATE_MACHINE:
    		setStateMachine((family.compositefsmmt.fsm.StateMachine) null);
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__INITIAL_TIME:
    		setInitialTime(INITIAL_TIME_EDEFAULT);
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__FINAL_TIME:
    		setFinalTime(FINAL_TIME_EDEFAULT);
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__GUARD:
    		setGuard((family.compositefsmmt.fsm.Guard) null);
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__ACTION:
    		setAction((family.compositefsmmt.fsm.Action) null);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__NAME:
    		return getName() != NAME_EDEFAULT;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__TARGET:
    		return getTarget() != null;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__SOURCE:
    		return getSource() != null;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__TRIGGER:
    		return getTrigger() != null;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__STATE_MACHINE:
    		return getStateMachine() != null;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__INITIAL_TIME:
    		return getInitialTime() != INITIAL_TIME_EDEFAULT;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__FINAL_TIME:
    		return getFinalTime() != FINAL_TIME_EDEFAULT;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__GUARD:
    		return getGuard() != null;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__ACTION:
    		return getAction() != null;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__NAME:
    		setName((java.lang.String) newValue);
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__TARGET:
    		setTarget((family.compositefsmmt.fsm.State) newValue);
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__SOURCE:
    		setSource((family.compositefsmmt.fsm.State) newValue);
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__TRIGGER:
    		setTrigger((family.compositefsmmt.fsm.Trigger) newValue);
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__STATE_MACHINE:
    		setStateMachine((family.compositefsmmt.fsm.StateMachine) newValue);
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__INITIAL_TIME:
    		setInitialTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__FINAL_TIME:
    		setFinalTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__GUARD:
    		setGuard((family.compositefsmmt.fsm.Guard) newValue);
    		return;
    	case family.compositefsmmt.fsm.FsmPackage.TRANSITION__ACTION:
    		setAction((family.compositefsmmt.fsm.Action) newValue);
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
