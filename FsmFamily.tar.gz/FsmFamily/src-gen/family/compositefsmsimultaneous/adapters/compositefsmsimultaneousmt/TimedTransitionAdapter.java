package family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt;

import compositefsm.fsm.TimedTransition;
import family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeFsmSimultaneousMTAdaptersFactory;
import family.compositefsmsimultaneousmt.fsm.Action;
import family.compositefsmsimultaneousmt.fsm.Guard;
import family.compositefsmsimultaneousmt.fsm.State;
import family.compositefsmsimultaneousmt.fsm.StateMachine;
import family.compositefsmsimultaneousmt.fsm.Trigger;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EClass;

@SuppressWarnings("all")
public class TimedTransitionAdapter extends EObjectAdapter<TimedTransition> implements family.compositefsmsimultaneousmt.fsm.TimedTransition {
  private CompositeFsmSimultaneousMTAdaptersFactory adaptersFactory;
  
  public TimedTransitionAdapter() {
    super(family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeFsmSimultaneousMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeFsmSimultaneousMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public int getDuration() {
    return adaptee.getDuration() ;
  }
  
  @Override
  public void setDuration(final int o) {
    adaptee.setDuration(o) ;
  }
  
  @Override
  public State getTarget() {
    return (State) adaptersFactory.createAdapter(adaptee.getTarget(), eResource) ;
  }
  
  @Override
  public void setTarget(final State o) {
    if (o != null)
    	adaptee.setTarget(((family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.StateAdapter) o).getAdaptee()) ;
    else adaptee.setTarget(null) ;
  }
  
  @Override
  public State getSource() {
    return (State) adaptersFactory.createAdapter(adaptee.getSource(), eResource) ;
  }
  
  @Override
  public void setSource(final State o) {
    if (o != null)
    	adaptee.setSource(((family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.StateAdapter) o).getAdaptee()) ;
    else adaptee.setSource(null) ;
  }
  
  @Override
  public Trigger getTrigger() {
    return (Trigger) adaptersFactory.createAdapter(adaptee.getTrigger(), eResource) ;
  }
  
  @Override
  public void setTrigger(final Trigger o) {
    if (o != null)
    	adaptee.setTrigger(((family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.TriggerAdapter) o).getAdaptee()) ;
    else adaptee.setTrigger(null) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return (StateMachine) adaptersFactory.createAdapter(adaptee.getStateMachine(), eResource) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    if (o != null)
    	adaptee.setStateMachine(((family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.StateMachineAdapter) o).getAdaptee()) ;
    else adaptee.setStateMachine(null) ;
  }
  
  @Override
  public Guard getGuard() {
    return (Guard) adaptersFactory.createAdapter(adaptee.getGuard(), eResource) ;
  }
  
  @Override
  public void setGuard(final Guard o) {
    if (o != null)
    	adaptee.setGuard(((family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.GuardAdapter) o).getAdaptee()) ;
    else adaptee.setGuard(null) ;
  }
  
  @Override
  public Action getAction() {
    return (Action) adaptersFactory.createAdapter(adaptee.getAction(), eResource) ;
  }
  
  @Override
  public void setAction(final Action o) {
    if (o != null)
    	adaptee.setAction(((family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.ActionAdapter) o).getAdaptee()) ;
    else adaptee.setAction(null) ;
  }
  
  protected final static String NAME_EDEFAULT = null;
  
  protected final static int INITIAL_TIME_EDEFAULT = 0;
  
  protected final static int FINAL_TIME_EDEFAULT = 0;
  
  protected final static int DURATION_EDEFAULT = 0;
  
  @Override
  public EClass eClass() {
    return family.compositefsmsimultaneousmt.fsm.FsmPackage.eINSTANCE.getTimedTransition();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__NAME:
    		return getName();
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__TARGET:
    		return getTarget();
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__SOURCE:
    		return getSource();
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__TRIGGER:
    		return getTrigger();
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__STATE_MACHINE:
    		return getStateMachine();
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__INITIAL_TIME:
    		return new java.lang.Integer(getInitialTime());
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__FINAL_TIME:
    		return new java.lang.Integer(getFinalTime());
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__GUARD:
    		return getGuard();
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__ACTION:
    		return getAction();
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__DURATION:
    		return new java.lang.Integer(getDuration());
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__NAME:
    		setName(NAME_EDEFAULT);
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__TARGET:
    		setTarget((family.compositefsmsimultaneousmt.fsm.State) null);
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__SOURCE:
    		setSource((family.compositefsmsimultaneousmt.fsm.State) null);
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__TRIGGER:
    		setTrigger((family.compositefsmsimultaneousmt.fsm.Trigger) null);
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__STATE_MACHINE:
    		setStateMachine((family.compositefsmsimultaneousmt.fsm.StateMachine) null);
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__INITIAL_TIME:
    		setInitialTime(INITIAL_TIME_EDEFAULT);
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__FINAL_TIME:
    		setFinalTime(FINAL_TIME_EDEFAULT);
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__GUARD:
    		setGuard((family.compositefsmsimultaneousmt.fsm.Guard) null);
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__ACTION:
    		setAction((family.compositefsmsimultaneousmt.fsm.Action) null);
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__DURATION:
    		setDuration(DURATION_EDEFAULT);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__NAME:
    		return getName() != NAME_EDEFAULT;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__TARGET:
    		return getTarget() != null;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__SOURCE:
    		return getSource() != null;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__TRIGGER:
    		return getTrigger() != null;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__STATE_MACHINE:
    		return getStateMachine() != null;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__INITIAL_TIME:
    		return getInitialTime() != INITIAL_TIME_EDEFAULT;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__FINAL_TIME:
    		return getFinalTime() != FINAL_TIME_EDEFAULT;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__GUARD:
    		return getGuard() != null;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__ACTION:
    		return getAction() != null;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__DURATION:
    		return getDuration() != DURATION_EDEFAULT;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__NAME:
    		setName((java.lang.String) newValue);
    		return;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__TARGET:
    		setTarget((family.compositefsmsimultaneousmt.fsm.State) newValue);
    		return;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__SOURCE:
    		setSource((family.compositefsmsimultaneousmt.fsm.State) newValue);
    		return;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__TRIGGER:
    		setTrigger((family.compositefsmsimultaneousmt.fsm.Trigger) newValue);
    		return;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__STATE_MACHINE:
    		setStateMachine((family.compositefsmsimultaneousmt.fsm.StateMachine) newValue);
    		return;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__INITIAL_TIME:
    		setInitialTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__FINAL_TIME:
    		setFinalTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__GUARD:
    		setGuard((family.compositefsmsimultaneousmt.fsm.Guard) newValue);
    		return;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__ACTION:
    		setAction((family.compositefsmsimultaneousmt.fsm.Action) newValue);
    		return;
    	case family.compositefsmsimultaneousmt.fsm.FsmPackage.TIMED_TRANSITION__DURATION:
    		setDuration(((java.lang.Integer) newValue).intValue());
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
