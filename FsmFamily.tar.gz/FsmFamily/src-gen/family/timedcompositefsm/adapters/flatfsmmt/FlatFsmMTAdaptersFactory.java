package family.timedcompositefsm.adapters.flatfsmmt;

import family.timedcompositefsm.adapters.flatfsmmt.FinalStateAdapter;
import family.timedcompositefsm.adapters.flatfsmmt.ForkAdapter;
import family.timedcompositefsm.adapters.flatfsmmt.InitialStateAdapter;
import family.timedcompositefsm.adapters.flatfsmmt.JoinAdapter;
import family.timedcompositefsm.adapters.flatfsmmt.NamedElementAdapter;
import family.timedcompositefsm.adapters.flatfsmmt.PseudostateAdapter;
import family.timedcompositefsm.adapters.flatfsmmt.StateAdapter;
import family.timedcompositefsm.adapters.flatfsmmt.StateMachineAdapter;
import family.timedcompositefsm.adapters.flatfsmmt.TimedTransitionAdapter;
import family.timedcompositefsm.adapters.flatfsmmt.TransitionAdapter;
import family.timedcompositefsm.adapters.flatfsmmt.TriggerAdapter;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.WeakHashMap;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import timedcompositefsm.fsm.FinalState;
import timedcompositefsm.fsm.Fork;
import timedcompositefsm.fsm.InitialState;
import timedcompositefsm.fsm.Join;
import timedcompositefsm.fsm.NamedElement;
import timedcompositefsm.fsm.Pseudostate;
import timedcompositefsm.fsm.State;
import timedcompositefsm.fsm.StateMachine;
import timedcompositefsm.fsm.TimedTransition;
import timedcompositefsm.fsm.Transition;
import timedcompositefsm.fsm.Trigger;

@SuppressWarnings("all")
public class FlatFsmMTAdaptersFactory implements AdaptersFactory {
  private static FlatFsmMTAdaptersFactory instance;
  
  private WeakHashMap<EObject, EObjectAdapter> register;
  
  public FlatFsmMTAdaptersFactory() {
    register = new WeakHashMap();
  }
  
  public static FlatFsmMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new family.timedcompositefsm.adapters.flatfsmmt.FlatFsmMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o, final Resource res) {
    if (o instanceof timedcompositefsm.fsm.StateMachine){
    	return createStateMachineAdapter((timedcompositefsm.fsm.StateMachine) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.FinalState){
    	return createFinalStateAdapter((timedcompositefsm.fsm.FinalState) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.InitialState){
    	return createInitialStateAdapter((timedcompositefsm.fsm.InitialState) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.State){
    	return createStateAdapter((timedcompositefsm.fsm.State) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.TimedTransition){
    	return createTimedTransitionAdapter((timedcompositefsm.fsm.TimedTransition) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Transition){
    	return createTransitionAdapter((timedcompositefsm.fsm.Transition) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Fork){
    	return createForkAdapter((timedcompositefsm.fsm.Fork) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Join){
    	return createJoinAdapter((timedcompositefsm.fsm.Join) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Pseudostate){
    	return createPseudostateAdapter((timedcompositefsm.fsm.Pseudostate) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.NamedElement){
    	return createNamedElementAdapter((timedcompositefsm.fsm.NamedElement) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Trigger){
    	return createTriggerAdapter((timedcompositefsm.fsm.Trigger) o, res) ;
    }
    
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.flatfsmmt.NamedElementAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.flatfsmmt.NamedElementAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.flatfsmmt.NamedElementAdapter) adapter ;
    }
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.flatfsmmt.StateMachineAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.flatfsmmt.StateMachineAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.flatfsmmt.StateMachineAdapter) adapter ;
    }
  }
  
  public StateAdapter createStateAdapter(final State adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.flatfsmmt.StateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.flatfsmmt.StateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.flatfsmmt.StateAdapter) adapter ;
    }
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.flatfsmmt.FinalStateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.flatfsmmt.FinalStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.flatfsmmt.FinalStateAdapter) adapter ;
    }
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.flatfsmmt.InitialStateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.flatfsmmt.InitialStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.flatfsmmt.InitialStateAdapter) adapter ;
    }
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.flatfsmmt.TransitionAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.flatfsmmt.TransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.flatfsmmt.TransitionAdapter) adapter ;
    }
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.flatfsmmt.TimedTransitionAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.flatfsmmt.TimedTransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.flatfsmmt.TimedTransitionAdapter) adapter ;
    }
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.flatfsmmt.TriggerAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.flatfsmmt.TriggerAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.flatfsmmt.TriggerAdapter) adapter ;
    }
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.flatfsmmt.PseudostateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.flatfsmmt.PseudostateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.flatfsmmt.PseudostateAdapter) adapter ;
    }
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.flatfsmmt.ForkAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.flatfsmmt.ForkAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.flatfsmmt.ForkAdapter) adapter ;
    }
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.flatfsmmt.JoinAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.flatfsmmt.JoinAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.flatfsmmt.JoinAdapter) adapter ;
    }
  }
}
