package family.timedcompositefsm.adapters.flatfsmmt;

import family.flatfsmmt.fsm.State;
import family.flatfsmmt.fsm.StateMachine;
import family.flatfsmmt.fsm.Trigger;
import family.timedcompositefsm.adapters.flatfsmmt.FlatFsmMTAdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EClass;
import timedcompositefsm.fsm.TimedTransition;

@SuppressWarnings("all")
public class TimedTransitionAdapter extends EObjectAdapter<TimedTransition> implements family.flatfsmmt.fsm.TimedTransition {
  private FlatFsmMTAdaptersFactory adaptersFactory;
  
  public TimedTransitionAdapter() {
    super(family.timedcompositefsm.adapters.flatfsmmt.FlatFsmMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.timedcompositefsm.adapters.flatfsmmt.FlatFsmMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public int getDuration() {
    return adaptee.getDuration() ;
  }
  
  @Override
  public void setDuration(final int o) {
    adaptee.setDuration(o) ;
  }
  
  @Override
  public State getTarget() {
    return (State) adaptersFactory.createAdapter(adaptee.getTarget(), eResource) ;
  }
  
  @Override
  public void setTarget(final State o) {
    if (o != null)
    	adaptee.setTarget(((family.timedcompositefsm.adapters.flatfsmmt.StateAdapter) o).getAdaptee()) ;
    else adaptee.setTarget(null) ;
  }
  
  @Override
  public State getSource() {
    return (State) adaptersFactory.createAdapter(adaptee.getSource(), eResource) ;
  }
  
  @Override
  public void setSource(final State o) {
    if (o != null)
    	adaptee.setSource(((family.timedcompositefsm.adapters.flatfsmmt.StateAdapter) o).getAdaptee()) ;
    else adaptee.setSource(null) ;
  }
  
  @Override
  public Trigger getTrigger() {
    return (Trigger) adaptersFactory.createAdapter(adaptee.getTrigger(), eResource) ;
  }
  
  @Override
  public void setTrigger(final Trigger o) {
    if (o != null)
    	adaptee.setTrigger(((family.timedcompositefsm.adapters.flatfsmmt.TriggerAdapter) o).getAdaptee()) ;
    else adaptee.setTrigger(null) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return (StateMachine) adaptersFactory.createAdapter(adaptee.getStateMachine(), eResource) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    if (o != null)
    	adaptee.setStateMachine(((family.timedcompositefsm.adapters.flatfsmmt.StateMachineAdapter) o).getAdaptee()) ;
    else adaptee.setStateMachine(null) ;
  }
  
  protected final static String NAME_EDEFAULT = null;
  
  protected final static int INITIAL_TIME_EDEFAULT = 0;
  
  protected final static int FINAL_TIME_EDEFAULT = 0;
  
  protected final static int DURATION_EDEFAULT = 0;
  
  @Override
  public EClass eClass() {
    return family.flatfsmmt.fsm.FsmPackage.eINSTANCE.getTimedTransition();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__NAME:
    		return getName();
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__TARGET:
    		return getTarget();
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__SOURCE:
    		return getSource();
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__TRIGGER:
    		return getTrigger();
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__STATE_MACHINE:
    		return getStateMachine();
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__INITIAL_TIME:
    		return new java.lang.Integer(getInitialTime());
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__FINAL_TIME:
    		return new java.lang.Integer(getFinalTime());
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__DURATION:
    		return new java.lang.Integer(getDuration());
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__NAME:
    		setName(NAME_EDEFAULT);
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__TARGET:
    		setTarget((family.flatfsmmt.fsm.State) null);
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__SOURCE:
    		setSource((family.flatfsmmt.fsm.State) null);
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__TRIGGER:
    		setTrigger((family.flatfsmmt.fsm.Trigger) null);
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__STATE_MACHINE:
    		setStateMachine((family.flatfsmmt.fsm.StateMachine) null);
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__INITIAL_TIME:
    		setInitialTime(INITIAL_TIME_EDEFAULT);
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__FINAL_TIME:
    		setFinalTime(FINAL_TIME_EDEFAULT);
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__DURATION:
    		setDuration(DURATION_EDEFAULT);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__NAME:
    		return getName() != NAME_EDEFAULT;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__TARGET:
    		return getTarget() != null;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__SOURCE:
    		return getSource() != null;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__TRIGGER:
    		return getTrigger() != null;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__STATE_MACHINE:
    		return getStateMachine() != null;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__INITIAL_TIME:
    		return getInitialTime() != INITIAL_TIME_EDEFAULT;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__FINAL_TIME:
    		return getFinalTime() != FINAL_TIME_EDEFAULT;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__DURATION:
    		return getDuration() != DURATION_EDEFAULT;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__NAME:
    		setName((java.lang.String) newValue);
    		return;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__TARGET:
    		setTarget((family.flatfsmmt.fsm.State) newValue);
    		return;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__SOURCE:
    		setSource((family.flatfsmmt.fsm.State) newValue);
    		return;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__TRIGGER:
    		setTrigger((family.flatfsmmt.fsm.Trigger) newValue);
    		return;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__STATE_MACHINE:
    		setStateMachine((family.flatfsmmt.fsm.StateMachine) newValue);
    		return;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__INITIAL_TIME:
    		setInitialTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__FINAL_TIME:
    		setFinalTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.flatfsmmt.fsm.FsmPackage.TIMED_TRANSITION__DURATION:
    		setDuration(((java.lang.Integer) newValue).intValue());
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
