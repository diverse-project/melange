package family.timedcompositefsm.adapters.timedfsmmt;

import family.timedcompositefsm.adapters.timedfsmmt.FinalStateAdapter;
import family.timedcompositefsm.adapters.timedfsmmt.ForkAdapter;
import family.timedcompositefsm.adapters.timedfsmmt.InitialStateAdapter;
import family.timedcompositefsm.adapters.timedfsmmt.JoinAdapter;
import family.timedcompositefsm.adapters.timedfsmmt.NamedElementAdapter;
import family.timedcompositefsm.adapters.timedfsmmt.PseudostateAdapter;
import family.timedcompositefsm.adapters.timedfsmmt.StateAdapter;
import family.timedcompositefsm.adapters.timedfsmmt.StateMachineAdapter;
import family.timedcompositefsm.adapters.timedfsmmt.TimedTransitionAdapter;
import family.timedcompositefsm.adapters.timedfsmmt.TransitionAdapter;
import family.timedcompositefsm.adapters.timedfsmmt.TriggerAdapter;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.WeakHashMap;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import timedcompositefsm.fsm.FinalState;
import timedcompositefsm.fsm.Fork;
import timedcompositefsm.fsm.InitialState;
import timedcompositefsm.fsm.Join;
import timedcompositefsm.fsm.NamedElement;
import timedcompositefsm.fsm.Pseudostate;
import timedcompositefsm.fsm.State;
import timedcompositefsm.fsm.StateMachine;
import timedcompositefsm.fsm.TimedTransition;
import timedcompositefsm.fsm.Transition;
import timedcompositefsm.fsm.Trigger;

@SuppressWarnings("all")
public class TimedFsmMTAdaptersFactory implements AdaptersFactory {
  private static TimedFsmMTAdaptersFactory instance;
  
  private WeakHashMap<EObject, EObjectAdapter> register;
  
  public TimedFsmMTAdaptersFactory() {
    register = new WeakHashMap();
  }
  
  public static TimedFsmMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new family.timedcompositefsm.adapters.timedfsmmt.TimedFsmMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o, final Resource res) {
    if (o instanceof timedcompositefsm.fsm.StateMachine){
    	return createStateMachineAdapter((timedcompositefsm.fsm.StateMachine) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.FinalState){
    	return createFinalStateAdapter((timedcompositefsm.fsm.FinalState) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.InitialState){
    	return createInitialStateAdapter((timedcompositefsm.fsm.InitialState) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.State){
    	return createStateAdapter((timedcompositefsm.fsm.State) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.TimedTransition){
    	return createTimedTransitionAdapter((timedcompositefsm.fsm.TimedTransition) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Transition){
    	return createTransitionAdapter((timedcompositefsm.fsm.Transition) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Fork){
    	return createForkAdapter((timedcompositefsm.fsm.Fork) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Join){
    	return createJoinAdapter((timedcompositefsm.fsm.Join) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Pseudostate){
    	return createPseudostateAdapter((timedcompositefsm.fsm.Pseudostate) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.NamedElement){
    	return createNamedElementAdapter((timedcompositefsm.fsm.NamedElement) o, res) ;
    }
    if (o instanceof timedcompositefsm.fsm.Trigger){
    	return createTriggerAdapter((timedcompositefsm.fsm.Trigger) o, res) ;
    }
    
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.timedfsmmt.NamedElementAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.timedfsmmt.NamedElementAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.timedfsmmt.NamedElementAdapter) adapter ;
    }
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.timedfsmmt.StateMachineAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.timedfsmmt.StateMachineAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.timedfsmmt.StateMachineAdapter) adapter ;
    }
  }
  
  public StateAdapter createStateAdapter(final State adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.timedfsmmt.StateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.timedfsmmt.StateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.timedfsmmt.StateAdapter) adapter ;
    }
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.timedfsmmt.FinalStateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.timedfsmmt.FinalStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.timedfsmmt.FinalStateAdapter) adapter ;
    }
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.timedfsmmt.InitialStateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.timedfsmmt.InitialStateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.timedfsmmt.InitialStateAdapter) adapter ;
    }
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.timedfsmmt.TransitionAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.timedfsmmt.TransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.timedfsmmt.TransitionAdapter) adapter ;
    }
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.timedfsmmt.TimedTransitionAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.timedfsmmt.TimedTransitionAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.timedfsmmt.TimedTransitionAdapter) adapter ;
    }
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.timedfsmmt.TriggerAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.timedfsmmt.TriggerAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.timedfsmmt.TriggerAdapter) adapter ;
    }
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.timedfsmmt.PseudostateAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.timedfsmmt.PseudostateAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.timedfsmmt.PseudostateAdapter) adapter ;
    }
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.timedfsmmt.ForkAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.timedfsmmt.ForkAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.timedfsmmt.ForkAdapter) adapter ;
    }
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (family.timedcompositefsm.adapters.timedfsmmt.JoinAdapter) adapter;
    else {
    	adapter = new family.timedcompositefsm.adapters.timedfsmmt.JoinAdapter() ;
    	adapter.setAdaptee(adaptee) ;
    	adapter.setResource(res) ;
    	register.put(adaptee, adapter);
    	return (family.timedcompositefsm.adapters.timedfsmmt.JoinAdapter) adapter ;
    }
  }
}
