package family.timedcompositefsm.adapters.timedfsmmt;

import family.timedcompositefsm.adapters.timedfsmmt.TimedFsmMTAdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EClass;
import timedcompositefsm.fsm.Trigger;

@SuppressWarnings("all")
public class TriggerAdapter extends EObjectAdapter<Trigger> implements family.timedfsmmt.fsm.Trigger {
  private TimedFsmMTAdaptersFactory adaptersFactory;
  
  public TriggerAdapter() {
    super(family.timedcompositefsm.adapters.timedfsmmt.TimedFsmMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.timedcompositefsm.adapters.timedfsmmt.TimedFsmMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
  
  protected final static String EXPRESSION_EDEFAULT = null;
  
  @Override
  public EClass eClass() {
    return family.timedfsmmt.fsm.FsmPackage.eINSTANCE.getTrigger();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.timedfsmmt.fsm.FsmPackage.TRIGGER__EXPRESSION:
    		return getExpression();
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.timedfsmmt.fsm.FsmPackage.TRIGGER__EXPRESSION:
    		setExpression(EXPRESSION_EDEFAULT);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.timedfsmmt.fsm.FsmPackage.TRIGGER__EXPRESSION:
    		return getExpression() != EXPRESSION_EDEFAULT;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.timedfsmmt.fsm.FsmPackage.TRIGGER__EXPRESSION:
    		setExpression((java.lang.String) newValue);
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
