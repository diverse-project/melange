package family;

import family.FlatFsmMT;
import family.FlatFsmSimultaneousMT;
import family.TimedCompositeFsmMT;
import family.TimedCompositeFsmSimultaneousMT;
import family.TimedFsmMT;
import family.TimedFsmSimultaneousMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;

@SuppressWarnings("all")
public class TimedCompositeFsmSimultaneous implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static TimedCompositeFsmSimultaneous load(final String uri) {
    ResourceSet rs = new ResourceSetImpl() ;
    Resource res = rs.getResource(URI.createURI(uri), true) ;
    TimedCompositeFsmSimultaneous mm = new TimedCompositeFsmSimultaneous() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FlatFsmMT toFlatFsmMT() {
    family.timedcompositefsmsimultaneous.adapters.flatfsmmt.TimedCompositeFsmSimultaneousAdapter adaptee = new family.timedcompositefsmsimultaneous.adapters.flatfsmmt.TimedCompositeFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FlatFsmSimultaneousMT toFlatFsmSimultaneousMT() {
    family.timedcompositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedCompositeFsmSimultaneousAdapter adaptee = new family.timedcompositefsmsimultaneous.adapters.flatfsmsimultaneousmt.TimedCompositeFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public TimedFsmMT toTimedFsmMT() {
    family.timedcompositefsmsimultaneous.adapters.timedfsmmt.TimedCompositeFsmSimultaneousAdapter adaptee = new family.timedcompositefsmsimultaneous.adapters.timedfsmmt.TimedCompositeFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public TimedFsmSimultaneousMT toTimedFsmSimultaneousMT() {
    family.timedcompositefsmsimultaneous.adapters.timedfsmsimultaneousmt.TimedCompositeFsmSimultaneousAdapter adaptee = new family.timedcompositefsmsimultaneous.adapters.timedfsmsimultaneousmt.TimedCompositeFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public TimedCompositeFsmMT toTimedCompositeFsmMT() {
    family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedCompositeFsmSimultaneousAdapter adaptee = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedCompositeFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public TimedCompositeFsmSimultaneousMT toTimedCompositeFsmSimultaneousMT() {
    family.timedcompositefsmsimultaneous.adapters.timedcompositefsmsimultaneousmt.TimedCompositeFsmSimultaneousAdapter adaptee = new family.timedcompositefsmsimultaneous.adapters.timedcompositefsmsimultaneousmt.TimedCompositeFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
