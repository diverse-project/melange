package family;

import family.CompositeFsmMT;
import family.CompositeFsmSimultaneousMT;
import family.FlatFsmMT;
import family.FlatFsmSimultaneousMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;

@SuppressWarnings("all")
public class CompositeFsmSimultaneous implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static CompositeFsmSimultaneous load(final String uri) {
    ResourceSet rs = new ResourceSetImpl() ;
    Resource res = rs.getResource(URI.createURI(uri), true) ;
    CompositeFsmSimultaneous mm = new CompositeFsmSimultaneous() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FlatFsmMT toFlatFsmMT() {
    family.compositefsmsimultaneous.adapters.flatfsmmt.CompositeFsmSimultaneousAdapter adaptee = new family.compositefsmsimultaneous.adapters.flatfsmmt.CompositeFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FlatFsmSimultaneousMT toFlatFsmSimultaneousMT() {
    family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.CompositeFsmSimultaneousAdapter adaptee = new family.compositefsmsimultaneous.adapters.flatfsmsimultaneousmt.CompositeFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public CompositeFsmMT toCompositeFsmMT() {
    family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmSimultaneousAdapter adaptee = new family.compositefsmsimultaneous.adapters.compositefsmmt.CompositeFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public CompositeFsmSimultaneousMT toCompositeFsmSimultaneousMT() {
    family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeFsmSimultaneousAdapter adaptee = new family.compositefsmsimultaneous.adapters.compositefsmsimultaneousmt.CompositeFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
