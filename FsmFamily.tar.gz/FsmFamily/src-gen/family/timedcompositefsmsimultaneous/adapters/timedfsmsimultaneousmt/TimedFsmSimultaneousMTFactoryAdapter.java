package family.timedcompositefsmsimultaneous.adapters.timedfsmsimultaneousmt;

import family.timedcompositefsmsimultaneous.adapters.timedfsmsimultaneousmt.TimedFsmSimultaneousMTAdaptersFactory;
import family.timedfsmsimultaneousmt.fsm.FinalState;
import family.timedfsmsimultaneousmt.fsm.Fork;
import family.timedfsmsimultaneousmt.fsm.FsmFactory;
import family.timedfsmsimultaneousmt.fsm.FsmPackage;
import family.timedfsmsimultaneousmt.fsm.InitialState;
import family.timedfsmsimultaneousmt.fsm.Join;
import family.timedfsmsimultaneousmt.fsm.NamedElement;
import family.timedfsmsimultaneousmt.fsm.Pseudostate;
import family.timedfsmsimultaneousmt.fsm.State;
import family.timedfsmsimultaneousmt.fsm.StateMachine;
import family.timedfsmsimultaneousmt.fsm.TimedTransition;
import family.timedfsmsimultaneousmt.fsm.Transition;
import family.timedfsmsimultaneousmt.fsm.Trigger;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;

@SuppressWarnings("all")
public class TimedFsmSimultaneousMTFactoryAdapter extends EFactoryImpl implements FsmFactory {
  private TimedFsmSimultaneousMTAdaptersFactory adaptersFactory = family.timedcompositefsmsimultaneous.adapters.timedfsmsimultaneousmt.TimedFsmSimultaneousMTAdaptersFactory.getInstance();
  
  private timedcompositefsm.fsm.FsmFactory fsmAdaptee = timedcompositefsm.fsm.FsmFactory.eINSTANCE;
  
  @Override
  public NamedElement createNamedElement() {
    return adaptersFactory.createNamedElementAdapter(fsmAdaptee.createNamedElement(), null) ;
  }
  
  @Override
  public StateMachine createStateMachine() {
    return adaptersFactory.createStateMachineAdapter(fsmAdaptee.createStateMachine(), null) ;
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(fsmAdaptee.createState(), null) ;
  }
  
  @Override
  public FinalState createFinalState() {
    return adaptersFactory.createFinalStateAdapter(fsmAdaptee.createFinalState(), null) ;
  }
  
  @Override
  public InitialState createInitialState() {
    return adaptersFactory.createInitialStateAdapter(fsmAdaptee.createInitialState(), null) ;
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(fsmAdaptee.createTransition(), null) ;
  }
  
  @Override
  public TimedTransition createTimedTransition() {
    return adaptersFactory.createTimedTransitionAdapter(fsmAdaptee.createTimedTransition(), null) ;
  }
  
  @Override
  public Trigger createTrigger() {
    return adaptersFactory.createTriggerAdapter(fsmAdaptee.createTrigger(), null) ;
  }
  
  @Override
  public Pseudostate createPseudostate() {
    return adaptersFactory.createPseudostateAdapter(fsmAdaptee.createPseudostate(), null) ;
  }
  
  @Override
  public Fork createFork() {
    return adaptersFactory.createForkAdapter(fsmAdaptee.createFork(), null) ;
  }
  
  @Override
  public Join createJoin() {
    return adaptersFactory.createJoinAdapter(fsmAdaptee.createJoin(), null) ;
  }
  
  @Override
  public EPackage getEPackage() {
    return getFsmPackage();
  }
  
  public FsmPackage getFsmPackage() {
    return family.timedfsmsimultaneousmt.fsm.FsmPackage.eINSTANCE;
  }
}
