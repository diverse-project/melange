package family.timedcompositefsmsimultaneous.adapters.timedfsmsimultaneousmt;

import family.TimedFsmSimultaneousMT;
import family.timedfsmsimultaneousmt.fsm.FsmFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;
import org.eclipse.emf.common.util.URI;

@SuppressWarnings("all")
public class TimedCompositeFsmSimultaneousAdapter extends ResourceAdapter implements TimedFsmSimultaneousMT {
  public TimedCompositeFsmSimultaneousAdapter() {
    super(family.timedcompositefsmsimultaneous.adapters.timedfsmsimultaneousmt.TimedFsmSimultaneousMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FsmFactory getFactory() {
    return new family.timedcompositefsmsimultaneous.adapters.timedfsmsimultaneousmt.TimedFsmSimultaneousMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(URI.createURI(uri));
    this.adaptee.save(null);
  }
}
