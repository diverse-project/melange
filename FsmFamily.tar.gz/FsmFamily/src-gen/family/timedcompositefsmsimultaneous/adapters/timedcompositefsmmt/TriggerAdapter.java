package family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt;

import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedCompositeFsmMTAdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EClass;
import timedcompositefsm.fsm.Trigger;

@SuppressWarnings("all")
public class TriggerAdapter extends EObjectAdapter<Trigger> implements family.timedcompositefsmmt.fsm.Trigger {
  private TimedCompositeFsmMTAdaptersFactory adaptersFactory;
  
  public TriggerAdapter() {
    super(family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedCompositeFsmMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedCompositeFsmMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
  
  protected final static String EXPRESSION_EDEFAULT = null;
  
  @Override
  public EClass eClass() {
    return family.timedcompositefsmmt.fsm.FsmPackage.eINSTANCE.getTrigger();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.timedcompositefsmmt.fsm.FsmPackage.TRIGGER__EXPRESSION:
    		return getExpression();
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.timedcompositefsmmt.fsm.FsmPackage.TRIGGER__EXPRESSION:
    		setExpression(EXPRESSION_EDEFAULT);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.timedcompositefsmmt.fsm.FsmPackage.TRIGGER__EXPRESSION:
    		return getExpression() != EXPRESSION_EDEFAULT;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.timedcompositefsmmt.fsm.FsmPackage.TRIGGER__EXPRESSION:
    		setExpression((java.lang.String) newValue);
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
