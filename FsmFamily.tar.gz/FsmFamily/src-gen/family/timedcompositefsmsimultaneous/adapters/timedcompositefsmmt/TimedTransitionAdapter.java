package family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt;

import family.timedcompositefsmmt.fsm.State;
import family.timedcompositefsmmt.fsm.StateMachine;
import family.timedcompositefsmmt.fsm.Trigger;
import family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedCompositeFsmMTAdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EClass;
import semantics.common.Context;
import timedcompositefsm.fsm.TimedTransition;

@SuppressWarnings("all")
public class TimedTransitionAdapter extends EObjectAdapter<TimedTransition> implements family.timedcompositefsmmt.fsm.TimedTransition {
  private TimedCompositeFsmMTAdaptersFactory adaptersFactory;
  
  public TimedTransitionAdapter() {
    super(family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedCompositeFsmMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TimedCompositeFsmMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public int getTime() {
    return adaptee.getTime() ;
  }
  
  @Override
  public void setTime(final int o) {
    adaptee.setTime(o) ;
  }
  
  @Override
  public int getDuration() {
    return adaptee.getDuration() ;
  }
  
  @Override
  public void setDuration(final int o) {
    adaptee.setDuration(o) ;
  }
  
  @Override
  public State getTarget() {
    return (State) adaptersFactory.createAdapter(adaptee.getTarget(), eResource) ;
  }
  
  @Override
  public void setTarget(final State o) {
    if (o != null)
    	adaptee.setTarget(((family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.StateAdapter) o).getAdaptee()) ;
    else adaptee.setTarget(null) ;
  }
  
  @Override
  public State getSource() {
    return (State) adaptersFactory.createAdapter(adaptee.getSource(), eResource) ;
  }
  
  @Override
  public void setSource(final State o) {
    if (o != null)
    	adaptee.setSource(((family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.StateAdapter) o).getAdaptee()) ;
    else adaptee.setSource(null) ;
  }
  
  @Override
  public Trigger getTrigger() {
    return (Trigger) adaptersFactory.createAdapter(adaptee.getTrigger(), eResource) ;
  }
  
  @Override
  public void setTrigger(final Trigger o) {
    if (o != null)
    	adaptee.setTrigger(((family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.TriggerAdapter) o).getAdaptee()) ;
    else adaptee.setTrigger(null) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return (StateMachine) adaptersFactory.createAdapter(adaptee.getStateMachine(), eResource) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    if (o != null)
    	adaptee.setStateMachine(((family.timedcompositefsmsimultaneous.adapters.timedcompositefsmmt.StateMachineAdapter) o).getAdaptee()) ;
    else adaptee.setStateMachine(null) ;
  }
  
  @Override
  public void process(final Context context) {
    semantics.timedcomposite.simultaneous.TransitionAspect.process(adaptee, context
    ) ;
  }
  
  protected final static String NAME_EDEFAULT = null;
  
  protected final static int INITIAL_TIME_EDEFAULT = 0;
  
  protected final static int FINAL_TIME_EDEFAULT = 0;
  
  protected final static int TIME_EDEFAULT = 0;
  
  protected final static int DURATION_EDEFAULT = 0;
  
  @Override
  public EClass eClass() {
    return family.timedcompositefsmmt.fsm.FsmPackage.eINSTANCE.getTimedTransition();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__NAME:
    		return getName();
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__TARGET:
    		return getTarget();
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__SOURCE:
    		return getSource();
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__TRIGGER:
    		return getTrigger();
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__STATE_MACHINE:
    		return getStateMachine();
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__INITIAL_TIME:
    		return new java.lang.Integer(getInitialTime());
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__FINAL_TIME:
    		return new java.lang.Integer(getFinalTime());
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__TIME:
    		return new java.lang.Integer(getTime());
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__DURATION:
    		return new java.lang.Integer(getDuration());
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__NAME:
    		setName(NAME_EDEFAULT);
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__TARGET:
    		setTarget((family.timedcompositefsmmt.fsm.State) null);
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__SOURCE:
    		setSource((family.timedcompositefsmmt.fsm.State) null);
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__TRIGGER:
    		setTrigger((family.timedcompositefsmmt.fsm.Trigger) null);
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__STATE_MACHINE:
    		setStateMachine((family.timedcompositefsmmt.fsm.StateMachine) null);
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__INITIAL_TIME:
    		setInitialTime(INITIAL_TIME_EDEFAULT);
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__FINAL_TIME:
    		setFinalTime(FINAL_TIME_EDEFAULT);
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__TIME:
    		setTime(TIME_EDEFAULT);
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__DURATION:
    		setDuration(DURATION_EDEFAULT);
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__NAME:
    		return getName() != NAME_EDEFAULT;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__TARGET:
    		return getTarget() != null;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__SOURCE:
    		return getSource() != null;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__TRIGGER:
    		return getTrigger() != null;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__STATE_MACHINE:
    		return getStateMachine() != null;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__INITIAL_TIME:
    		return getInitialTime() != INITIAL_TIME_EDEFAULT;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__FINAL_TIME:
    		return getFinalTime() != FINAL_TIME_EDEFAULT;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__TIME:
    		return getTime() != TIME_EDEFAULT;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__DURATION:
    		return getDuration() != DURATION_EDEFAULT;
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__NAME:
    		setName((java.lang.String) newValue);
    		return;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__TARGET:
    		setTarget((family.timedcompositefsmmt.fsm.State) newValue);
    		return;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__SOURCE:
    		setSource((family.timedcompositefsmmt.fsm.State) newValue);
    		return;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__TRIGGER:
    		setTrigger((family.timedcompositefsmmt.fsm.Trigger) newValue);
    		return;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__STATE_MACHINE:
    		setStateMachine((family.timedcompositefsmmt.fsm.StateMachine) newValue);
    		return;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__INITIAL_TIME:
    		setInitialTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__FINAL_TIME:
    		setFinalTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__TIME:
    		setTime(((java.lang.Integer) newValue).intValue());
    		return;
    	case family.timedcompositefsmmt.fsm.FsmPackage.TIMED_TRANSITION__DURATION:
    		setDuration(((java.lang.Integer) newValue).intValue());
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
