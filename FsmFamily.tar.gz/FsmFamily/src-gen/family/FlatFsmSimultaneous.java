package family;

import family.FlatFsmMT;
import family.FlatFsmSimultaneousMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;

@SuppressWarnings("all")
public class FlatFsmSimultaneous implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static FlatFsmSimultaneous load(final String uri) {
    ResourceSet rs = new ResourceSetImpl() ;
    Resource res = rs.getResource(URI.createURI(uri), true) ;
    FlatFsmSimultaneous mm = new FlatFsmSimultaneous() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FlatFsmMT toFlatFsmMT() {
    family.flatfsmsimultaneous.adapters.flatfsmmt.FlatFsmSimultaneousAdapter adaptee = new family.flatfsmsimultaneous.adapters.flatfsmmt.FlatFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FlatFsmSimultaneousMT toFlatFsmSimultaneousMT() {
    family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousAdapter adaptee = new family.flatfsmsimultaneous.adapters.flatfsmsimultaneousmt.FlatFsmSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
