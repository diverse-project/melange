package family.timedfsmsimultaneous.adapters.timedfsmmt;

import family.timedfsmmt.fsm.FinalState;
import family.timedfsmmt.fsm.Fork;
import family.timedfsmmt.fsm.FsmFactory;
import family.timedfsmmt.fsm.FsmPackage;
import family.timedfsmmt.fsm.InitialState;
import family.timedfsmmt.fsm.Join;
import family.timedfsmmt.fsm.NamedElement;
import family.timedfsmmt.fsm.Pseudostate;
import family.timedfsmmt.fsm.State;
import family.timedfsmmt.fsm.StateMachine;
import family.timedfsmmt.fsm.TimedTransition;
import family.timedfsmmt.fsm.Transition;
import family.timedfsmmt.fsm.Trigger;
import family.timedfsmsimultaneous.adapters.timedfsmmt.TimedFsmMTAdaptersFactory;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;

@SuppressWarnings("all")
public class TimedFsmMTFactoryAdapter extends EFactoryImpl implements FsmFactory {
  private TimedFsmMTAdaptersFactory adaptersFactory = family.timedfsmsimultaneous.adapters.timedfsmmt.TimedFsmMTAdaptersFactory.getInstance();
  
  private timedfsm.fsm.FsmFactory fsmAdaptee = timedfsm.fsm.FsmFactory.eINSTANCE;
  
  @Override
  public NamedElement createNamedElement() {
    return adaptersFactory.createNamedElementAdapter(fsmAdaptee.createNamedElement(), null) ;
  }
  
  @Override
  public StateMachine createStateMachine() {
    return adaptersFactory.createStateMachineAdapter(fsmAdaptee.createStateMachine(), null) ;
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(fsmAdaptee.createState(), null) ;
  }
  
  @Override
  public FinalState createFinalState() {
    return adaptersFactory.createFinalStateAdapter(fsmAdaptee.createFinalState(), null) ;
  }
  
  @Override
  public InitialState createInitialState() {
    return adaptersFactory.createInitialStateAdapter(fsmAdaptee.createInitialState(), null) ;
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(fsmAdaptee.createTransition(), null) ;
  }
  
  @Override
  public TimedTransition createTimedTransition() {
    return adaptersFactory.createTimedTransitionAdapter(fsmAdaptee.createTimedTransition(), null) ;
  }
  
  @Override
  public Trigger createTrigger() {
    return adaptersFactory.createTriggerAdapter(fsmAdaptee.createTrigger(), null) ;
  }
  
  @Override
  public Pseudostate createPseudostate() {
    return adaptersFactory.createPseudostateAdapter(fsmAdaptee.createPseudostate(), null) ;
  }
  
  @Override
  public Fork createFork() {
    return adaptersFactory.createForkAdapter(fsmAdaptee.createFork(), null) ;
  }
  
  @Override
  public Join createJoin() {
    return adaptersFactory.createJoinAdapter(fsmAdaptee.createJoin(), null) ;
  }
  
  @Override
  public EPackage getEPackage() {
    return getFsmPackage();
  }
  
  public FsmPackage getFsmPackage() {
    return family.timedfsmmt.fsm.FsmPackage.eINSTANCE;
  }
}
