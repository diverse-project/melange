package family.timedfsmsimultaneous.adapters.timedfsmmt;

import family.timedfsmmt.fsm.State;
import family.timedfsmmt.fsm.Transition;
import family.timedfsmsimultaneous.adapters.timedfsmmt.TimedFsmMTAdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import java.util.Collection;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import semantics.common.Context;
import timedfsm.fsm.StateMachine;

@SuppressWarnings("all")
public class StateMachineAdapter extends EObjectAdapter<StateMachine> implements family.timedfsmmt.fsm.StateMachine {
  private TimedFsmMTAdaptersFactory adaptersFactory;
  
  public StateMachineAdapter() {
    super(family.timedfsmsimultaneous.adapters.timedfsmmt.TimedFsmMTAdaptersFactory.getInstance()) ;
    adaptersFactory = family.timedfsmsimultaneous.adapters.timedfsmmt.TimedFsmMTAdaptersFactory.getInstance() ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  private EList<State> states;
  
  @Override
  public EList<State> getStates() {
    if (states == null)
    	states = fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), adaptersFactory) ;
    return states;
  }
  
  private EList<Transition> transitions;
  
  @Override
  public EList<Transition> getTransitions() {
    if (transitions == null)
    	transitions = fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getTransitions(), adaptersFactory) ;
    return transitions;
  }
  
  @Override
  public void eval(final Context context, final String filePath) {
    semantics.timed.simultaneous.StateMachineAspect.eval(adaptee, context
    , filePath
    ) ;
  }
  
  protected final static String NAME_EDEFAULT = null;
  
  @Override
  public EClass eClass() {
    return family.timedfsmmt.fsm.FsmPackage.eINSTANCE.getStateMachine();
  }
  
  @Override
  public Object eGet(final int featureID, final boolean resolve, final boolean coreType) {
    switch (featureID) {
    	case family.timedfsmmt.fsm.FsmPackage.STATE_MACHINE__NAME:
    		return getName();
    	case family.timedfsmmt.fsm.FsmPackage.STATE_MACHINE__STATES:
    		return getStates();
    	case family.timedfsmmt.fsm.FsmPackage.STATE_MACHINE__TRANSITIONS:
    		return getTransitions();
    }
    
    return super.eGet(featureID, resolve, coreType);
  }
  
  @Override
  public void eUnset(final int featureID) {
    switch (featureID) {
    	case family.timedfsmmt.fsm.FsmPackage.STATE_MACHINE__NAME:
    		setName(NAME_EDEFAULT);
    	case family.timedfsmmt.fsm.FsmPackage.STATE_MACHINE__STATES:
    		getStates().clear();
    	case family.timedfsmmt.fsm.FsmPackage.STATE_MACHINE__TRANSITIONS:
    		getTransitions().clear();
    	return;
    }
    
    super.eUnset(featureID);
  }
  
  @Override
  public boolean eIsSet(final int featureID) {
    switch (featureID) {
    	case family.timedfsmmt.fsm.FsmPackage.STATE_MACHINE__NAME:
    		return getName() != NAME_EDEFAULT;
    	case family.timedfsmmt.fsm.FsmPackage.STATE_MACHINE__STATES:
    		return getStates() != null && !getStates().isEmpty();
    	case family.timedfsmmt.fsm.FsmPackage.STATE_MACHINE__TRANSITIONS:
    		return getTransitions() != null && !getTransitions().isEmpty();
    }
    
    return super.eIsSet(featureID);
  }
  
  @Override
  public void eSet(final int featureID, final Object newValue) {
    switch (featureID) {
    	case family.timedfsmmt.fsm.FsmPackage.STATE_MACHINE__NAME:
    		setName((java.lang.String) newValue);
    		return;
    	case family.timedfsmmt.fsm.FsmPackage.STATE_MACHINE__STATES:
    		getStates().clear();
    		getStates().addAll((Collection) newValue);
    		return;
    	case family.timedfsmmt.fsm.FsmPackage.STATE_MACHINE__TRANSITIONS:
    		getTransitions().clear();
    		getTransitions().addAll((Collection) newValue);
    		return;
    }
    
    super.eSet(featureID, newValue);
  }
}
