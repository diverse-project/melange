package family.timedfsmsimultaneous.adapters.flatfsmmt;

import family.FlatFsmMT;
import family.flatfsmmt.fsm.FsmFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;
import org.eclipse.emf.common.util.URI;

@SuppressWarnings("all")
public class TimedFsmSimultaneousAdapter extends ResourceAdapter implements FlatFsmMT {
  public TimedFsmSimultaneousAdapter() {
    super(family.timedfsmsimultaneous.adapters.flatfsmmt.FlatFsmMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FsmFactory getFactory() {
    return new family.timedfsmsimultaneous.adapters.flatfsmmt.FlatFsmMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(URI.createURI(uri));
    this.adaptee.save(null);
  }
}
