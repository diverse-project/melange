/**
 */
package root;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super A</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see root.RootPackage#getSuperA()
 * @model
 * @generated
 */
public interface SuperA extends EObject {
} // SuperA
