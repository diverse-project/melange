/**
 */
package root.impl;

import org.eclipse.emf.ecore.EClass;

import root.RootPackage;
import root.SubA;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sub A</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SubAImpl extends AImpl implements SubA {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SubAImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RootPackage.Literals.SUB_A;
	}

} //SubAImpl
