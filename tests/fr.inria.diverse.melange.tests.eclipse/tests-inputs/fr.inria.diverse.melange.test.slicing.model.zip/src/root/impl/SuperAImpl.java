/**
 */
package root.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import root.RootPackage;
import root.SuperA;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super A</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SuperAImpl extends MinimalEObjectImpl.Container implements SuperA {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperAImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RootPackage.Literals.SUPER_A;
	}

} //SuperAImpl
