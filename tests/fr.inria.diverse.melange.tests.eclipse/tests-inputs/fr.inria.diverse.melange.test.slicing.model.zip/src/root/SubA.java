/**
 */
package root;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub A</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see root.RootPackage#getSubA()
 * @model
 * @generated
 */
public interface SubA extends A {
} // SubA
