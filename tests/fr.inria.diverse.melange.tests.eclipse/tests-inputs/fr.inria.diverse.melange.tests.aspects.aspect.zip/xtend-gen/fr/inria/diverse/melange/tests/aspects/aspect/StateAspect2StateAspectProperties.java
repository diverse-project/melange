package fr.inria.diverse.melange.tests.aspects.aspect;

@SuppressWarnings("all")
public class StateAspect2StateAspectProperties {
  public String foo = "foo2";
}
