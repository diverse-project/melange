package fr.inria.diverse.melange.tests.aspects.aspect;

@SuppressWarnings("all")
public class StateAspect1StateAspectProperties {
  public String foo = "foo1";
}
