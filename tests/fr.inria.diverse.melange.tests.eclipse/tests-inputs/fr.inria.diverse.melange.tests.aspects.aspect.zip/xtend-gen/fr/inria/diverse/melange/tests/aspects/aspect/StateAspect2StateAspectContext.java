package fr.inria.diverse.melange.tests.aspects.aspect;

import fr.inria.diverse.melange.tests.aspects.aspect.StateAspect2StateAspectProperties;
import java.util.Map;
import timed.fsm.State;

@SuppressWarnings("all")
public class StateAspect2StateAspectContext {
  public final static StateAspect2StateAspectContext INSTANCE = new StateAspect2StateAspectContext();
  
  public static StateAspect2StateAspectProperties getSelf(final State _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.aspects.aspect.StateAspect2StateAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<State, StateAspect2StateAspectProperties> map = new java.util.WeakHashMap<timed.fsm.State, fr.inria.diverse.melange.tests.aspects.aspect.StateAspect2StateAspectProperties>();
  
  public Map<State, StateAspect2StateAspectProperties> getMap() {
    return map;
  }
}
