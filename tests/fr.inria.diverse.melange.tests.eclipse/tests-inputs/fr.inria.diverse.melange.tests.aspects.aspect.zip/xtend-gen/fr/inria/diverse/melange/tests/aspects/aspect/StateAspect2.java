package fr.inria.diverse.melange.tests.aspects.aspect;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.aspects.aspect.StateAspect2StateAspectProperties;
import org.eclipse.xtend2.lib.StringConcatenation;
import timed.fsm.State;

@Aspect(className = State.class)
@SuppressWarnings("all")
public class StateAspect2 {
  public static String bar(final State _self) {
    final fr.inria.diverse.melange.tests.aspects.aspect.StateAspect2StateAspectProperties _self_ = fr.inria.diverse.melange.tests.aspects.aspect.StateAspect2StateAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_bar(_self_, _self);;
    return (java.lang.String)result;
  }
  
  public static State barbar(final State _self, final State arg) {
    final fr.inria.diverse.melange.tests.aspects.aspect.StateAspect2StateAspectProperties _self_ = fr.inria.diverse.melange.tests.aspects.aspect.StateAspect2StateAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_barbar(_self_, _self,arg);;
    return (timed.fsm.State)result;
  }
  
  public static String foo(final State _self) {
    final fr.inria.diverse.melange.tests.aspects.aspect.StateAspect2StateAspectProperties _self_ = fr.inria.diverse.melange.tests.aspects.aspect.StateAspect2StateAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_foo(_self_, _self);;
    return (java.lang.String)result;
  }
  
  public static void foo(final State _self, final String foo) {
    final fr.inria.diverse.melange.tests.aspects.aspect.StateAspect2StateAspectProperties _self_ = fr.inria.diverse.melange.tests.aspects.aspect.StateAspect2StateAspectContext.getSelf(_self);
    _privk3_foo(_self_, _self,foo);;
  }
  
  protected static String _privk3_bar(final StateAspect2StateAspectProperties _self_, final State _self) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("bar2");
    return _builder.toString();
  }
  
  protected static State _privk3_barbar(final StateAspect2StateAspectProperties _self_, final State _self, final State arg) {
    return null;
  }
  
  protected static String _privk3_foo(final StateAspect2StateAspectProperties _self_, final State _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getFoo") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (java.lang.String) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.foo;
  }
  
  protected static void _privk3_foo(final StateAspect2StateAspectProperties _self_, final State _self, final String foo) {
    _self_.foo = foo; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setFoo")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, foo);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
