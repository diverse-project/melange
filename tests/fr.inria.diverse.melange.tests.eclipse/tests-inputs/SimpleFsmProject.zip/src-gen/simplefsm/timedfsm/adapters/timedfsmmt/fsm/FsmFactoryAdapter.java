package simplefsm.timedfsm.adapters.timedfsmmt.fsm;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import simplefsm.timedfsmmt.fsm.FSM;
import simplefsm.timedfsmmt.fsm.FsmFactory;
import simplefsm.timedfsmmt.fsm.FsmPackage;
import simplefsm.timedfsmmt.fsm.State;
import simplefsm.timedfsmmt.fsm.Transition;
import timedfsm.fsm.TimedfsmFactory;

@SuppressWarnings("all")
public class FsmFactoryAdapter extends EFactoryImpl implements FsmFactory {
  private simplefsm.timedfsm.adapters.timedfsmmt.TimedFsmMTAdaptersFactory adaptersFactory = simplefsm.timedfsm.adapters.timedfsmmt.TimedFsmMTAdaptersFactory.getInstance();
  
  private TimedfsmFactory fsmAdaptee = timedfsm.fsm.TimedfsmFactory.eINSTANCE;
  
  @Override
  public FSM createFSM() {
    return adaptersFactory.createFSMAdapter(fsmAdaptee.createFSM(), null);
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(fsmAdaptee.createState(), null);
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(fsmAdaptee.createTransition(), null);
  }
  
  @Override
  public EPackage getEPackage() {
    return getFsmPackage();
  }
  
  public FsmPackage getFsmPackage() {
    return simplefsm.timedfsmmt.fsm.FsmPackage.eINSTANCE;
  }
}
