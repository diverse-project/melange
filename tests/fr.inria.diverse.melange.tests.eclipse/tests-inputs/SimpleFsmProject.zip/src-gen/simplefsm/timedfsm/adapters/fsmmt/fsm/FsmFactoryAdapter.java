package simplefsm.timedfsm.adapters.fsmmt.fsm;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import simplefsm.fsmmt.fsm.FSM;
import simplefsm.fsmmt.fsm.FsmFactory;
import simplefsm.fsmmt.fsm.FsmPackage;
import simplefsm.fsmmt.fsm.State;
import simplefsm.fsmmt.fsm.Transition;
import timedfsm.fsm.TimedfsmFactory;

@SuppressWarnings("all")
public class FsmFactoryAdapter extends EFactoryImpl implements FsmFactory {
  private simplefsm.timedfsm.adapters.fsmmt.FsmMTAdaptersFactory adaptersFactory = simplefsm.timedfsm.adapters.fsmmt.FsmMTAdaptersFactory.getInstance();
  
  private TimedfsmFactory fsmAdaptee = timedfsm.fsm.TimedfsmFactory.eINSTANCE;
  
  @Override
  public FSM createFSM() {
    return adaptersFactory.createFSMAdapter(fsmAdaptee.createFSM(), null);
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(fsmAdaptee.createState(), null);
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(fsmAdaptee.createTransition(), null);
  }
  
  @Override
  public EPackage getEPackage() {
    return getFsmPackage();
  }
  
  public FsmPackage getFsmPackage() {
    return simplefsm.fsmmt.fsm.FsmPackage.eINSTANCE;
  }
}
