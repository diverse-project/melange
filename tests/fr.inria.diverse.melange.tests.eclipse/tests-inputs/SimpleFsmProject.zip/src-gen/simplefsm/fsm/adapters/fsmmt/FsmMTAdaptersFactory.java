package simplefsm.fsm.adapters.fsmmt;

import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import fsm.FSM;
import fsm.State;
import fsm.Transition;
import java.util.WeakHashMap;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FsmMTAdaptersFactory implements AdaptersFactory {
  private static simplefsm.fsm.adapters.fsmmt.FsmMTAdaptersFactory instance;
  
  public static simplefsm.fsm.adapters.fsmmt.FsmMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new simplefsm.fsm.adapters.fsmmt.FsmMTAdaptersFactory();
    }
    return instance;
  }
  
  private WeakHashMap<EObject, EObjectAdapter> register;
  
  public FsmMTAdaptersFactory() {
    register = new WeakHashMap();
  }
  
  public EObjectAdapter createAdapter(final EObject o, final Resource res) {
    if (o instanceof fsm.FSM){
    	return createFSMAdapter((fsm.FSM) o, res);
    }
    if (o instanceof fsm.State){
    	return createStateAdapter((fsm.State) o, res);
    }
    if (o instanceof fsm.Transition){
    	return createTransitionAdapter((fsm.Transition) o, res);
    }
    
    return null;
  }
  
  public simplefsm.fsm.adapters.fsmmt.fsm.FSMAdapter createFSMAdapter(final FSM adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (simplefsm.fsm.adapters.fsmmt.fsm.FSMAdapter) adapter;
    else {
    	adapter = new simplefsm.fsm.adapters.fsmmt.fsm.FSMAdapter();
    	adapter.setAdaptee(adaptee);
    	adapter.setResource(res);
    	register.put(adaptee, adapter);
    	return (simplefsm.fsm.adapters.fsmmt.fsm.FSMAdapter) adapter;
    }
  }
  
  public simplefsm.fsm.adapters.fsmmt.fsm.StateAdapter createStateAdapter(final State adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (simplefsm.fsm.adapters.fsmmt.fsm.StateAdapter) adapter;
    else {
    	adapter = new simplefsm.fsm.adapters.fsmmt.fsm.StateAdapter();
    	adapter.setAdaptee(adaptee);
    	adapter.setResource(res);
    	register.put(adaptee, adapter);
    	return (simplefsm.fsm.adapters.fsmmt.fsm.StateAdapter) adapter;
    }
  }
  
  public simplefsm.fsm.adapters.fsmmt.fsm.TransitionAdapter createTransitionAdapter(final Transition adaptee, final Resource res) {
    if (adaptee == null)
    	return null;
    EObjectAdapter adapter = register.get(adaptee);
    if(adapter != null)
    	 return (simplefsm.fsm.adapters.fsmmt.fsm.TransitionAdapter) adapter;
    else {
    	adapter = new simplefsm.fsm.adapters.fsmmt.fsm.TransitionAdapter();
    	adapter.setAdaptee(adaptee);
    	adapter.setResource(res);
    	register.put(adaptee, adapter);
    	return (simplefsm.fsm.adapters.fsmmt.fsm.TransitionAdapter) adapter;
    }
  }
}
