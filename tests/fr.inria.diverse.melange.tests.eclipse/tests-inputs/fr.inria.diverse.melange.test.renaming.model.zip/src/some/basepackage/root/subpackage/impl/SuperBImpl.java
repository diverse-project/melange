/**
 */
package some.basepackage.root.subpackage.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import some.basepackage.root.subpackage.SubpackagePackage;
import some.basepackage.root.subpackage.SuperB;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Super B</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SuperBImpl extends MinimalEObjectImpl.Container implements SuperB {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SuperBImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SubpackagePackage.Literals.SUPER_B;
	}

} //SuperBImpl
