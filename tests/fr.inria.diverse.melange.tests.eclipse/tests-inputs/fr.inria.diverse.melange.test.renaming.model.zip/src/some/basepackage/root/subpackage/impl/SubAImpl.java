/**
 */
package some.basepackage.root.subpackage.impl;

import org.eclipse.emf.ecore.EClass;

import some.basepackage.root.subpackage.SubA;
import some.basepackage.root.subpackage.SubpackagePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sub A</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SubAImpl extends ClassBImpl implements SubA {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SubAImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SubpackagePackage.Literals.SUB_A;
	}

} //SubAImpl
