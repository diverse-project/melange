/**
 */
package some.basepackage.root.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import some.basepackage.root.ClassA;
import some.basepackage.root.RootPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Class A</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ClassAImpl extends MinimalEObjectImpl.Container implements ClassA {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClassAImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RootPackage.Literals.CLASS_A;
	}

} //ClassAImpl
