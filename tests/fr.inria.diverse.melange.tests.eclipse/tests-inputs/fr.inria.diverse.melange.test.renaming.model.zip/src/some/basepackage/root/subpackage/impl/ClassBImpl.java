/**
 */
package some.basepackage.root.subpackage.impl;

import org.eclipse.emf.ecore.EClass;

import some.basepackage.root.subpackage.ClassB;
import some.basepackage.root.subpackage.SubpackagePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Class B</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ClassBImpl extends SuperBImpl implements ClassB {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClassBImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SubpackagePackage.Literals.CLASS_B;
	}

} //ClassBImpl
