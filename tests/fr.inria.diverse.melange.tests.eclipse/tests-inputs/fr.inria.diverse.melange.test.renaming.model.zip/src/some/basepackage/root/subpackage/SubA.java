/**
 */
package some.basepackage.root.subpackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub A</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see some.basepackage.root.subpackage.SubpackagePackage#getSubA()
 * @model
 * @generated
 */
public interface SubA extends ClassB {
} // SubA
