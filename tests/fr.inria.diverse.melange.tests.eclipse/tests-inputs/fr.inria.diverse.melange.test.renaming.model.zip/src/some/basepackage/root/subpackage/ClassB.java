/**
 */
package some.basepackage.root.subpackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Class B</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see some.basepackage.root.subpackage.SubpackagePackage#getClassB()
 * @model
 * @generated
 */
public interface ClassB extends SuperB {
} // ClassB
