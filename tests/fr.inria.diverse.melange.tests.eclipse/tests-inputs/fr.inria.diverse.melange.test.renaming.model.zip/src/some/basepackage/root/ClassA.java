/**
 */
package some.basepackage.root;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Class A</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see some.basepackage.root.RootPackage#getClassA()
 * @model
 * @generated
 */
public interface ClassA extends EObject {
} // ClassA
