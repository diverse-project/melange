/**
 */
package some.basepackage.root.subpackage;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super B</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see some.basepackage.root.subpackage.SubpackagePackage#getSuperB()
 * @model
 * @generated
 */
public interface SuperB extends EObject {
} // SuperB
