/**
 */
package toppkg.subpkg1.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import toppkg.subpkg1.Subpkg1Class2;
import toppkg.subpkg1.Subpkg1Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Class2</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class Subpkg1Class2Impl extends MinimalEObjectImpl.Container implements Subpkg1Class2 {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Subpkg1Class2Impl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Subpkg1Package.Literals.SUBPKG1_CLASS2;
	}

} //Subpkg1Class2Impl
