/**
 */
package toppkg.subpkg1;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Class2</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see toppkg.subpkg1.Subpkg1Package#getSubpkg1Class2()
 * @model
 * @generated
 */
public interface Subpkg1Class2 extends EObject {
} // Subpkg1Class2
