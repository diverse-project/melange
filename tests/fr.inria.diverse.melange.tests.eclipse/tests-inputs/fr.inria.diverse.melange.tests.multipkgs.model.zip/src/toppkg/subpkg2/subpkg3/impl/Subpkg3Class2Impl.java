/**
 */
package toppkg.subpkg2.subpkg3.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import toppkg.subpkg2.subpkg3.Subpkg3Class2;
import toppkg.subpkg2.subpkg3.Subpkg3Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Class2</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class Subpkg3Class2Impl extends MinimalEObjectImpl.Container implements Subpkg3Class2 {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Subpkg3Class2Impl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Subpkg3Package.Literals.SUBPKG3_CLASS2;
	}

} //Subpkg3Class2Impl
