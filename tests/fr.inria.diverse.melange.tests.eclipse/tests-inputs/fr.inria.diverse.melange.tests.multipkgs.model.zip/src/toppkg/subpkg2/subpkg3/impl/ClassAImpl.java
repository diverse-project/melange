/**
 */
package toppkg.subpkg2.subpkg3.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import toppkg.subpkg2.subpkg3.ClassA;
import toppkg.subpkg2.subpkg3.Subpkg3Package;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Class A</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ClassAImpl extends MinimalEObjectImpl.Container implements ClassA {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClassAImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Subpkg3Package.Literals.CLASS_A;
	}

} //ClassAImpl
