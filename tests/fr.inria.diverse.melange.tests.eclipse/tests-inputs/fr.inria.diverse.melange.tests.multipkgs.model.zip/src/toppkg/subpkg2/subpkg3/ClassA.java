/**
 */
package toppkg.subpkg2.subpkg3;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Class A</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see toppkg.subpkg2.subpkg3.Subpkg3Package#getClassA()
 * @model
 * @generated
 */
public interface ClassA extends EObject {
} // ClassA
