/**
 */
package toppkg.subpkg2.subpkg3;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Class2</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see toppkg.subpkg2.subpkg3.Subpkg3Package#getSubpkg3Class2()
 * @model
 * @generated
 */
public interface Subpkg3Class2 extends EObject {
} // Subpkg3Class2
