/**
 */
package root;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Class</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see root.RootPackage#getClass_()
 * @model
 * @generated
 */
public interface Class extends EObject {
} // Class
