/**
 */
package rootpkg;

import toppkg.subpkg2.Subpkg2Class1;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>New Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link rootpkg.NewClass#getToSubpkg2Class1 <em>To Subpkg2 Class1</em>}</li>
 * </ul>
 *
 * @see rootpkg.RootpkgPackage#getNewClass()
 * @model
 * @generated
 */
public interface NewClass extends root.Class {
	/**
	 * Returns the value of the '<em><b>To Subpkg2 Class1</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>To Subpkg2 Class1</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>To Subpkg2 Class1</em>' reference.
	 * @see #setToSubpkg2Class1(Subpkg2Class1)
	 * @see rootpkg.RootpkgPackage#getNewClass_ToSubpkg2Class1()
	 * @model
	 * @generated
	 */
	Subpkg2Class1 getToSubpkg2Class1();

	/**
	 * Sets the value of the '{@link rootpkg.NewClass#getToSubpkg2Class1 <em>To Subpkg2 Class1</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>To Subpkg2 Class1</em>' reference.
	 * @see #getToSubpkg2Class1()
	 * @generated
	 */
	void setToSubpkg2Class1(Subpkg2Class1 value);

} // NewClass
