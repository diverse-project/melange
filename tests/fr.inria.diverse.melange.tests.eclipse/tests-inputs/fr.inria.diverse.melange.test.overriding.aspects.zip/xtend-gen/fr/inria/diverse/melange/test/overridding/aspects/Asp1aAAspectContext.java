package fr.inria.diverse.melange.test.overridding.aspects;

import fr.inria.diverse.melange.test.overridding.aspects.Asp1aAAspectProperties;
import fr.inria.diverse.root.A;
import java.util.Map;

@SuppressWarnings("all")
public class Asp1aAAspectContext {
  public final static Asp1aAAspectContext INSTANCE = new Asp1aAAspectContext();
  
  public static Asp1aAAspectProperties getSelf(final A _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.test.overridding.aspects.Asp1aAAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<A, Asp1aAAspectProperties> map = new java.util.WeakHashMap<fr.inria.diverse.root.A, fr.inria.diverse.melange.test.overridding.aspects.Asp1aAAspectProperties>();
  
  public Map<A, Asp1aAAspectProperties> getMap() {
    return map;
  }
}
