package fr.inria.diverse.melange.test.overridding.aspects;

import fr.inria.diverse.melange.test.overridding.aspects.Asp1bAAspectProperties;
import fr.inria.diverse.root.A;
import java.util.Map;

@SuppressWarnings("all")
public class Asp1bAAspectContext {
  public final static Asp1bAAspectContext INSTANCE = new Asp1bAAspectContext();
  
  public static Asp1bAAspectProperties getSelf(final A _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.test.overridding.aspects.Asp1bAAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<A, Asp1bAAspectProperties> map = new java.util.WeakHashMap<fr.inria.diverse.root.A, fr.inria.diverse.melange.test.overridding.aspects.Asp1bAAspectProperties>();
  
  public Map<A, Asp1bAAspectProperties> getMap() {
    return map;
  }
}
