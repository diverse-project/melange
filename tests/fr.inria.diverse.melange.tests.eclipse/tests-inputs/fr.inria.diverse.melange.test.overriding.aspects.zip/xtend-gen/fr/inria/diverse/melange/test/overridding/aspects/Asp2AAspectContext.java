package fr.inria.diverse.melange.test.overridding.aspects;

import fr.inria.diverse.melange.test.overridding.aspects.Asp2AAspectProperties;
import fr.inria.diverse.root.A;
import java.util.Map;

@SuppressWarnings("all")
public class Asp2AAspectContext {
  public final static Asp2AAspectContext INSTANCE = new Asp2AAspectContext();
  
  public static Asp2AAspectProperties getSelf(final A _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.test.overridding.aspects.Asp2AAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<A, Asp2AAspectProperties> map = new java.util.WeakHashMap<fr.inria.diverse.root.A, fr.inria.diverse.melange.test.overridding.aspects.Asp2AAspectProperties>();
  
  public Map<A, Asp2AAspectProperties> getMap() {
    return map;
  }
}
