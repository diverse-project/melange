package fr.inria.diverse.melange.test.overridding.aspects;

@SuppressWarnings("all")
public class Asp4AAspectProperties {
}
