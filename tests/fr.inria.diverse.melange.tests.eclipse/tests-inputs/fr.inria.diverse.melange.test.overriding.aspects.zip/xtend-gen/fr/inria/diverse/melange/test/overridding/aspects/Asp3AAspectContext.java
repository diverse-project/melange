package fr.inria.diverse.melange.test.overridding.aspects;

import fr.inria.diverse.melange.test.overridding.aspects.Asp3AAspectProperties;
import fr.inria.diverse.root.A;
import java.util.Map;

@SuppressWarnings("all")
public class Asp3AAspectContext {
  public final static Asp3AAspectContext INSTANCE = new Asp3AAspectContext();
  
  public static Asp3AAspectProperties getSelf(final A _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.test.overridding.aspects.Asp3AAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<A, Asp3AAspectProperties> map = new java.util.WeakHashMap<fr.inria.diverse.root.A, fr.inria.diverse.melange.test.overridding.aspects.Asp3AAspectProperties>();
  
  public Map<A, Asp3AAspectProperties> getMap() {
    return map;
  }
}
