package fr.inria.diverse.melange.test.overridding.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.test.overridding.aspects.Asp0AAspectProperties;
import fr.inria.diverse.root.A;

@Aspect(className = A.class)
@SuppressWarnings("all")
public class Asp0 {
  public static String whoIAm(final A _self) {
    fr.inria.diverse.melange.test.overridding.aspects.Asp0AAspectProperties _self_ = fr.inria.diverse.melange.test.overridding.aspects.Asp0AAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_whoIAm(_self_, _self);
    return (java.lang.String)result;
  }
  
  protected static String _privk3_whoIAm(final Asp0AAspectProperties _self_, final A _self) {
    return "Asp0";
  }
}
