package fr.inria.diverse.melange.test.overridding.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.test.overridding.aspects.Asp1bAAspectProperties;
import fr.inria.diverse.root.A;

@Aspect(className = A.class)
@SuppressWarnings("all")
public class Asp1b {
  public static String whoIAm(final A _self) {
    fr.inria.diverse.melange.test.overridding.aspects.Asp1bAAspectProperties _self_ = fr.inria.diverse.melange.test.overridding.aspects.Asp1bAAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_whoIAm(_self_, _self);
    return (java.lang.String)result;
  }
  
  protected static String _privk3_whoIAm(final Asp1bAAspectProperties _self_, final A _self) {
    return "Asp1b";
  }
}
