package fr.inria.diverse.melange.test.overridding.aspects;

import fr.inria.diverse.melange.test.overridding.aspects.Asp4AAspectProperties;
import fr.inria.diverse.root.A;
import java.util.Map;

@SuppressWarnings("all")
public class Asp4AAspectContext {
  public final static Asp4AAspectContext INSTANCE = new Asp4AAspectContext();
  
  public static Asp4AAspectProperties getSelf(final A _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.test.overridding.aspects.Asp4AAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<A, Asp4AAspectProperties> map = new java.util.WeakHashMap<fr.inria.diverse.root.A, fr.inria.diverse.melange.test.overridding.aspects.Asp4AAspectProperties>();
  
  public Map<A, Asp4AAspectProperties> getMap() {
    return map;
  }
}
