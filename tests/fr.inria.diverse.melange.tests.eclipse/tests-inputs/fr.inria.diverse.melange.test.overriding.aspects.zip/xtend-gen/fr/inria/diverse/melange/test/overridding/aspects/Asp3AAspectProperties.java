package fr.inria.diverse.melange.test.overridding.aspects;

@SuppressWarnings("all")
public class Asp3AAspectProperties {
}
