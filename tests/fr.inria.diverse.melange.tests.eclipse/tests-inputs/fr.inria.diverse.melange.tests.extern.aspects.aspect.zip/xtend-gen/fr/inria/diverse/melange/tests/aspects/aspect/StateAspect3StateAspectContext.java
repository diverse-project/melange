package fr.inria.diverse.melange.tests.aspects.aspect;

import fr.inria.diverse.melange.tests.aspects.aspect.StateAspect3StateAspectProperties;
import fsm.State;
import java.util.Map;

@SuppressWarnings("all")
public class StateAspect3StateAspectContext {
  public final static StateAspect3StateAspectContext INSTANCE = new StateAspect3StateAspectContext();
  
  public static StateAspect3StateAspectProperties getSelf(final State _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.aspects.aspect.StateAspect3StateAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<State, StateAspect3StateAspectProperties> map = new java.util.WeakHashMap<fsm.State, fr.inria.diverse.melange.tests.aspects.aspect.StateAspect3StateAspectProperties>();
  
  public Map<State, StateAspect3StateAspectProperties> getMap() {
    return map;
  }
}
