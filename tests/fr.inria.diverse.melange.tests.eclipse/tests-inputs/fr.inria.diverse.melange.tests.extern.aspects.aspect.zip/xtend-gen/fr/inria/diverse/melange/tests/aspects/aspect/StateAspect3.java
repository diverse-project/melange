package fr.inria.diverse.melange.tests.aspects.aspect;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.aspects.aspect.StateAspect3StateAspectProperties;
import fsm.State;

@Aspect(className = State.class)
@SuppressWarnings("all")
public class StateAspect3 {
  public static int baz(final State _self, final String s) {
    final fr.inria.diverse.melange.tests.aspects.aspect.StateAspect3StateAspectProperties _self_ = fr.inria.diverse.melange.tests.aspects.aspect.StateAspect3StateAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_baz(_self_, _self,s);;
    return (int)result;
  }
  
  protected static int _privk3_baz(final StateAspect3StateAspectProperties _self_, final State _self, final String s) {
    return (-1);
  }
}
