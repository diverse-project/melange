package fr.inria.diverse.melange.tests.aspects.aspect;

@SuppressWarnings("all")
public class StateAspect3StateAspectProperties {
}
