package fr.inria.diverse.melange.tests.aspects.aspect;

import fr.inria.diverse.melange.tests.aspects.aspect.StateAspect1StateAspectProperties;
import fsm.State;
import java.util.Map;

@SuppressWarnings("all")
public class StateAspect1StateAspectContext {
  public final static StateAspect1StateAspectContext INSTANCE = new StateAspect1StateAspectContext();
  
  public static StateAspect1StateAspectProperties getSelf(final State _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.aspects.aspect.StateAspect1StateAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<State, StateAspect1StateAspectProperties> map = new java.util.WeakHashMap<fsm.State, fr.inria.diverse.melange.tests.aspects.aspect.StateAspect1StateAspectProperties>();
  
  public Map<State, StateAspect1StateAspectProperties> getMap() {
    return map;
  }
}
