package fr.inria.diverse.melange.tests.aspects.aspect;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.aspects.aspect.StateAspect1StateAspectProperties;
import fsm.State;
import org.eclipse.xtend2.lib.StringConcatenation;

@Aspect(className = State.class)
@SuppressWarnings("all")
public class StateAspect1 {
  public static String foo(final State _self) {
    final fr.inria.diverse.melange.tests.aspects.aspect.StateAspect1StateAspectProperties _self_ = fr.inria.diverse.melange.tests.aspects.aspect.StateAspect1StateAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_foo(_self_, _self);;
    return (java.lang.String)result;
  }
  
  protected static String _privk3_foo(final StateAspect1StateAspectProperties _self_, final State _self) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("foo!");
    return _builder.toString();
  }
}
