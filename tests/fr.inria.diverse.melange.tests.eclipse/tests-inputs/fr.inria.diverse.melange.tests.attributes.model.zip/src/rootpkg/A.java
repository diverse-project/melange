/**
 */
package rootpkg;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>A</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see rootpkg.RootpkgPackage#getA()
 * @model
 * @generated
 */
public interface A extends EObject {
} // A
