package fr.inria.diverse.melange.tests.attributes.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.attributes.aspects.TokenAspectTokenAspectProperties;
import other.rootpkg2.Token;

@Aspect(className = Token.class)
@SuppressWarnings("all")
public class TokenAspect {
  public static String myName(final Token _self) {
    final fr.inria.diverse.melange.tests.attributes.aspects.TokenAspectTokenAspectProperties _self_ = fr.inria.diverse.melange.tests.attributes.aspects.TokenAspectTokenAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_myName(_self_, _self);;
    return (java.lang.String)result;
  }
  
  public static void myName(final Token _self, final String myName) {
    final fr.inria.diverse.melange.tests.attributes.aspects.TokenAspectTokenAspectProperties _self_ = fr.inria.diverse.melange.tests.attributes.aspects.TokenAspectTokenAspectContext.getSelf(_self);
    _privk3_myName(_self_, _self,myName);;
  }
  
  protected static String _privk3_myName(final TokenAspectTokenAspectProperties _self_, final Token _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getMyName") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (java.lang.String) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.myName;
  }
  
  protected static void _privk3_myName(final TokenAspectTokenAspectProperties _self_, final Token _self, final String myName) {
    _self_.myName = myName; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setMyName")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, myName);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
