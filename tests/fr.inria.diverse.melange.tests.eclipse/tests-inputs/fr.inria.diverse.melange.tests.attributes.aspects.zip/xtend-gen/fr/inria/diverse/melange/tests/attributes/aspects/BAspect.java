package fr.inria.diverse.melange.tests.attributes.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.Containment;
import fr.inria.diverse.melange.tests.attributes.aspects.BAspectBAspectProperties;
import org.eclipse.emf.common.util.UniqueEList;
import rootpkg.A;
import rootpkg.B;

@Aspect(className = B.class)
@SuppressWarnings("all")
public class BAspect {
  @Containment
  public static UniqueEList<A> toA(final B _self) {
    final fr.inria.diverse.melange.tests.attributes.aspects.BAspectBAspectProperties _self_ = fr.inria.diverse.melange.tests.attributes.aspects.BAspectBAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_toA(_self_, _self);;
    return (org.eclipse.emf.common.util.UniqueEList<rootpkg.A>)result;
  }
  
  @Containment
  public static void toA(final B _self, final UniqueEList<A> toA) {
    final fr.inria.diverse.melange.tests.attributes.aspects.BAspectBAspectProperties _self_ = fr.inria.diverse.melange.tests.attributes.aspects.BAspectBAspectContext.getSelf(_self);
    _privk3_toA(_self_, _self,toA);;
  }
  
  protected static UniqueEList<A> _privk3_toA(final BAspectBAspectProperties _self_, final B _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getToA") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.emf.common.util.UniqueEList) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.toA;
  }
  
  protected static void _privk3_toA(final BAspectBAspectProperties _self_, final B _self, final UniqueEList<A> toA) {
    _self_.toA = toA; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setToA")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, toA);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
