package fr.inria.diverse.melange.tests.attributes.aspects;

import org.eclipse.emf.common.util.EList;
import rootpkg.A;
import rootpkg.B;

@SuppressWarnings("all")
public class BAspectBAspectProperties {
  public EList<A> toA;
  
  public EList<B> toB = null;
}
