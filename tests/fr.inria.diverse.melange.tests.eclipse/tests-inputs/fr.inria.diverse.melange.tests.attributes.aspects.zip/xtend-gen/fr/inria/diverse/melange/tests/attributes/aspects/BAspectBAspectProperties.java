package fr.inria.diverse.melange.tests.attributes.aspects;

import org.eclipse.emf.common.util.EList;
import rootpkg.A;

@SuppressWarnings("all")
public class BAspectBAspectProperties {
  public EList<A> toA;
}
