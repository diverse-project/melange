package fr.inria.diverse.melange.tests.attributes.aspects;

import org.eclipse.emf.common.util.EList;
import rootpkg.A;
import rootpkg.B;

@SuppressWarnings("all")
public class AAspectAAspectProperties {
  public final EList<A> toA = null;
  
  public B toB = null;
}
