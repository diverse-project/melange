package fr.inria.diverse.melange.tests.attributes.aspects;

import org.eclipse.emf.common.util.BasicEList;
import rootpkg.A;

@SuppressWarnings("all")
public class AAspectAAspectProperties {
  public final BasicEList<A> toA = null;
}
