package fr.inria.diverse.melange.tests.attributes.aspects;

@SuppressWarnings("all")
public class TokenAspectTokenAspectProperties {
  public String myName;
}
