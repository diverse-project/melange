package fr.inria.diverse.melange.tests.attributes.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.Unique;
import fr.inria.diverse.melange.tests.attributes.aspects.AAspectAAspectProperties;
import org.eclipse.emf.common.util.EList;
import rootpkg.A;
import rootpkg.B;

@Aspect(className = A.class)
@SuppressWarnings("all")
public class AAspect {
  @Unique
  public static EList<A> toA(final A _self) {
    final fr.inria.diverse.melange.tests.attributes.aspects.AAspectAAspectProperties _self_ = fr.inria.diverse.melange.tests.attributes.aspects.AAspectAAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_toA(_self_, _self);;
    return (org.eclipse.emf.common.util.EList<rootpkg.A>)result;
  }
  
  public static EList<B> toB(final A _self) {
    final fr.inria.diverse.melange.tests.attributes.aspects.AAspectAAspectProperties _self_ = fr.inria.diverse.melange.tests.attributes.aspects.AAspectAAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_toB(_self_, _self);;
    return (org.eclipse.emf.common.util.EList<rootpkg.B>)result;
  }
  
  public static void toB(final A _self, final EList<B> toB) {
    final fr.inria.diverse.melange.tests.attributes.aspects.AAspectAAspectProperties _self_ = fr.inria.diverse.melange.tests.attributes.aspects.AAspectAAspectContext.getSelf(_self);
    _privk3_toB(_self_, _self,toB);;
  }
  
  protected static EList<A> _privk3_toA(final AAspectAAspectProperties _self_, final A _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getToA") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.emf.common.util.EList) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.toA;
  }
  
  protected static EList<B> _privk3_toB(final AAspectAAspectProperties _self_, final A _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getToB") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.emf.common.util.EList) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.toB;
  }
  
  protected static void _privk3_toB(final AAspectAAspectProperties _self_, final A _self, final EList<B> toB) {
    _self_.toB = toB; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setToB")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, toB);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
