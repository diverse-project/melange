package fr.inria.diverse.melange.tests.attributes.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.attributes.aspects.AAspectAAspectProperties;
import org.eclipse.emf.common.util.BasicEList;
import rootpkg.A;

@Aspect(className = A.class)
@SuppressWarnings("all")
public class AAspect {
  public static BasicEList<A> toA(final A _self) {
    final fr.inria.diverse.melange.tests.attributes.aspects.AAspectAAspectProperties _self_ = fr.inria.diverse.melange.tests.attributes.aspects.AAspectAAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_toA(_self_, _self);;
    return (org.eclipse.emf.common.util.BasicEList<rootpkg.A>)result;
  }
  
  protected static BasicEList<A> _privk3_toA(final AAspectAAspectProperties _self_, final A _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getToA") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.emf.common.util.BasicEList) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.toA;
  }
}
