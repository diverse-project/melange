package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.multipkgs.aspects.TopClassAAspectClassAAspectProperties;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtext.xbase.lib.InputOutput;
import toppkg.ClassA;

@Aspect(className = ClassA.class)
@SuppressWarnings("all")
public class TopClassAAspect {
  public static void visit(final ClassA _self) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.TopClassAAspectClassAAspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.TopClassAAspectClassAAspectContext.getSelf(_self);
    _privk3_visit(_self_, _self);;
  }
  
  public static EList<toppkg.subpkg2.subpkg3.ClassA> toSubClassA(final ClassA _self) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.TopClassAAspectClassAAspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.TopClassAAspectClassAAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_toSubClassA(_self_, _self);;
    return (org.eclipse.emf.common.util.EList<toppkg.subpkg2.subpkg3.ClassA>)result;
  }
  
  public static void toSubClassA(final ClassA _self, final EList<toppkg.subpkg2.subpkg3.ClassA> toSubClassA) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.TopClassAAspectClassAAspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.TopClassAAspectClassAAspectContext.getSelf(_self);
    _privk3_toSubClassA(_self_, _self,toSubClassA);;
  }
  
  protected static void _privk3_visit(final TopClassAAspectClassAAspectProperties _self_, final ClassA _self) {
    EClass _eClass = _self.eClass();
    String _name = _eClass.getName();
    InputOutput.<String>println(_name);
  }
  
  protected static EList<toppkg.subpkg2.subpkg3.ClassA> _privk3_toSubClassA(final TopClassAAspectClassAAspectProperties _self_, final ClassA _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getToSubClassA") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.emf.common.util.EList) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.toSubClassA;
  }
  
  protected static void _privk3_toSubClassA(final TopClassAAspectClassAAspectProperties _self_, final ClassA _self, final EList<toppkg.subpkg2.subpkg3.ClassA> toSubClassA) {
    _self_.toSubClassA = toSubClassA; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setToSubClassA")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, toSubClassA);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
