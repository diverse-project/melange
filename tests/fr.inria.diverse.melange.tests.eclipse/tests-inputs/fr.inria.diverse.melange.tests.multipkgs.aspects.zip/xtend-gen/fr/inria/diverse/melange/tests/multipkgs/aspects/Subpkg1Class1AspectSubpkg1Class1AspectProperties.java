package fr.inria.diverse.melange.tests.multipkgs.aspects;

@SuppressWarnings("all")
public class Subpkg1Class1AspectSubpkg1Class1AspectProperties {
}
