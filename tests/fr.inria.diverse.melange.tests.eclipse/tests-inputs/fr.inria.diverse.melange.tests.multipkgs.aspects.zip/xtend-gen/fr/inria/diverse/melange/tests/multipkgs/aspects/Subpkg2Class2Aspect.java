package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class2AspectSubpkg2Class2AspectProperties;
import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class1Aspect;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtext.xbase.lib.InputOutput;
import toppkg.subpkg2.Subpkg2Class2;
import toppkg.subpkg2.subpkg3.Subpkg3Class1;

@Aspect(className = Subpkg2Class2.class)
@SuppressWarnings("all")
public class Subpkg2Class2Aspect {
  public static void visit(final Subpkg2Class2 _self) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class2AspectSubpkg2Class2AspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class2AspectSubpkg2Class2AspectContext.getSelf(_self);
    _privk3_visit(_self_, _self);;
  }
  
  protected static void _privk3_visit(final Subpkg2Class2AspectSubpkg2Class2AspectProperties _self_, final Subpkg2Class2 _self) {
    EClass _eClass = _self.eClass();
    String _name = _eClass.getName();
    InputOutput.<String>println(_name);
    EList<Subpkg3Class1> _mySubpkg3Class1 = _self.getMySubpkg3Class1();
    final Consumer<Subpkg3Class1> _function = (Subpkg3Class1 it) -> {
      Subpkg3Class1Aspect.visit(it);
    };
    _mySubpkg3Class1.forEach(_function);
  }
}
