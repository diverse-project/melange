package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class1AspectSubpkg3Class1AspectProperties;
import java.util.Map;
import toppkg.subpkg2.subpkg3.Subpkg3Class1;

@SuppressWarnings("all")
public class Subpkg3Class1AspectSubpkg3Class1AspectContext {
  public final static Subpkg3Class1AspectSubpkg3Class1AspectContext INSTANCE = new Subpkg3Class1AspectSubpkg3Class1AspectContext();
  
  public static Subpkg3Class1AspectSubpkg3Class1AspectProperties getSelf(final Subpkg3Class1 _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class1AspectSubpkg3Class1AspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Subpkg3Class1, Subpkg3Class1AspectSubpkg3Class1AspectProperties> map = new java.util.WeakHashMap<toppkg.subpkg2.subpkg3.Subpkg3Class1, fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class1AspectSubpkg3Class1AspectProperties>();
  
  public Map<Subpkg3Class1, Subpkg3Class1AspectSubpkg3Class1AspectProperties> getMap() {
    return map;
  }
}
