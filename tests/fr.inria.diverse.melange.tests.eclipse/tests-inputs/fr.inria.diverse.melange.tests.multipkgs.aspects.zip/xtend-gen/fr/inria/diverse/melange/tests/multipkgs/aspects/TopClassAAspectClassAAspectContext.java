package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.melange.tests.multipkgs.aspects.TopClassAAspectClassAAspectProperties;
import java.util.Map;
import toppkg.ClassA;

@SuppressWarnings("all")
public class TopClassAAspectClassAAspectContext {
  public final static TopClassAAspectClassAAspectContext INSTANCE = new TopClassAAspectClassAAspectContext();
  
  public static TopClassAAspectClassAAspectProperties getSelf(final ClassA _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.multipkgs.aspects.TopClassAAspectClassAAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<ClassA, TopClassAAspectClassAAspectProperties> map = new java.util.WeakHashMap<toppkg.ClassA, fr.inria.diverse.melange.tests.multipkgs.aspects.TopClassAAspectClassAAspectProperties>();
  
  public Map<ClassA, TopClassAAspectClassAAspectProperties> getMap() {
    return map;
  }
}
