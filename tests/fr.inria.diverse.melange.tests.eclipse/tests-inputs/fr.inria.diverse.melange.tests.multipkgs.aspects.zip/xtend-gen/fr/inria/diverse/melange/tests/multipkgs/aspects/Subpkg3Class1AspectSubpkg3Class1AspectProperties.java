package fr.inria.diverse.melange.tests.multipkgs.aspects;

@SuppressWarnings("all")
public class Subpkg3Class1AspectSubpkg3Class1AspectProperties {
}
