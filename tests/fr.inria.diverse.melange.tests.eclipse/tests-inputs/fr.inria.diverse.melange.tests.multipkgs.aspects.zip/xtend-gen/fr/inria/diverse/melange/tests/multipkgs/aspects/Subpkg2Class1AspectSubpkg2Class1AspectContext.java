package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class1AspectSubpkg2Class1AspectProperties;
import java.util.Map;
import toppkg.subpkg2.Subpkg2Class1;

@SuppressWarnings("all")
public class Subpkg2Class1AspectSubpkg2Class1AspectContext {
  public final static Subpkg2Class1AspectSubpkg2Class1AspectContext INSTANCE = new Subpkg2Class1AspectSubpkg2Class1AspectContext();
  
  public static Subpkg2Class1AspectSubpkg2Class1AspectProperties getSelf(final Subpkg2Class1 _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class1AspectSubpkg2Class1AspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Subpkg2Class1, Subpkg2Class1AspectSubpkg2Class1AspectProperties> map = new java.util.WeakHashMap<toppkg.subpkg2.Subpkg2Class1, fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class1AspectSubpkg2Class1AspectProperties>();
  
  public Map<Subpkg2Class1, Subpkg2Class1AspectSubpkg2Class1AspectProperties> getMap() {
    return map;
  }
}
