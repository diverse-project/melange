package fr.inria.diverse.melange.tests.multipkgs.aspects;

@SuppressWarnings("all")
public class Subpkg2Class1AspectSubpkg2Class1AspectProperties {
}
