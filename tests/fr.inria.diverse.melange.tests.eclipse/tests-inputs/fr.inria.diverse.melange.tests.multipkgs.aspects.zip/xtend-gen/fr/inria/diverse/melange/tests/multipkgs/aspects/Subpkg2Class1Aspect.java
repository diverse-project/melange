package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class1AspectSubpkg2Class1AspectProperties;
import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class2Aspect;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtext.xbase.lib.InputOutput;
import toppkg.subpkg2.Subpkg2Class1;
import toppkg.subpkg2.Subpkg2Class2;

@Aspect(className = Subpkg2Class1.class)
@SuppressWarnings("all")
public class Subpkg2Class1Aspect {
  public static void visit(final Subpkg2Class1 _self) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class1AspectSubpkg2Class1AspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class1AspectSubpkg2Class1AspectContext.getSelf(_self);
    _privk3_visit(_self_, _self);;
  }
  
  protected static void _privk3_visit(final Subpkg2Class1AspectSubpkg2Class1AspectProperties _self_, final Subpkg2Class1 _self) {
    EClass _eClass = _self.eClass();
    String _name = _eClass.getName();
    InputOutput.<String>println(_name);
    EList<Subpkg2Class2> _mySubpkg2Class2 = _self.getMySubpkg2Class2();
    final Consumer<Subpkg2Class2> _function = (Subpkg2Class2 it) -> {
      Subpkg2Class2Aspect.visit(it);
    };
    _mySubpkg2Class2.forEach(_function);
  }
}
