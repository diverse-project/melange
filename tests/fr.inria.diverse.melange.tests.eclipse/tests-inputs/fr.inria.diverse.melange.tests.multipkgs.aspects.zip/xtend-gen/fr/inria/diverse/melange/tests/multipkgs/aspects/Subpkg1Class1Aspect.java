package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class1AspectSubpkg1Class1AspectProperties;
import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class2Aspect;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtext.xbase.lib.InputOutput;
import toppkg.subpkg1.Subpkg1Class1;
import toppkg.subpkg1.Subpkg1Class2;

@Aspect(className = Subpkg1Class1.class)
@SuppressWarnings("all")
public class Subpkg1Class1Aspect {
  public static void visit(final Subpkg1Class1 _self) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class1AspectSubpkg1Class1AspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class1AspectSubpkg1Class1AspectContext.getSelf(_self);
    _privk3_visit(_self_, _self);;
  }
  
  protected static void _privk3_visit(final Subpkg1Class1AspectSubpkg1Class1AspectProperties _self_, final Subpkg1Class1 _self) {
    EClass _eClass = _self.eClass();
    String _name = _eClass.getName();
    InputOutput.<String>println(_name);
    EList<Subpkg1Class2> _mySubpkg1Class2 = _self.getMySubpkg1Class2();
    final Consumer<Subpkg1Class2> _function = (Subpkg1Class2 it) -> {
      Subpkg1Class2Aspect.visit(it);
    };
    _mySubpkg1Class2.forEach(_function);
  }
}
