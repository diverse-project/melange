package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass2AspectTopClass2AspectProperties;
import java.util.Map;
import toppkg.TopClass2;

@SuppressWarnings("all")
public class TopClass2AspectTopClass2AspectContext {
  public final static TopClass2AspectTopClass2AspectContext INSTANCE = new TopClass2AspectTopClass2AspectContext();
  
  public static TopClass2AspectTopClass2AspectProperties getSelf(final TopClass2 _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass2AspectTopClass2AspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<TopClass2, TopClass2AspectTopClass2AspectProperties> map = new java.util.WeakHashMap<toppkg.TopClass2, fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass2AspectTopClass2AspectProperties>();
  
  public Map<TopClass2, TopClass2AspectTopClass2AspectProperties> getMap() {
    return map;
  }
}
