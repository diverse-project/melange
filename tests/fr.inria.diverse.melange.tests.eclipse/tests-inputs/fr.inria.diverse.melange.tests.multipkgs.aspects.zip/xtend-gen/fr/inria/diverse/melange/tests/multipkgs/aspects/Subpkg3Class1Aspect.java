package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class1AspectSubpkg3Class1AspectProperties;
import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class2Aspect;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtext.xbase.lib.InputOutput;
import toppkg.subpkg2.subpkg3.Subpkg3Class1;
import toppkg.subpkg2.subpkg3.Subpkg3Class2;

@Aspect(className = Subpkg3Class1.class)
@SuppressWarnings("all")
public class Subpkg3Class1Aspect {
  public static void visit(final Subpkg3Class1 _self) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class1AspectSubpkg3Class1AspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class1AspectSubpkg3Class1AspectContext.getSelf(_self);
    _privk3_visit(_self_, _self);;
  }
  
  protected static void _privk3_visit(final Subpkg3Class1AspectSubpkg3Class1AspectProperties _self_, final Subpkg3Class1 _self) {
    EClass _eClass = _self.eClass();
    String _name = _eClass.getName();
    InputOutput.<String>println(_name);
    EList<Subpkg3Class2> _mySubpkg3Class2 = _self.getMySubpkg3Class2();
    final Consumer<Subpkg3Class2> _function = (Subpkg3Class2 it) -> {
      Subpkg3Class2Aspect.visit(it);
    };
    _mySubpkg3Class2.forEach(_function);
  }
}
