package fr.inria.diverse.melange.tests.multipkgs.aspects;

import toppkg.ClassA;

@SuppressWarnings("all")
public class SubClassAAspectClassAAspectProperties {
  public ClassA toUpperClassA;
}
