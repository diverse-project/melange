package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class1Aspect;
import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class1Aspect;
import fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass1AspectTopClass1AspectProperties;
import fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass2Aspect;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtext.xbase.lib.InputOutput;
import toppkg.TopClass1;
import toppkg.TopClass2;
import toppkg.subpkg1.Subpkg1Class1;
import toppkg.subpkg2.Subpkg2Class1;

@Aspect(className = TopClass1.class)
@SuppressWarnings("all")
public class TopClass1Aspect {
  public static void visit(final TopClass1 _self) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass1AspectTopClass1AspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass1AspectTopClass1AspectContext.getSelf(_self);
    _privk3_visit(_self_, _self);;
  }
  
  protected static void _privk3_visit(final TopClass1AspectTopClass1AspectProperties _self_, final TopClass1 _self) {
    EClass _eClass = _self.eClass();
    String _name = _eClass.getName();
    InputOutput.<String>println(_name);
    EList<Subpkg1Class1> _mySubPkg1Class1 = _self.getMySubPkg1Class1();
    final Consumer<Subpkg1Class1> _function = (Subpkg1Class1 it) -> {
      Subpkg1Class1Aspect.visit(it);
    };
    _mySubPkg1Class1.forEach(_function);
    EList<Subpkg2Class1> _mySubpkg2Class1 = _self.getMySubpkg2Class1();
    final Consumer<Subpkg2Class1> _function_1 = (Subpkg2Class1 it) -> {
      Subpkg2Class1Aspect.visit(it);
    };
    _mySubpkg2Class1.forEach(_function_1);
    EList<TopClass2> _myTopClass2 = _self.getMyTopClass2();
    final Consumer<TopClass2> _function_2 = (TopClass2 it) -> {
      TopClass2Aspect.visit(it);
    };
    _myTopClass2.forEach(_function_2);
  }
}
