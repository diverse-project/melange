package fr.inria.diverse.melange.tests.multipkgs.aspects;

@SuppressWarnings("all")
public class Subpkg2Class2AspectSubpkg2Class2AspectProperties {
}
