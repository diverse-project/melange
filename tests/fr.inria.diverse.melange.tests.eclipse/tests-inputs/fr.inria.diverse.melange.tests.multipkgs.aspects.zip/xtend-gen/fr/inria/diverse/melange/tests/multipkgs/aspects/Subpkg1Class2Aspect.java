package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class2AspectSubpkg1Class2AspectProperties;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtext.xbase.lib.InputOutput;
import toppkg.subpkg1.Subpkg1Class2;

@Aspect(className = Subpkg1Class2.class)
@SuppressWarnings("all")
public class Subpkg1Class2Aspect {
  public static void visit(final Subpkg1Class2 _self) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class2AspectSubpkg1Class2AspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class2AspectSubpkg1Class2AspectContext.getSelf(_self);
    _privk3_visit(_self_, _self);;
  }
  
  protected static void _privk3_visit(final Subpkg1Class2AspectSubpkg1Class2AspectProperties _self_, final Subpkg1Class2 _self) {
    EClass _eClass = _self.eClass();
    String _name = _eClass.getName();
    InputOutput.<String>println(_name);
  }
}
