package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.multipkgs.aspects.SubClassAAspectClassAAspectProperties;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtext.xbase.lib.InputOutput;
import toppkg.subpkg2.subpkg3.ClassA;

@Aspect(className = ClassA.class)
@SuppressWarnings("all")
public class SubClassAAspect {
  public static void visit(final ClassA _self) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.SubClassAAspectClassAAspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.SubClassAAspectClassAAspectContext.getSelf(_self);
    _privk3_visit(_self_, _self);;
  }
  
  public static toppkg.ClassA toUpperClassA(final ClassA _self) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.SubClassAAspectClassAAspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.SubClassAAspectClassAAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_toUpperClassA(_self_, _self);;
    return (toppkg.ClassA)result;
  }
  
  public static void toUpperClassA(final ClassA _self, final toppkg.ClassA toUpperClassA) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.SubClassAAspectClassAAspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.SubClassAAspectClassAAspectContext.getSelf(_self);
    _privk3_toUpperClassA(_self_, _self,toUpperClassA);;
  }
  
  protected static void _privk3_visit(final SubClassAAspectClassAAspectProperties _self_, final ClassA _self) {
    EClass _eClass = _self.eClass();
    String _name = _eClass.getName();
    InputOutput.<String>println(_name);
  }
  
  protected static toppkg.ClassA _privk3_toUpperClassA(final SubClassAAspectClassAAspectProperties _self_, final ClassA _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getToUpperClassA") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (toppkg.ClassA) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.toUpperClassA;
  }
  
  protected static void _privk3_toUpperClassA(final SubClassAAspectClassAAspectProperties _self_, final ClassA _self, final toppkg.ClassA toUpperClassA) {
    _self_.toUpperClassA = toUpperClassA; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setToUpperClassA")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, toUpperClassA);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
