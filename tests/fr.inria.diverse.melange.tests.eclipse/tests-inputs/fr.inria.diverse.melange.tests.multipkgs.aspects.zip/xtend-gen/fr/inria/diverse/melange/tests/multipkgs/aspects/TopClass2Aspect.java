package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass2AspectTopClass2AspectProperties;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtext.xbase.lib.InputOutput;
import toppkg.TopClass2;

@Aspect(className = TopClass2.class)
@SuppressWarnings("all")
public class TopClass2Aspect {
  public static void visit(final TopClass2 _self) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass2AspectTopClass2AspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass2AspectTopClass2AspectContext.getSelf(_self);
    _privk3_visit(_self_, _self);;
  }
  
  protected static void _privk3_visit(final TopClass2AspectTopClass2AspectProperties _self_, final TopClass2 _self) {
    EClass _eClass = _self.eClass();
    String _name = _eClass.getName();
    InputOutput.<String>println(_name);
  }
}
