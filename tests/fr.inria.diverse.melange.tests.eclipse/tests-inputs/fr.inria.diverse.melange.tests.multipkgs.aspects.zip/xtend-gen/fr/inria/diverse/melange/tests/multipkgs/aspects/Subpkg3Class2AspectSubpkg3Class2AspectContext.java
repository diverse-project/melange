package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class2AspectSubpkg3Class2AspectProperties;
import java.util.Map;
import toppkg.subpkg2.subpkg3.Subpkg3Class2;

@SuppressWarnings("all")
public class Subpkg3Class2AspectSubpkg3Class2AspectContext {
  public final static Subpkg3Class2AspectSubpkg3Class2AspectContext INSTANCE = new Subpkg3Class2AspectSubpkg3Class2AspectContext();
  
  public static Subpkg3Class2AspectSubpkg3Class2AspectProperties getSelf(final Subpkg3Class2 _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class2AspectSubpkg3Class2AspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Subpkg3Class2, Subpkg3Class2AspectSubpkg3Class2AspectProperties> map = new java.util.WeakHashMap<toppkg.subpkg2.subpkg3.Subpkg3Class2, fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class2AspectSubpkg3Class2AspectProperties>();
  
  public Map<Subpkg3Class2, Subpkg3Class2AspectSubpkg3Class2AspectProperties> getMap() {
    return map;
  }
}
