package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class1AspectSubpkg1Class1AspectProperties;
import java.util.Map;
import toppkg.subpkg1.Subpkg1Class1;

@SuppressWarnings("all")
public class Subpkg1Class1AspectSubpkg1Class1AspectContext {
  public final static Subpkg1Class1AspectSubpkg1Class1AspectContext INSTANCE = new Subpkg1Class1AspectSubpkg1Class1AspectContext();
  
  public static Subpkg1Class1AspectSubpkg1Class1AspectProperties getSelf(final Subpkg1Class1 _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class1AspectSubpkg1Class1AspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Subpkg1Class1, Subpkg1Class1AspectSubpkg1Class1AspectProperties> map = new java.util.WeakHashMap<toppkg.subpkg1.Subpkg1Class1, fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class1AspectSubpkg1Class1AspectProperties>();
  
  public Map<Subpkg1Class1, Subpkg1Class1AspectSubpkg1Class1AspectProperties> getMap() {
    return map;
  }
}
