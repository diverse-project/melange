package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass1AspectTopClass1AspectProperties;
import java.util.Map;
import toppkg.TopClass1;

@SuppressWarnings("all")
public class TopClass1AspectTopClass1AspectContext {
  public final static TopClass1AspectTopClass1AspectContext INSTANCE = new TopClass1AspectTopClass1AspectContext();
  
  public static TopClass1AspectTopClass1AspectProperties getSelf(final TopClass1 _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass1AspectTopClass1AspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<TopClass1, TopClass1AspectTopClass1AspectProperties> map = new java.util.WeakHashMap<toppkg.TopClass1, fr.inria.diverse.melange.tests.multipkgs.aspects.TopClass1AspectTopClass1AspectProperties>();
  
  public Map<TopClass1, TopClass1AspectTopClass1AspectProperties> getMap() {
    return map;
  }
}
