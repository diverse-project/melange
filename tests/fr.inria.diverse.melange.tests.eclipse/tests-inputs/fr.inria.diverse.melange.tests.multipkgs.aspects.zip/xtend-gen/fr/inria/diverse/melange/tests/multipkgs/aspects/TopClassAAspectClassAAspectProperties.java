package fr.inria.diverse.melange.tests.multipkgs.aspects;

import org.eclipse.emf.common.util.EList;
import toppkg.subpkg2.subpkg3.ClassA;

@SuppressWarnings("all")
public class TopClassAAspectClassAAspectProperties {
  public EList<ClassA> toSubClassA;
}
