package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class2AspectSubpkg1Class2AspectProperties;
import java.util.Map;
import toppkg.subpkg1.Subpkg1Class2;

@SuppressWarnings("all")
public class Subpkg1Class2AspectSubpkg1Class2AspectContext {
  public final static Subpkg1Class2AspectSubpkg1Class2AspectContext INSTANCE = new Subpkg1Class2AspectSubpkg1Class2AspectContext();
  
  public static Subpkg1Class2AspectSubpkg1Class2AspectProperties getSelf(final Subpkg1Class2 _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class2AspectSubpkg1Class2AspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Subpkg1Class2, Subpkg1Class2AspectSubpkg1Class2AspectProperties> map = new java.util.WeakHashMap<toppkg.subpkg1.Subpkg1Class2, fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg1Class2AspectSubpkg1Class2AspectProperties>();
  
  public Map<Subpkg1Class2, Subpkg1Class2AspectSubpkg1Class2AspectProperties> getMap() {
    return map;
  }
}
