package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.melange.tests.multipkgs.aspects.SubClassAAspectClassAAspectProperties;
import java.util.Map;
import toppkg.subpkg2.subpkg3.ClassA;

@SuppressWarnings("all")
public class SubClassAAspectClassAAspectContext {
  public final static SubClassAAspectClassAAspectContext INSTANCE = new SubClassAAspectClassAAspectContext();
  
  public static SubClassAAspectClassAAspectProperties getSelf(final ClassA _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.multipkgs.aspects.SubClassAAspectClassAAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<ClassA, SubClassAAspectClassAAspectProperties> map = new java.util.WeakHashMap<toppkg.subpkg2.subpkg3.ClassA, fr.inria.diverse.melange.tests.multipkgs.aspects.SubClassAAspectClassAAspectProperties>();
  
  public Map<ClassA, SubClassAAspectClassAAspectProperties> getMap() {
    return map;
  }
}
