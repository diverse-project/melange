package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class2AspectSubpkg2Class2AspectProperties;
import java.util.Map;
import toppkg.subpkg2.Subpkg2Class2;

@SuppressWarnings("all")
public class Subpkg2Class2AspectSubpkg2Class2AspectContext {
  public final static Subpkg2Class2AspectSubpkg2Class2AspectContext INSTANCE = new Subpkg2Class2AspectSubpkg2Class2AspectContext();
  
  public static Subpkg2Class2AspectSubpkg2Class2AspectProperties getSelf(final Subpkg2Class2 _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class2AspectSubpkg2Class2AspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Subpkg2Class2, Subpkg2Class2AspectSubpkg2Class2AspectProperties> map = new java.util.WeakHashMap<toppkg.subpkg2.Subpkg2Class2, fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg2Class2AspectSubpkg2Class2AspectProperties>();
  
  public Map<Subpkg2Class2, Subpkg2Class2AspectSubpkg2Class2AspectProperties> getMap() {
    return map;
  }
}
