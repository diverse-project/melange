package fr.inria.diverse.melange.tests.multipkgs.aspects;

@SuppressWarnings("all")
public class Subpkg3Class2AspectSubpkg3Class2AspectProperties {
}
