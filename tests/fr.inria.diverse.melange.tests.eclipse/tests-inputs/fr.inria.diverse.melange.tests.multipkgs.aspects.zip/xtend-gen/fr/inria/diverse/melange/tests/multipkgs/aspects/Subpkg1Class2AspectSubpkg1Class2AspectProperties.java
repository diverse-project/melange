package fr.inria.diverse.melange.tests.multipkgs.aspects;

@SuppressWarnings("all")
public class Subpkg1Class2AspectSubpkg1Class2AspectProperties {
}
