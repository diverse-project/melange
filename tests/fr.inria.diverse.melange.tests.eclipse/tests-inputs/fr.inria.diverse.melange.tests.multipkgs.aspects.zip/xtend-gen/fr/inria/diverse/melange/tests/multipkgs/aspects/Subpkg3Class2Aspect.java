package fr.inria.diverse.melange.tests.multipkgs.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class2AspectSubpkg3Class2AspectProperties;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.xtext.xbase.lib.InputOutput;
import toppkg.subpkg2.subpkg3.Subpkg3Class2;

@Aspect(className = Subpkg3Class2.class)
@SuppressWarnings("all")
public class Subpkg3Class2Aspect {
  public static void visit(final Subpkg3Class2 _self) {
    final fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class2AspectSubpkg3Class2AspectProperties _self_ = fr.inria.diverse.melange.tests.multipkgs.aspects.Subpkg3Class2AspectSubpkg3Class2AspectContext.getSelf(_self);
    _privk3_visit(_self_, _self);;
  }
  
  protected static void _privk3_visit(final Subpkg3Class2AspectSubpkg3Class2AspectProperties _self_, final Subpkg3Class2 _self) {
    EClass _eClass = _self.eClass();
    String _name = _eClass.getName();
    InputOutput.<String>println(_name);
  }
}
