/**
 */
package fr.inria.diverse.root;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>A</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.inria.diverse.root.RootPackage#getA()
 * @model
 * @generated
 */
public interface A extends EObject {
} // A
