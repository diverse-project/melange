package fr.inria.diverse.melange.slicing.aspects;

import fr.inria.diverse.melange.slicing.aspects.SubAAspectSubAAspectProperties;
import java.util.Map;
import root.SubA;

@SuppressWarnings("all")
public class SubAAspectSubAAspectContext {
  public final static SubAAspectSubAAspectContext INSTANCE = new SubAAspectSubAAspectContext();
  
  public static SubAAspectSubAAspectProperties getSelf(final SubA _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.slicing.aspects.SubAAspectSubAAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<SubA, SubAAspectSubAAspectProperties> map = new java.util.WeakHashMap<root.SubA, fr.inria.diverse.melange.slicing.aspects.SubAAspectSubAAspectProperties>();
  
  public Map<SubA, SubAAspectSubAAspectProperties> getMap() {
    return map;
  }
}
