package fr.inria.diverse.melange.slicing.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.slicing.aspects.SubAAspectSubAAspectProperties;
import root.SubA;

@Aspect(className = SubA.class)
@SuppressWarnings("all")
public class SubAAspect {
  public static String attrib3(final SubA _self) {
    fr.inria.diverse.melange.slicing.aspects.SubAAspectSubAAspectProperties _self_ = fr.inria.diverse.melange.slicing.aspects.SubAAspectSubAAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_attrib3(_self_, _self);
    return (java.lang.String)result;
  }
  
  public static void attrib3(final SubA _self, final String attrib3) {
    fr.inria.diverse.melange.slicing.aspects.SubAAspectSubAAspectProperties _self_ = fr.inria.diverse.melange.slicing.aspects.SubAAspectSubAAspectContext.getSelf(_self);
    _privk3_attrib3(_self_, _self,attrib3);
  }
  
  protected static String _privk3_attrib3(final SubAAspectSubAAspectProperties _self_, final SubA _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getAttrib3") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (java.lang.String) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.attrib3;
  }
  
  protected static void _privk3_attrib3(final SubAAspectSubAAspectProperties _self_, final SubA _self, final String attrib3) {
    _self_.attrib3 = attrib3; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setAttrib3")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, attrib3);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
