package fr.inria.diverse.melange.slicing.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.slicing.aspects.BAspectBAspectProperties;
import root.B;

@Aspect(className = B.class)
@SuppressWarnings("all")
public class BAspect {
  public static String attrib4(final B _self) {
    fr.inria.diverse.melange.slicing.aspects.BAspectBAspectProperties _self_ = fr.inria.diverse.melange.slicing.aspects.BAspectBAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_attrib4(_self_, _self);
    return (java.lang.String)result;
  }
  
  public static void attrib4(final B _self, final String attrib4) {
    fr.inria.diverse.melange.slicing.aspects.BAspectBAspectProperties _self_ = fr.inria.diverse.melange.slicing.aspects.BAspectBAspectContext.getSelf(_self);
    _privk3_attrib4(_self_, _self,attrib4);
  }
  
  protected static String _privk3_attrib4(final BAspectBAspectProperties _self_, final B _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getAttrib4") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (java.lang.String) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.attrib4;
  }
  
  protected static void _privk3_attrib4(final BAspectBAspectProperties _self_, final B _self, final String attrib4) {
    _self_.attrib4 = attrib4; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setAttrib4")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, attrib4);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
