package fr.inria.diverse.melange.slicing.aspects;

@SuppressWarnings("all")
public class SuperAAspectSuperAAspectProperties {
  public String attrib;
}
