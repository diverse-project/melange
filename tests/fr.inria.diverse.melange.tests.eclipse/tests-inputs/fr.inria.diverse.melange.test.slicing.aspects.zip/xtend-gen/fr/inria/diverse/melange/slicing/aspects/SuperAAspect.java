package fr.inria.diverse.melange.slicing.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.slicing.aspects.SuperAAspectSuperAAspectProperties;
import root.SuperA;

@Aspect(className = SuperA.class)
@SuppressWarnings("all")
public class SuperAAspect {
  public static String attrib1(final SuperA _self) {
    fr.inria.diverse.melange.slicing.aspects.SuperAAspectSuperAAspectProperties _self_ = fr.inria.diverse.melange.slicing.aspects.SuperAAspectSuperAAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_attrib1(_self_, _self);
    return (java.lang.String)result;
  }
  
  public static void attrib1(final SuperA _self, final String attrib1) {
    fr.inria.diverse.melange.slicing.aspects.SuperAAspectSuperAAspectProperties _self_ = fr.inria.diverse.melange.slicing.aspects.SuperAAspectSuperAAspectContext.getSelf(_self);
    _privk3_attrib1(_self_, _self,attrib1);
  }
  
  protected static String _privk3_attrib1(final SuperAAspectSuperAAspectProperties _self_, final SuperA _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getAttrib1") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (java.lang.String) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.attrib1;
  }
  
  protected static void _privk3_attrib1(final SuperAAspectSuperAAspectProperties _self_, final SuperA _self, final String attrib1) {
    _self_.attrib1 = attrib1; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setAttrib1")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, attrib1);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
