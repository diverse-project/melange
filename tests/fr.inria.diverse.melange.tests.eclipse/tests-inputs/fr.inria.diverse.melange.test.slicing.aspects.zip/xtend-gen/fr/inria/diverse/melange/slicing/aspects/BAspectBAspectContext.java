package fr.inria.diverse.melange.slicing.aspects;

import fr.inria.diverse.melange.slicing.aspects.BAspectBAspectProperties;
import java.util.Map;
import root.B;

@SuppressWarnings("all")
public class BAspectBAspectContext {
  public final static BAspectBAspectContext INSTANCE = new BAspectBAspectContext();
  
  public static BAspectBAspectProperties getSelf(final B _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.slicing.aspects.BAspectBAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<B, BAspectBAspectProperties> map = new java.util.WeakHashMap<root.B, fr.inria.diverse.melange.slicing.aspects.BAspectBAspectProperties>();
  
  public Map<B, BAspectBAspectProperties> getMap() {
    return map;
  }
}
