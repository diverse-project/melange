package fr.inria.diverse.melange.slicing.aspects;

@SuppressWarnings("all")
public class SubAAspectSubAAspectProperties {
  public String attrib;
}
