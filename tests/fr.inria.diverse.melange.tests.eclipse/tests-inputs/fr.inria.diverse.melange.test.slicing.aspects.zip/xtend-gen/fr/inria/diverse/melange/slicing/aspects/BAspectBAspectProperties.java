package fr.inria.diverse.melange.slicing.aspects;

@SuppressWarnings("all")
public class BAspectBAspectProperties {
  public String attrib;
}
