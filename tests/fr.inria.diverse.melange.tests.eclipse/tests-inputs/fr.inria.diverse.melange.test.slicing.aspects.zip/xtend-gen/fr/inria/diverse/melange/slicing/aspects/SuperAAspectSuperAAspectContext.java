package fr.inria.diverse.melange.slicing.aspects;

import fr.inria.diverse.melange.slicing.aspects.SuperAAspectSuperAAspectProperties;
import java.util.Map;
import root.SuperA;

@SuppressWarnings("all")
public class SuperAAspectSuperAAspectContext {
  public final static SuperAAspectSuperAAspectContext INSTANCE = new SuperAAspectSuperAAspectContext();
  
  public static SuperAAspectSuperAAspectProperties getSelf(final SuperA _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.slicing.aspects.SuperAAspectSuperAAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<SuperA, SuperAAspectSuperAAspectProperties> map = new java.util.WeakHashMap<root.SuperA, fr.inria.diverse.melange.slicing.aspects.SuperAAspectSuperAAspectProperties>();
  
  public Map<SuperA, SuperAAspectSuperAAspectProperties> getMap() {
    return map;
  }
}
