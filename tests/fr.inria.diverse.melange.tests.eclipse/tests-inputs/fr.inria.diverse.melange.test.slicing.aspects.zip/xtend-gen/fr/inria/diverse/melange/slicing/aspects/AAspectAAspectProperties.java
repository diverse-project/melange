package fr.inria.diverse.melange.slicing.aspects;

@SuppressWarnings("all")
public class AAspectAAspectProperties {
  public String attrib2;
}
