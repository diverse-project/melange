package fr.inria.diverse.melange.slicing.aspects;

import fr.inria.diverse.melange.slicing.aspects.AAspectAAspectProperties;
import java.util.Map;
import root.A;

@SuppressWarnings("all")
public class AAspectAAspectContext {
  public final static AAspectAAspectContext INSTANCE = new AAspectAAspectContext();
  
  public static AAspectAAspectProperties getSelf(final A _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.slicing.aspects.AAspectAAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<A, AAspectAAspectProperties> map = new java.util.WeakHashMap<root.A, fr.inria.diverse.melange.slicing.aspects.AAspectAAspectProperties>();
  
  public Map<A, AAspectAAspectProperties> getMap() {
    return map;
  }
}
