package dispatch.melange.l4;

import dispatch.melange.l1.BAspect;
import dispatch.melange.l4.SubBAspectSubBAspectProperties;
import extension.dispatchroot.SubB;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.xtext.xbase.lib.InputOutput;

@Aspect(className = SubB.class)
@SuppressWarnings("all")
public class SubBAspect extends BAspect {
  public static void foo(final SubB _self) {
    final dispatch.melange.l4.SubBAspectSubBAspectProperties _self_ = dispatch.melange.l4.SubBAspectSubBAspectContext.getSelf(_self);
    _privk3_foo(_self_, _self);;
  }
  
  protected static void _privk3_foo(final SubBAspectSubBAspectProperties _self_, final SubB _self) {
    InputOutput.<String>println("L4 - SubB.foo()");
  }
}
