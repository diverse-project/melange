package dispatch.melange.l4;

@SuppressWarnings("all")
public class SubBAspectSubBAspectProperties {
}
