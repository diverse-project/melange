package dispatch.melange.l4;

import dispatch.melange.l4.SubBAspectSubBAspectProperties;
import extension.dispatchroot.SubB;
import java.util.Map;

@SuppressWarnings("all")
public class SubBAspectSubBAspectContext {
  public final static SubBAspectSubBAspectContext INSTANCE = new SubBAspectSubBAspectContext();
  
  public static SubBAspectSubBAspectProperties getSelf(final SubB _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new dispatch.melange.l4.SubBAspectSubBAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<SubB, SubBAspectSubBAspectProperties> map = new java.util.WeakHashMap<extension.dispatchroot.SubB, dispatch.melange.l4.SubBAspectSubBAspectProperties>();
  
  public Map<SubB, SubBAspectSubBAspectProperties> getMap() {
    return map;
  }
}
