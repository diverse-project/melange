package dispatch.melange.l3;

import dispatch.melange.l1.BAspect;
import dispatch.melange.l3.L3_BAspectBAspectProperties;
import dispatchroot.B;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.xtext.xbase.lib.InputOutput;

@Aspect(className = B.class)
@SuppressWarnings("all")
public class L3_BAspect extends BAspect {
  public static void foo(final B _self) {
    final dispatch.melange.l3.L3_BAspectBAspectProperties _self_ = dispatch.melange.l3.L3_BAspectBAspectContext.getSelf(_self);
    _privk3_foo(_self_, _self);;
  }
  
  protected static void _privk3_foo(final L3_BAspectBAspectProperties _self_, final B _self) {
    InputOutput.<String>println("L3 - B.foo()");
  }
}
