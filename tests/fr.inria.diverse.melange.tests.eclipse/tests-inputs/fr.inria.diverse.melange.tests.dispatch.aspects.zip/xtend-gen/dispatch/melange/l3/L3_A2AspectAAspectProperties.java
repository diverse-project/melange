package dispatch.melange.l3;

@SuppressWarnings("all")
public class L3_A2AspectAAspectProperties {
}
