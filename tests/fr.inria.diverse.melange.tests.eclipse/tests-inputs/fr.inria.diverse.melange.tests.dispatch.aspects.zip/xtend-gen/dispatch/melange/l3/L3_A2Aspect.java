package dispatch.melange.l3;

import dispatch.melange.l3.L3_A2AspectAAspectProperties;
import dispatchroot.A;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.xtext.xbase.lib.InputOutput;

@Aspect(className = A.class)
@SuppressWarnings("all")
public class L3_A2Aspect {
  public static void bar(final A _self) {
    final dispatch.melange.l3.L3_A2AspectAAspectProperties _self_ = dispatch.melange.l3.L3_A2AspectAAspectContext.getSelf(_self);
    _privk3_bar(_self_, _self);;
  }
  
  protected static void _privk3_bar(final L3_A2AspectAAspectProperties _self_, final A _self) {
    InputOutput.<String>println("L3 - A2.bar()");
  }
}
