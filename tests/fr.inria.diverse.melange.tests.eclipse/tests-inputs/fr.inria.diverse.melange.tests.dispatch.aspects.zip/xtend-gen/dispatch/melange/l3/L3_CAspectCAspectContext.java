package dispatch.melange.l3;

import dispatch.melange.l3.L3_CAspectCAspectProperties;
import dispatchroot.C;
import java.util.Map;

@SuppressWarnings("all")
public class L3_CAspectCAspectContext {
  public final static L3_CAspectCAspectContext INSTANCE = new L3_CAspectCAspectContext();
  
  public static L3_CAspectCAspectProperties getSelf(final C _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new dispatch.melange.l3.L3_CAspectCAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<C, L3_CAspectCAspectProperties> map = new java.util.WeakHashMap<dispatchroot.C, dispatch.melange.l3.L3_CAspectCAspectProperties>();
  
  public Map<C, L3_CAspectCAspectProperties> getMap() {
    return map;
  }
}
