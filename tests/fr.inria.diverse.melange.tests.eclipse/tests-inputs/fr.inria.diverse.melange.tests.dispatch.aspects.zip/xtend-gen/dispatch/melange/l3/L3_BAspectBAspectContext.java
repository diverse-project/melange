package dispatch.melange.l3;

import dispatch.melange.l3.L3_BAspectBAspectProperties;
import dispatchroot.B;
import java.util.Map;

@SuppressWarnings("all")
public class L3_BAspectBAspectContext {
  public final static L3_BAspectBAspectContext INSTANCE = new L3_BAspectBAspectContext();
  
  public static L3_BAspectBAspectProperties getSelf(final B _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new dispatch.melange.l3.L3_BAspectBAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<B, L3_BAspectBAspectProperties> map = new java.util.WeakHashMap<dispatchroot.B, dispatch.melange.l3.L3_BAspectBAspectProperties>();
  
  public Map<B, L3_BAspectBAspectProperties> getMap() {
    return map;
  }
}
