package dispatch.melange.l3;

import dispatch.melange.l1.AAspect;
import dispatch.melange.l1.CAspect;
import dispatch.melange.l3.L3_A2Aspect;
import dispatch.melange.l3.L3_CAspectCAspectProperties;
import dispatchroot.A;
import dispatchroot.C;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.xtext.xbase.lib.InputOutput;

@Aspect(className = C.class)
@SuppressWarnings("all")
public class L3_CAspect extends CAspect {
  public static void bar(final C _self, final A a) {
    final dispatch.melange.l3.L3_CAspectCAspectProperties _self_ = dispatch.melange.l3.L3_CAspectCAspectContext.getSelf(_self);
    _privk3_bar(_self_, _self,a);;
  }
  
  protected static void _privk3_bar(final L3_CAspectCAspectProperties _self_, final C _self, final A a) {
    InputOutput.<String>print("L3 - C.bar() calling : ");
    AAspect.foo(a);
    L3_A2Aspect.bar(a);
  }
}
