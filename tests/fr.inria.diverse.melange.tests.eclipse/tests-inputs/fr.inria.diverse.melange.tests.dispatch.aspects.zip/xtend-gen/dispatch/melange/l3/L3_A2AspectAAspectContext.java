package dispatch.melange.l3;

import dispatch.melange.l3.L3_A2AspectAAspectProperties;
import dispatchroot.A;
import java.util.Map;

@SuppressWarnings("all")
public class L3_A2AspectAAspectContext {
  public final static L3_A2AspectAAspectContext INSTANCE = new L3_A2AspectAAspectContext();
  
  public static L3_A2AspectAAspectProperties getSelf(final A _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new dispatch.melange.l3.L3_A2AspectAAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<A, L3_A2AspectAAspectProperties> map = new java.util.WeakHashMap<dispatchroot.A, dispatch.melange.l3.L3_A2AspectAAspectProperties>();
  
  public Map<A, L3_A2AspectAAspectProperties> getMap() {
    return map;
  }
}
