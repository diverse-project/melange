package dispatch.melange.l2;

@SuppressWarnings("all")
public class L2_AAspectAAspectProperties {
}
