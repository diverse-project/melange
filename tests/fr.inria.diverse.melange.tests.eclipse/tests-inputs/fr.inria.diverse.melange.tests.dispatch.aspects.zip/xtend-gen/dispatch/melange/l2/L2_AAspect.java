package dispatch.melange.l2;

import dispatch.melange.l1.AAspect;
import dispatch.melange.l2.L2_AAspectAAspectProperties;
import dispatchroot.A;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.xtext.xbase.lib.InputOutput;

@Aspect(className = A.class)
@SuppressWarnings("all")
public class L2_AAspect extends AAspect {
  public static void foo(final A _self) {
    final dispatch.melange.l2.L2_AAspectAAspectProperties _self_ = dispatch.melange.l2.L2_AAspectAAspectContext.getSelf(_self);
    _privk3_foo(_self_, _self);;
  }
  
  protected static void _privk3_foo(final L2_AAspectAAspectProperties _self_, final A _self) {
    InputOutput.<String>println("L2 - A.foo()");
  }
}
