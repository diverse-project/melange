package dispatch.melange.l2;

import dispatch.melange.l2.L2_AAspectAAspectProperties;
import dispatchroot.A;
import java.util.Map;

@SuppressWarnings("all")
public class L2_AAspectAAspectContext {
  public final static L2_AAspectAAspectContext INSTANCE = new L2_AAspectAAspectContext();
  
  public static L2_AAspectAAspectProperties getSelf(final A _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new dispatch.melange.l2.L2_AAspectAAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<A, L2_AAspectAAspectProperties> map = new java.util.WeakHashMap<dispatchroot.A, dispatch.melange.l2.L2_AAspectAAspectProperties>();
  
  public Map<A, L2_AAspectAAspectProperties> getMap() {
    return map;
  }
}
