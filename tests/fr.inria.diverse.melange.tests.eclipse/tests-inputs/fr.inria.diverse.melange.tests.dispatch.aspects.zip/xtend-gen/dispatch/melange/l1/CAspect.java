package dispatch.melange.l1;

import dispatch.melange.l1.AAspect;
import dispatch.melange.l1.CAspectCAspectProperties;
import dispatchroot.A;
import dispatchroot.C;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.xtext.xbase.lib.InputOutput;

@Aspect(className = C.class)
@SuppressWarnings("all")
public class CAspect {
  public static void bar(final C _self, final A a) {
    final dispatch.melange.l1.CAspectCAspectProperties _self_ = dispatch.melange.l1.CAspectCAspectContext.getSelf(_self);
    _privk3_bar(_self_, _self,a);;
  }
  
  protected static void _privk3_bar(final CAspectCAspectProperties _self_, final C _self, final A a) {
    InputOutput.<String>print("L1 - C.bar() calling : ");
    AAspect.foo(a);
  }
}
