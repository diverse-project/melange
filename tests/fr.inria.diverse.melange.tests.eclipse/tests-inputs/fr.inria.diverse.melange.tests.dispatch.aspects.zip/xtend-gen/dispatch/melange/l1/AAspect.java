package dispatch.melange.l1;

import dispatch.melange.l1.AAspectAAspectProperties;
import dispatchroot.A;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.xtext.xbase.lib.InputOutput;

@Aspect(className = A.class)
@SuppressWarnings("all")
public class AAspect {
  public static void foo(final A _self) {
    final dispatch.melange.l1.AAspectAAspectProperties _self_ = dispatch.melange.l1.AAspectAAspectContext.getSelf(_self);
     if (_self instanceof dispatchroot.B){
    					dispatch.melange.l1.BAspect.foo((dispatchroot.B)_self);
    } else  if (_self instanceof dispatchroot.A){
    					dispatch.melange.l1.AAspect._privk3_foo(_self_, (dispatchroot.A)_self);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_foo(final AAspectAAspectProperties _self_, final A _self) {
    InputOutput.<String>println("L1 - A.foo()");
  }
}
