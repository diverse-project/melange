package dispatch.melange.l1;

@SuppressWarnings("all")
public class BAspectBAspectProperties {
}
