package dispatch.melange.l1;

import dispatch.melange.l1.BAspectBAspectProperties;
import dispatchroot.B;
import java.util.Map;

@SuppressWarnings("all")
public class BAspectBAspectContext {
  public final static BAspectBAspectContext INSTANCE = new BAspectBAspectContext();
  
  public static BAspectBAspectProperties getSelf(final B _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new dispatch.melange.l1.BAspectBAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<B, BAspectBAspectProperties> map = new java.util.WeakHashMap<dispatchroot.B, dispatch.melange.l1.BAspectBAspectProperties>();
  
  public Map<B, BAspectBAspectProperties> getMap() {
    return map;
  }
}
