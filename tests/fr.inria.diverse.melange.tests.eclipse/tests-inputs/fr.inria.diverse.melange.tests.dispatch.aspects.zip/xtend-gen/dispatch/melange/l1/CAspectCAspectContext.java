package dispatch.melange.l1;

import dispatch.melange.l1.CAspectCAspectProperties;
import dispatchroot.C;
import java.util.Map;

@SuppressWarnings("all")
public class CAspectCAspectContext {
  public final static CAspectCAspectContext INSTANCE = new CAspectCAspectContext();
  
  public static CAspectCAspectProperties getSelf(final C _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new dispatch.melange.l1.CAspectCAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<C, CAspectCAspectProperties> map = new java.util.WeakHashMap<dispatchroot.C, dispatch.melange.l1.CAspectCAspectProperties>();
  
  public Map<C, CAspectCAspectProperties> getMap() {
    return map;
  }
}
