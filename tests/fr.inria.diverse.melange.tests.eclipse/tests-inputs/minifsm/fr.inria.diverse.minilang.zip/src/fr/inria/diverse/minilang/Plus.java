/**
 */
package fr.inria.diverse.minilang;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Plus</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.inria.diverse.minilang.MinilangPackage#getPlus()
 * @model
 * @generated
 */
public interface Plus extends IntOperation {
} // Plus
