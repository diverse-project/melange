/**
 */
package fr.inria.diverse.minilang.impl;

import fr.inria.diverse.minilang.Greater;
import fr.inria.diverse.minilang.MinilangPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Greater</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class GreaterImpl extends IntComparisonImpl implements Greater {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GreaterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MinilangPackage.Literals.GREATER;
	}

} //GreaterImpl
