/**
 */
package fr.inria.diverse.minilang;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Int Variable Ref</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.inria.diverse.minilang.MinilangPackage#getIntVariableRef()
 * @model
 * @generated
 */
public interface IntVariableRef extends VariableRef, IntExpression {
} // IntVariableRef
