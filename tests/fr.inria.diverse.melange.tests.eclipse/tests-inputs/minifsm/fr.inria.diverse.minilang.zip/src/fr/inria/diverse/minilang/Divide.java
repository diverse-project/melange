/**
 */
package fr.inria.diverse.minilang;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Divide</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.inria.diverse.minilang.MinilangPackage#getDivide()
 * @model
 * @generated
 */
public interface Divide extends IntOperation {
} // Divide
