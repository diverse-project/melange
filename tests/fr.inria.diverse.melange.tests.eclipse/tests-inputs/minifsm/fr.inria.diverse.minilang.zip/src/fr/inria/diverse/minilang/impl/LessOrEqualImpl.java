/**
 */
package fr.inria.diverse.minilang.impl;

import fr.inria.diverse.minilang.LessOrEqual;
import fr.inria.diverse.minilang.MinilangPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Less Or Equal</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LessOrEqualImpl extends IntComparisonImpl implements LessOrEqual {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LessOrEqualImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MinilangPackage.Literals.LESS_OR_EQUAL;
	}

} //LessOrEqualImpl
