/**
 */
package fr.inria.diverse.minilang.impl;

import fr.inria.diverse.minilang.MinilangPackage;
import fr.inria.diverse.minilang.Plus;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Plus</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PlusImpl extends IntOperationImpl implements Plus {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PlusImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MinilangPackage.Literals.PLUS;
	}

} //PlusImpl
