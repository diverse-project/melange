/**
 */
package fr.inria.diverse.minilang;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Equal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.inria.diverse.minilang.MinilangPackage#getEqual()
 * @model
 * @generated
 */
public interface Equal extends IntComparison {
} // Equal
