/**
 */
package fr.inria.diverse.minilang.impl;

import fr.inria.diverse.minilang.IntExpression;
import fr.inria.diverse.minilang.MinilangPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Int Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class IntExpressionImpl extends MinimalEObjectImpl.Container implements IntExpression {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IntExpressionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MinilangPackage.Literals.INT_EXPRESSION;
	}

} //IntExpressionImpl
