/**
 */
package fr.inria.diverse.minilang;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Greater</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.inria.diverse.minilang.MinilangPackage#getGreater()
 * @model
 * @generated
 */
public interface Greater extends IntComparison {
} // Greater
