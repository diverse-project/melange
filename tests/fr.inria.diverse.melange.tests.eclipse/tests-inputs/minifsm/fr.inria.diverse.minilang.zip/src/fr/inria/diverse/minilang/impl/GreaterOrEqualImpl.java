/**
 */
package fr.inria.diverse.minilang.impl;

import fr.inria.diverse.minilang.GreaterOrEqual;
import fr.inria.diverse.minilang.MinilangPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Greater Or Equal</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class GreaterOrEqualImpl extends IntComparisonImpl implements GreaterOrEqual {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GreaterOrEqualImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MinilangPackage.Literals.GREATER_OR_EQUAL;
	}

} //GreaterOrEqualImpl
