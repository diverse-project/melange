/**
 */
package fr.inria.diverse.minilang.impl;

import fr.inria.diverse.minilang.BooleanExpression;
import fr.inria.diverse.minilang.MinilangPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Boolean Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BooleanExpressionImpl extends MinimalEObjectImpl.Container implements BooleanExpression {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BooleanExpressionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MinilangPackage.Literals.BOOLEAN_EXPRESSION;
	}

} //BooleanExpressionImpl
