/**
 */
package fr.inria.diverse.minilang.impl;

import fr.inria.diverse.minilang.IntVariableRef;
import fr.inria.diverse.minilang.MinilangPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Int Variable Ref</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class IntVariableRefImpl extends VariableRefImpl implements IntVariableRef {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IntVariableRefImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MinilangPackage.Literals.INT_VARIABLE_REF;
	}

} //IntVariableRefImpl
