/**
 */
package fr.inria.diverse.minilang.impl;

import fr.inria.diverse.minilang.BooleanVariableRef;
import fr.inria.diverse.minilang.MinilangPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Boolean Variable Ref</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class BooleanVariableRefImpl extends VariableRefImpl implements BooleanVariableRef {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BooleanVariableRefImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MinilangPackage.Literals.BOOLEAN_VARIABLE_REF;
	}

} //BooleanVariableRefImpl
