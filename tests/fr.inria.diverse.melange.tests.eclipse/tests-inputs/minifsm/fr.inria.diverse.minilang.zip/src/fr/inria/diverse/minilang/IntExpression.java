/**
 */
package fr.inria.diverse.minilang;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Int Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.inria.diverse.minilang.MinilangPackage#getIntExpression()
 * @model
 * @generated
 */
public interface IntExpression extends EObject {
} // IntExpression
