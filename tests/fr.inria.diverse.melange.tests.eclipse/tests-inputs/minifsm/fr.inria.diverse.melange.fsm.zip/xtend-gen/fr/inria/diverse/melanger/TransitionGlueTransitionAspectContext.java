package fr.inria.diverse.melanger;

import fr.inria.diverse.melanger.TransitionGlueTransitionAspectProperties;
import fr.inria.diverse.minifsm.Transition;
import java.util.Map;

@SuppressWarnings("all")
public class TransitionGlueTransitionAspectContext {
  public final static TransitionGlueTransitionAspectContext INSTANCE = new TransitionGlueTransitionAspectContext();
  
  public static TransitionGlueTransitionAspectProperties getSelf(final Transition _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melanger.TransitionGlueTransitionAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Transition, TransitionGlueTransitionAspectProperties> map = new java.util.WeakHashMap<fr.inria.diverse.minifsm.Transition, fr.inria.diverse.melanger.TransitionGlueTransitionAspectProperties>();
  
  public Map<Transition, TransitionGlueTransitionAspectProperties> getMap() {
    return map;
  }
}
