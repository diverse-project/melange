package fr.inria.diverse.melanger;

import fr.inria.diverse.melanger.FSMGlueFSMAspectProperties;
import fr.inria.diverse.minifsm.FSM;
import java.util.Map;

@SuppressWarnings("all")
public class FSMGlueFSMAspectContext {
  public final static FSMGlueFSMAspectContext INSTANCE = new FSMGlueFSMAspectContext();
  
  public static FSMGlueFSMAspectProperties getSelf(final FSM _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melanger.FSMGlueFSMAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<FSM, FSMGlueFSMAspectProperties> map = new java.util.WeakHashMap<fr.inria.diverse.minifsm.FSM, fr.inria.diverse.melanger.FSMGlueFSMAspectProperties>();
  
  public Map<FSM, FSMGlueFSMAspectProperties> getMap() {
    return map;
  }
}
