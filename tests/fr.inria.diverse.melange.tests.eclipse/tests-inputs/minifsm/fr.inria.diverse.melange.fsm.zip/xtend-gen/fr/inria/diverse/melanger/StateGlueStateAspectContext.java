package fr.inria.diverse.melanger;

import fr.inria.diverse.melanger.StateGlueStateAspectProperties;
import fr.inria.diverse.minifsm.State;
import java.util.Map;

@SuppressWarnings("all")
public class StateGlueStateAspectContext {
  public final static StateGlueStateAspectContext INSTANCE = new StateGlueStateAspectContext();
  
  public static StateGlueStateAspectProperties getSelf(final State _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melanger.StateGlueStateAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<State, StateGlueStateAspectProperties> map = new java.util.WeakHashMap<fr.inria.diverse.minifsm.State, fr.inria.diverse.melanger.StateGlueStateAspectProperties>();
  
  public Map<State, StateGlueStateAspectProperties> getMap() {
    return map;
  }
}
