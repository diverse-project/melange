package fr.inria.diverse.melanger;

import fr.inria.diverse.minilang.Block;

@SuppressWarnings("all")
public class StateGlueStateAspectProperties {
  public Block block;
}
