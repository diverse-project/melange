package fr.inria.diverse.melanger;

import fr.inria.diverse.melanger.FinalStateGlueFinalStateAspectProperties;
import fr.inria.diverse.minifsm.FinalState;
import java.util.Map;

@SuppressWarnings("all")
public class FinalStateGlueFinalStateAspectContext {
  public final static FinalStateGlueFinalStateAspectContext INSTANCE = new FinalStateGlueFinalStateAspectContext();
  
  public static FinalStateGlueFinalStateAspectProperties getSelf(final FinalState _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melanger.FinalStateGlueFinalStateAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<FinalState, FinalStateGlueFinalStateAspectProperties> map = new java.util.WeakHashMap<fr.inria.diverse.minifsm.FinalState, fr.inria.diverse.melanger.FinalStateGlueFinalStateAspectProperties>();
  
  public Map<FinalState, FinalStateGlueFinalStateAspectProperties> getMap() {
    return map;
  }
}
