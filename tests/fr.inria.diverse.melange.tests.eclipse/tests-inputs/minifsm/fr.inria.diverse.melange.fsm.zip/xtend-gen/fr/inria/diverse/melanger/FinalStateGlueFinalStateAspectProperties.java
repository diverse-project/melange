package fr.inria.diverse.melanger;

@SuppressWarnings("all")
public class FinalStateGlueFinalStateAspectProperties {
}
