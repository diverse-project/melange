package fr.inria.diverse.melanger;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import fr.inria.diverse.melanger.FinalStateGlueFinalStateAspectProperties;
import fr.inria.diverse.melanger.StateGlue;
import fr.inria.diverse.minifsm.FinalState;
import org.eclipse.xtext.xbase.lib.InputOutput;

@Aspect(className = FinalState.class)
@SuppressWarnings("all")
public class FinalStateGlue extends StateGlue {
  @OverrideAspectMethod
  public static void execute(final FinalState _self) {
    final fr.inria.diverse.melanger.FinalStateGlueFinalStateAspectProperties _self_ = fr.inria.diverse.melanger.FinalStateGlueFinalStateAspectContext.getSelf(_self);
     if (_self instanceof fr.inria.diverse.minifsm.FinalState){
    					fr.inria.diverse.melanger.FinalStateGlue._privk3_execute(_self_, (fr.inria.diverse.minifsm.FinalState)_self);
    } else  if (_self instanceof fr.inria.diverse.minifsm.State){
    					fr.inria.diverse.melanger.StateGlue.execute((fr.inria.diverse.minifsm.State)_self);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  private static void super_execute(final FinalState _self) {
    final fr.inria.diverse.melanger.StateGlueStateAspectProperties _self_ = fr.inria.diverse.melanger.StateGlueStateAspectContext.getSelf(_self);
     fr.inria.diverse.melanger.StateGlue._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final FinalStateGlueFinalStateAspectProperties _self_, final FinalState _self) {
    FinalStateGlue.super_execute(_self);
    InputOutput.<String>println("End");
  }
}
