package fr.inria.diverse.melanger;

import fr.inria.diverse.context.minilang.Context;

@SuppressWarnings("all")
public class FSMGlueFSMAspectProperties {
  public Context context;
}
