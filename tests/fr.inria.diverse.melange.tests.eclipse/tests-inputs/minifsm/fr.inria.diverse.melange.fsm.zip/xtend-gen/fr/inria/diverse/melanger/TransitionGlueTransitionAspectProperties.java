package fr.inria.diverse.melanger;

import fr.inria.diverse.minilang.BooleanExpression;

@SuppressWarnings("all")
public class TransitionGlueTransitionAspectProperties {
  public BooleanExpression expression;
}
