package fr.inria.diverse.melanger;

import fr.inria.diverse.context.minilang.Context;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.Containment;
import fr.inria.diverse.melanger.FSMGlue;
import fr.inria.diverse.melanger.StateGlueStateAspectProperties;
import fr.inria.diverse.minifsm.FSM;
import fr.inria.diverse.minifsm.State;
import fr.inria.diverse.minilang.Block;
import fr.inria.diverse.minilang.Statement;
import java.util.function.Consumer;
import minifsm.aspects.StateAspect;
import minilang.aspects.StatementAspect;
import org.eclipse.emf.common.util.EList;

@Aspect(className = State.class)
@SuppressWarnings("all")
public class StateGlue extends StateAspect {
  public static void execute(final State _self) {
    final fr.inria.diverse.melanger.StateGlueStateAspectProperties _self_ = fr.inria.diverse.melanger.StateGlueStateAspectContext.getSelf(_self);
     if (_self instanceof fr.inria.diverse.minifsm.FinalState){
    					fr.inria.diverse.melanger.FinalStateGlue.execute((fr.inria.diverse.minifsm.FinalState)_self);
    } else  if (_self instanceof fr.inria.diverse.minifsm.State){
    					fr.inria.diverse.melanger.StateGlue._privk3_execute(_self_, (fr.inria.diverse.minifsm.State)_self);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  @Containment
  public static Block block(final State _self) {
    final fr.inria.diverse.melanger.StateGlueStateAspectProperties _self_ = fr.inria.diverse.melanger.StateGlueStateAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_block(_self_, _self);;
    return (fr.inria.diverse.minilang.Block)result;
  }
  
  @Containment
  public static void block(final State _self, final Block block) {
    final fr.inria.diverse.melanger.StateGlueStateAspectProperties _self_ = fr.inria.diverse.melanger.StateGlueStateAspectContext.getSelf(_self);
    _privk3_block(_self_, _self,block);;
  }
  
  protected static void _privk3_execute(final StateGlueStateAspectProperties _self_, final State _self) {
    Block _block = StateGlue.block(_self);
    EList<Statement> _statement = null;
    if (_block!=null) {
      _statement=_block.getStatement();
    }
    if (_statement!=null) {
      final Consumer<Statement> _function = (Statement it) -> {
        FSM _fsm = _self.getFsm();
        Context _context = FSMGlue.context(_fsm);
        StatementAspect.execute(it, _context);
      };
      _statement.forEach(_function);
    }
  }
  
  protected static Block _privk3_block(final StateGlueStateAspectProperties _self_, final State _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getBlock") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (fr.inria.diverse.minilang.Block) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.block;
  }
  
  protected static void _privk3_block(final StateGlueStateAspectProperties _self_, final State _self, final Block block) {
    _self_.block = block; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setBlock")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, block);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
