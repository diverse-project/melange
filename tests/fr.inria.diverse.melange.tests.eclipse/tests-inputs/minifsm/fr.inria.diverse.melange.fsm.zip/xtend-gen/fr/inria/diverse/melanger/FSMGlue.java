package fr.inria.diverse.melanger;

import fr.inria.diverse.context.minilang.Context;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.annotation.Containment;
import fr.inria.diverse.melanger.FSMGlueFSMAspectProperties;
import fr.inria.diverse.minifsm.FSM;
import minifsm.aspects.FSMAspect;

@Aspect(className = FSM.class)
@SuppressWarnings("all")
public class FSMGlue extends FSMAspect {
  @Containment
  public static Context context(final FSM _self) {
    final fr.inria.diverse.melanger.FSMGlueFSMAspectProperties _self_ = fr.inria.diverse.melanger.FSMGlueFSMAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_context(_self_, _self);;
    return (fr.inria.diverse.context.minilang.Context)result;
  }
  
  @Containment
  public static void context(final FSM _self, final Context context) {
    final fr.inria.diverse.melanger.FSMGlueFSMAspectProperties _self_ = fr.inria.diverse.melanger.FSMGlueFSMAspectContext.getSelf(_self);
    _privk3_context(_self_, _self,context);;
  }
  
  protected static Context _privk3_context(final FSMGlueFSMAspectProperties _self_, final FSM _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getContext") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (fr.inria.diverse.context.minilang.Context) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.context;
  }
  
  protected static void _privk3_context(final FSMGlueFSMAspectProperties _self_, final FSM _self, final Context context) {
    _self_.context = context; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setContext")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, context);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
