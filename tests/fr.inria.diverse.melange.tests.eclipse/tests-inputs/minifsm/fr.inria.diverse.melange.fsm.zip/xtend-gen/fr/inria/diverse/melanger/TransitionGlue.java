package fr.inria.diverse.melanger;

import com.google.common.base.Objects;
import fr.inria.diverse.context.minilang.Context;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.Containment;
import fr.inria.diverse.melanger.FSMGlue;
import fr.inria.diverse.melanger.TransitionGlueTransitionAspectProperties;
import fr.inria.diverse.minifsm.FSM;
import fr.inria.diverse.minifsm.Transition;
import fr.inria.diverse.minilang.BooleanExpression;
import minifsm.aspects.TransitionAspect;
import minilang.aspects.BooleanExpressionAspect;

@Aspect(className = Transition.class)
@SuppressWarnings("all")
public class TransitionGlue extends TransitionAspect {
  public static boolean isActivated(final Transition _self) {
    final fr.inria.diverse.melanger.TransitionGlueTransitionAspectProperties _self_ = fr.inria.diverse.melanger.TransitionGlueTransitionAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_isActivated(_self_, _self);;
    return (boolean)result;
  }
  
  @Containment
  public static BooleanExpression expression(final Transition _self) {
    final fr.inria.diverse.melanger.TransitionGlueTransitionAspectProperties _self_ = fr.inria.diverse.melanger.TransitionGlueTransitionAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_expression(_self_, _self);;
    return (fr.inria.diverse.minilang.BooleanExpression)result;
  }
  
  @Containment
  public static void expression(final Transition _self, final BooleanExpression expression) {
    final fr.inria.diverse.melanger.TransitionGlueTransitionAspectProperties _self_ = fr.inria.diverse.melanger.TransitionGlueTransitionAspectContext.getSelf(_self);
    _privk3_expression(_self_, _self,expression);;
  }
  
  protected static boolean _privk3_isActivated(final TransitionGlueTransitionAspectProperties _self_, final Transition _self) {
    boolean _or = false;
    BooleanExpression _expression = TransitionGlue.expression(_self);
    boolean _equals = Objects.equal(_expression, null);
    if (_equals) {
      _or = true;
    } else {
      BooleanExpression _expression_1 = TransitionGlue.expression(_self);
      FSM _fsm = _self.getFsm();
      Context _context = FSMGlue.context(_fsm);
      boolean _eval = BooleanExpressionAspect.eval(_expression_1, _context);
      _or = _eval;
    }
    return _or;
  }
  
  protected static BooleanExpression _privk3_expression(final TransitionGlueTransitionAspectProperties _self_, final Transition _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getExpression") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (fr.inria.diverse.minilang.BooleanExpression) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.expression;
  }
  
  protected static void _privk3_expression(final TransitionGlueTransitionAspectProperties _self_, final Transition _self, final BooleanExpression expression) {
    _self_.expression = expression; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setExpression")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, expression);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
