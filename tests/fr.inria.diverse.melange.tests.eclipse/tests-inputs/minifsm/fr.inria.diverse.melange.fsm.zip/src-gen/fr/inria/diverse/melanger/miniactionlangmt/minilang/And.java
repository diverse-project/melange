/**
 */
package fr.inria.diverse.melanger.miniactionlangmt.minilang;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>And</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.inria.diverse.melanger.miniactionlangmt.minilang.MinilangPackage#getAnd()
 * @model
 * @generated
 */
public interface And extends BooleanOperation {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	boolean eval(Context ctx);

} // And
