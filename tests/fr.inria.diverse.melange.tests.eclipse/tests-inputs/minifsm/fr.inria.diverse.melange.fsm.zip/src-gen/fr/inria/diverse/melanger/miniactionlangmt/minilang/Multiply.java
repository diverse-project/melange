/**
 */
package fr.inria.diverse.melanger.miniactionlangmt.minilang;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Multiply</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.inria.diverse.melanger.miniactionlangmt.minilang.MinilangPackage#getMultiply()
 * @model
 * @generated
 */
public interface Multiply extends IntOperation {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	int eval(Context ctx);

} // Multiply
