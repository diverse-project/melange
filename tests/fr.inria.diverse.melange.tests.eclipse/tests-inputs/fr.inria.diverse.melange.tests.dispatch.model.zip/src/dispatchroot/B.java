/**
 */
package dispatchroot;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>B</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dispatchroot.DispatchrootPackage#getB()
 * @model
 * @generated
 */
public interface B extends A {
} // B
