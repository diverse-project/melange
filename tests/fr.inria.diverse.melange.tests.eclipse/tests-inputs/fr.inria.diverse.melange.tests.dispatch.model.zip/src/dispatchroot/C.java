/**
 */
package dispatchroot;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>C</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dispatchroot.DispatchrootPackage#getC()
 * @model
 * @generated
 */
public interface C extends EObject {
} // C
