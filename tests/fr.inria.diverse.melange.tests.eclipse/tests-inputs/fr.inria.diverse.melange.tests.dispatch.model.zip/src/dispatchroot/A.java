/**
 */
package dispatchroot;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>A</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dispatchroot.DispatchrootPackage#getA()
 * @model
 * @generated
 */
public interface A extends EObject {
} // A
