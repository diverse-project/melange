/**
 */
package extension.dispatchroot.impl;

import extension.dispatchroot.DispatchrootPackage;
import extension.dispatchroot.SubB;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sub B</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SubBImpl extends BImpl implements SubB {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SubBImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DispatchrootPackage.Literals.SUB_B;
	}

} //SubBImpl
