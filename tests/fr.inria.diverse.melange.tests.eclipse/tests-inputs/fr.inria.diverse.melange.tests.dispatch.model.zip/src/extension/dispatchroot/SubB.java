/**
 */
package extension.dispatchroot;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sub B</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see extension.dispatchroot.DispatchrootPackage#getSubB()
 * @model
 * @generated
 */
public interface SubB extends B {
} // SubB
