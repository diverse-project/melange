/**
 */
package extension.dispatchroot;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>B</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see extension.dispatchroot.DispatchrootPackage#getB()
 * @model
 * @generated
 */
public interface B extends EObject {
} // B
