package fr.inria.diverse.melange.test.renaming.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.test.renaming.aspects.ClassAAspectClassAAspectProperties;
import some.basepackage.root.ClassA;
import some.basepackage.root.subpackage.ClassB;

@Aspect(className = ClassA.class)
@SuppressWarnings("all")
public class ClassAAspect {
  public static ClassB toB(final ClassA _self) {
    fr.inria.diverse.melange.test.renaming.aspects.ClassAAspectClassAAspectProperties _self_ = fr.inria.diverse.melange.test.renaming.aspects.ClassAAspectClassAAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_toB(_self_, _self);
    return (some.basepackage.root.subpackage.ClassB)result;
  }
  
  public static void toB(final ClassA _self, final ClassB toB) {
    fr.inria.diverse.melange.test.renaming.aspects.ClassAAspectClassAAspectProperties _self_ = fr.inria.diverse.melange.test.renaming.aspects.ClassAAspectClassAAspectContext.getSelf(_self);
    _privk3_toB(_self_, _self,toB);
  }
  
  protected static ClassB _privk3_toB(final ClassAAspectClassAAspectProperties _self_, final ClassA _self) {
     return _self_.toB; 
  }
  
  protected static void _privk3_toB(final ClassAAspectClassAAspectProperties _self_, final ClassA _self, final ClassB toB) {
    _self_.toB = toB; try {
    
    			for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    				if (m.getName().equals("set" + "ToB")
    						&& m.getParameterTypes().length == 1) {
    					m.invoke(_self, toB);
    
    				}
    			}
    		} catch (Exception e) {
    			// Chut !
    		} 
  }
}
