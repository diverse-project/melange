package fr.inria.diverse.melange.test.renaming.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.test.renaming.aspects.SuperBAspectSuperBAspectProperties;
import some.basepackage.root.subpackage.SuperB;

@Aspect(className = SuperB.class)
@SuppressWarnings("all")
public class SuperBAspect {
  public static String attrib(final SuperB _self) {
    fr.inria.diverse.melange.test.renaming.aspects.SuperBAspectSuperBAspectProperties _self_ = fr.inria.diverse.melange.test.renaming.aspects.SuperBAspectSuperBAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_attrib(_self_, _self);
    return (java.lang.String)result;
  }
  
  public static void attrib(final SuperB _self, final String attrib) {
    fr.inria.diverse.melange.test.renaming.aspects.SuperBAspectSuperBAspectProperties _self_ = fr.inria.diverse.melange.test.renaming.aspects.SuperBAspectSuperBAspectContext.getSelf(_self);
    _privk3_attrib(_self_, _self,attrib);
  }
  
  protected static String _privk3_attrib(final SuperBAspectSuperBAspectProperties _self_, final SuperB _self) {
     return _self_.attrib; 
  }
  
  protected static void _privk3_attrib(final SuperBAspectSuperBAspectProperties _self_, final SuperB _self, final String attrib) {
    _self_.attrib = attrib; try {
    
    			for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    				if (m.getName().equals("set" + "Attrib")
    						&& m.getParameterTypes().length == 1) {
    					m.invoke(_self, attrib);
    
    				}
    			}
    		} catch (Exception e) {
    			// Chut !
    		} 
  }
}
