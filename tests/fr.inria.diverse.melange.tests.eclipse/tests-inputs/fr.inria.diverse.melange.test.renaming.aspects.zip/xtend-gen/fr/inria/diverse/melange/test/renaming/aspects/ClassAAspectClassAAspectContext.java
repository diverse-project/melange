package fr.inria.diverse.melange.test.renaming.aspects;

import fr.inria.diverse.melange.test.renaming.aspects.ClassAAspectClassAAspectProperties;
import java.util.Map;
import some.basepackage.root.ClassA;

@SuppressWarnings("all")
public class ClassAAspectClassAAspectContext {
  public final static ClassAAspectClassAAspectContext INSTANCE = new ClassAAspectClassAAspectContext();
  
  public static ClassAAspectClassAAspectProperties getSelf(final ClassA _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.test.renaming.aspects.ClassAAspectClassAAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<ClassA, ClassAAspectClassAAspectProperties> map = new java.util.WeakHashMap<some.basepackage.root.ClassA, fr.inria.diverse.melange.test.renaming.aspects.ClassAAspectClassAAspectProperties>();
  
  public Map<ClassA, ClassAAspectClassAAspectProperties> getMap() {
    return map;
  }
}
