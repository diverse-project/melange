package fr.inria.diverse.melange.test.renaming.aspects;

@SuppressWarnings("all")
public class SuperBAspectSuperBAspectProperties {
  public String attrib;
}
