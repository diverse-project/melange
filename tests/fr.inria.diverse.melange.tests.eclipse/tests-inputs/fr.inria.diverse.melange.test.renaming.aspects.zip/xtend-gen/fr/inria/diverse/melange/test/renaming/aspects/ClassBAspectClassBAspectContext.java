package fr.inria.diverse.melange.test.renaming.aspects;

import fr.inria.diverse.melange.test.renaming.aspects.ClassBAspectClassBAspectProperties;
import java.util.Map;
import some.basepackage.root.subpackage.ClassB;

@SuppressWarnings("all")
public class ClassBAspectClassBAspectContext {
  public final static ClassBAspectClassBAspectContext INSTANCE = new ClassBAspectClassBAspectContext();
  
  public static ClassBAspectClassBAspectProperties getSelf(final ClassB _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.test.renaming.aspects.ClassBAspectClassBAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<ClassB, ClassBAspectClassBAspectProperties> map = new java.util.WeakHashMap<some.basepackage.root.subpackage.ClassB, fr.inria.diverse.melange.test.renaming.aspects.ClassBAspectClassBAspectProperties>();
  
  public Map<ClassB, ClassBAspectClassBAspectProperties> getMap() {
    return map;
  }
}
