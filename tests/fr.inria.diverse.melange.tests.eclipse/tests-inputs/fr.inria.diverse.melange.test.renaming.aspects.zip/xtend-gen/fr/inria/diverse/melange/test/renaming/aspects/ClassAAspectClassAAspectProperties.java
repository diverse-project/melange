package fr.inria.diverse.melange.test.renaming.aspects;

import some.basepackage.root.subpackage.ClassB;

@SuppressWarnings("all")
public class ClassAAspectClassAAspectProperties {
  public ClassB toB;
}
