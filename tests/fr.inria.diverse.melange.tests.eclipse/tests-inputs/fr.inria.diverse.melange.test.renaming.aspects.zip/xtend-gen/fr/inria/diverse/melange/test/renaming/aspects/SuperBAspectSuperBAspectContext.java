package fr.inria.diverse.melange.test.renaming.aspects;

import fr.inria.diverse.melange.test.renaming.aspects.SuperBAspectSuperBAspectProperties;
import java.util.Map;
import some.basepackage.root.subpackage.SuperB;

@SuppressWarnings("all")
public class SuperBAspectSuperBAspectContext {
  public final static SuperBAspectSuperBAspectContext INSTANCE = new SuperBAspectSuperBAspectContext();
  
  public static SuperBAspectSuperBAspectProperties getSelf(final SuperB _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.melange.test.renaming.aspects.SuperBAspectSuperBAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<SuperB, SuperBAspectSuperBAspectProperties> map = new java.util.WeakHashMap<some.basepackage.root.subpackage.SuperB, fr.inria.diverse.melange.test.renaming.aspects.SuperBAspectSuperBAspectProperties>();
  
  public Map<SuperB, SuperBAspectSuperBAspectProperties> getMap() {
    return map;
  }
}
