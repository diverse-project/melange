package fr.inria.diverse.melange.test.renaming.aspects;

import some.basepackage.root.ClassA;

@SuppressWarnings("all")
public class ClassBAspectClassBAspectProperties {
  public ClassA toA;
}
