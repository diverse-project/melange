package fr.inria.diverse.melange.test.renaming.aspects;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.melange.test.renaming.aspects.ClassBAspectClassBAspectProperties;
import fr.inria.diverse.melange.test.renaming.aspects.SuperBAspect;
import some.basepackage.root.ClassA;
import some.basepackage.root.subpackage.ClassB;

@Aspect(className = ClassB.class)
@SuppressWarnings("all")
public class ClassBAspect extends SuperBAspect {
  public static ClassA toA(final ClassB _self) {
    fr.inria.diverse.melange.test.renaming.aspects.ClassBAspectClassBAspectProperties _self_ = fr.inria.diverse.melange.test.renaming.aspects.ClassBAspectClassBAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_toA(_self_, _self);
    return (some.basepackage.root.ClassA)result;
  }
  
  public static void toA(final ClassB _self, final ClassA toA) {
    fr.inria.diverse.melange.test.renaming.aspects.ClassBAspectClassBAspectProperties _self_ = fr.inria.diverse.melange.test.renaming.aspects.ClassBAspectClassBAspectContext.getSelf(_self);
    _privk3_toA(_self_, _self,toA);
  }
  
  protected static ClassA _privk3_toA(final ClassBAspectClassBAspectProperties _self_, final ClassB _self) {
     return _self_.toA; 
  }
  
  protected static void _privk3_toA(final ClassBAspectClassBAspectProperties _self_, final ClassB _self, final ClassA toA) {
    _self_.toA = toA; try {
    
    			for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    				if (m.getName().equals("set" + "ToA")
    						&& m.getParameterTypes().length == 1) {
    					m.invoke(_self, toA);
    
    				}
    			}
    		} catch (Exception e) {
    			// Chut !
    		} 
  }
}
