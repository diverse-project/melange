package finitestatemachines;

import finitestatemachines.FiniteStateMachineRTCMT;
import finitestatemachines.FiniteStateMachineSimultaneousMT;
import finitestatemachines.FiniteStateMachineTimedCompositeMT;
import finitestatemachines.FiniteStateMachineTimedCompositeSimultaneousMT;
import finitestatemachines.FiniteStateMachineTimedMT;
import finitestatemachines.FiniteStateMachineTimedSimultaneousMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FiniteStateMachineTimedCompositeSimultaneous implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static FiniteStateMachineTimedCompositeSimultaneous load(final String uri) {
    org.eclipse.emf.ecore.resource.ResourceSet rs = new org.eclipse.emf.ecore.resource.impl.ResourceSetImpl() ;
    Resource res = rs.getResource(org.eclipse.emf.common.util.URI.createURI(uri), true) ;
    FiniteStateMachineTimedCompositeSimultaneous mm = new FiniteStateMachineTimedCompositeSimultaneous() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FiniteStateMachineRTCMT toFiniteStateMachineRTCMT() {
    finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineTimedCompositeSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineTimedCompositeSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineSimultaneousMT toFiniteStateMachineSimultaneousMT() {
    finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineTimedCompositeSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineTimedCompositeSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineTimedMT toFiniteStateMachineTimedMT() {
    finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedCompositeSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedCompositeSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineTimedCompositeMT toFiniteStateMachineTimedCompositeMT() {
    finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedcompositemt.FiniteStateMachineTimedCompositeSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedcompositemt.FiniteStateMachineTimedCompositeSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineTimedSimultaneousMT toFiniteStateMachineTimedSimultaneousMT() {
    finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedsimultaneousmt.FiniteStateMachineTimedCompositeSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedsimultaneousmt.FiniteStateMachineTimedCompositeSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineTimedCompositeSimultaneousMT toFiniteStateMachineTimedCompositeSimultaneousMT() {
    finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedcompositesimultaneousmt.FiniteStateMachineTimedCompositeSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedcompositesimultaneousmt.FiniteStateMachineTimedCompositeSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
