package finitestatemachines;

import finitestatemachines.FiniteStateMachineCompositeMT;
import finitestatemachines.FiniteStateMachineRTCMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FiniteStateMachineComposite implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static FiniteStateMachineComposite load(final String uri) {
    org.eclipse.emf.ecore.resource.ResourceSet rs = new org.eclipse.emf.ecore.resource.impl.ResourceSetImpl() ;
    Resource res = rs.getResource(org.eclipse.emf.common.util.URI.createURI(uri), true) ;
    FiniteStateMachineComposite mm = new FiniteStateMachineComposite() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FiniteStateMachineRTCMT toFiniteStateMachineRTCMT() {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineCompositeAdapter adaptee = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineCompositeAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineCompositeMT toFiniteStateMachineCompositeMT() {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeAdapter adaptee = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
