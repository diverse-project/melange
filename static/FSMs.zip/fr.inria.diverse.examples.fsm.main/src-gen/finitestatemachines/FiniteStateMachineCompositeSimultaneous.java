package finitestatemachines;

import finitestatemachines.FiniteStateMachineCompositeMT;
import finitestatemachines.FiniteStateMachineCompositeSimultaneousMT;
import finitestatemachines.FiniteStateMachineRTCMT;
import finitestatemachines.FiniteStateMachineSimultaneousMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FiniteStateMachineCompositeSimultaneous implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static FiniteStateMachineCompositeSimultaneous load(final String uri) {
    org.eclipse.emf.ecore.resource.ResourceSet rs = new org.eclipse.emf.ecore.resource.impl.ResourceSetImpl() ;
    Resource res = rs.getResource(org.eclipse.emf.common.util.URI.createURI(uri), true) ;
    FiniteStateMachineCompositeSimultaneous mm = new FiniteStateMachineCompositeSimultaneous() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FiniteStateMachineRTCMT toFiniteStateMachineRTCMT() {
    finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineCompositeSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineCompositeSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineSimultaneousMT toFiniteStateMachineSimultaneousMT() {
    finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineCompositeSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineCompositeSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineCompositeMT toFiniteStateMachineCompositeMT() {
    finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineCompositeSimultaneousMT toFiniteStateMachineCompositeSimultaneousMT() {
    finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositesimultaneousmt.FiniteStateMachineCompositeSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositesimultaneousmt.FiniteStateMachineCompositeSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
