package finitestatemachines.finitestatemachinecompositemt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachinecompositemt.NamedElement;
import finitestatemachines.finitestatemachinecompositemt.State;
import finitestatemachines.finitestatemachinecompositemt.Transition;
import finitestatemachines.finitestatemachinecompositemt.Variable;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface StateMachine extends EObject, NamedElement {
  public EList<State> getStates();
  
  public EList<Transition> getTransitions();
  
  public EList<Variable> getVariables();
  
  public void eval(final Context context, final String filePath);
}
