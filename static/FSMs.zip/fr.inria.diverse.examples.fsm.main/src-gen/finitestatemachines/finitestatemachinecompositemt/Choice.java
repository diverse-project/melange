package finitestatemachines.finitestatemachinecompositemt;

import finitestatemachines.finitestatemachinecompositemt.Pseudostate;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface Choice extends EObject, Pseudostate {
}
