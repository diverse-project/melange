package finitestatemachines.finitestatemachinecompositemt;

import fr.inria.diverse.melange.lib.IFactory;

@SuppressWarnings("all")
public interface FiniteStateMachineCompositeMTFactory extends IFactory {
  public abstract finitestatemachines.finitestatemachinecompositemt.NamedElement createNamedElement();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.StateMachine createStateMachine();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.State createState();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.FinalState createFinalState();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.InitialState createInitialState();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.Transition createTransition();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.TimedTransition createTimedTransition();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.Trigger createTrigger();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.Pseudostate createPseudostate();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.Fork createFork();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.Join createJoin();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.CompositeState createCompositeState();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.Region createRegion();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.Action createAction();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.Variable createVariable();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.Choice createChoice();
  
  public abstract finitestatemachines.finitestatemachinecompositemt.Guard createGuard();
}
