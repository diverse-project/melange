package finitestatemachines.finitestatemachinecompositemt;

import finitestatemachines.finitestatemachinecompositemt.Region;
import finitestatemachines.finitestatemachinecompositemt.State;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface CompositeState extends EObject, State {
  public EList<Region> getRegions();
  
  public EList<State> getAllStates();
}
