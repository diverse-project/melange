package finitestatemachines.finitestatemachinecompositemt;

import finitestatemachines.finitestatemachinecompositemt.State;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface FinalState extends EObject, State {
}
