package finitestatemachines;

@SuppressWarnings("all")
public class StandaloneSetup {
  public static void doSetup() {
    StandaloneSetup setup = new StandaloneSetup() ;
    setup.doEMFRegistration() ;
    setup.doAdaptersRegistration() ;
  }
  
  public void doEMFRegistration() {
    org.eclipse.emf.ecore.EPackage.Registry.INSTANCE.put(
    	finitestatemachines.FinitestatemachinesPackage.eNS_URI,
    	finitestatemachines.FinitestatemachinesPackage.eINSTANCE
    ) ;
    org.eclipse.emf.ecore.EPackage.Registry.INSTANCE.put(
    	finitestatemachines.FinitestatemachinesPackage.eNS_URI,
    	finitestatemachines.FinitestatemachinesPackage.eINSTANCE
    ) ;
    org.eclipse.emf.ecore.EPackage.Registry.INSTANCE.put(
    	finitestatemachinestimed.FinitestatemachinestimedPackage.eNS_URI,
    	finitestatemachinestimed.FinitestatemachinestimedPackage.eINSTANCE
    ) ;
    org.eclipse.emf.ecore.EPackage.Registry.INSTANCE.put(
    	finitestatemachinescomposite.FinitestatemachinescompositePackage.eNS_URI,
    	finitestatemachinescomposite.FinitestatemachinescompositePackage.eINSTANCE
    ) ;
    org.eclipse.emf.ecore.EPackage.Registry.INSTANCE.put(
    	finitestatemachinestimedcomposite.FinitestatemachinestimedcompositePackage.eNS_URI,
    	finitestatemachinestimedcomposite.FinitestatemachinestimedcompositePackage.eINSTANCE
    ) ;
    org.eclipse.emf.ecore.EPackage.Registry.INSTANCE.put(
    	finitestatemachinestimed.FinitestatemachinestimedPackage.eNS_URI,
    	finitestatemachinestimed.FinitestatemachinestimedPackage.eINSTANCE
    ) ;
    org.eclipse.emf.ecore.EPackage.Registry.INSTANCE.put(
    	finitestatemachinescomposite.FinitestatemachinescompositePackage.eNS_URI,
    	finitestatemachinescomposite.FinitestatemachinescompositePackage.eINSTANCE
    ) ;
    org.eclipse.emf.ecore.EPackage.Registry.INSTANCE.put(
    	finitestatemachinestimedcomposite.FinitestatemachinestimedcompositePackage.eNS_URI,
    	finitestatemachinestimedcomposite.FinitestatemachinestimedcompositePackage.eINSTANCE
    ) ;
    
    org.eclipse.emf.ecore.resource.Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put(
    	"*",
    	new org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl()
    ) ;
  }
  
  public void doAdaptersRegistration() {
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineRTC",
    	"finitestatemachines.FiniteStateMachineRTCMT",
    	finitestatemachines.finitestatemachinertc.adapters.finitestatemachinertcmt.FiniteStateMachineRTCAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm",
    	  "FiniteStateMachineRTCMT",
    	  finitestatemachines.finitestatemachinertc.adapters.finitestatemachinertcmt.FiniteStateMachineRTCAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineSimultaneous",
    	"finitestatemachines.FiniteStateMachineRTCMT",
    	finitestatemachines.finitestatemachinesimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm",
    	  "FiniteStateMachineRTCMT",
    	  finitestatemachines.finitestatemachinesimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineSimultaneous",
    	"finitestatemachines.FiniteStateMachineSimultaneousMT",
    	finitestatemachines.finitestatemachinesimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm",
    	  "FiniteStateMachineSimultaneousMT",
    	  finitestatemachines.finitestatemachinesimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimed",
    	"finitestatemachines.FiniteStateMachineRTCMT",
    	finitestatemachines.finitestatemachinetimed.adapters.finitestatemachinertcmt.FiniteStateMachineTimedAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timed",
    	  "FiniteStateMachineRTCMT",
    	  finitestatemachines.finitestatemachinetimed.adapters.finitestatemachinertcmt.FiniteStateMachineTimedAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimed",
    	"finitestatemachines.FiniteStateMachineTimedMT",
    	finitestatemachines.finitestatemachinetimed.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timed",
    	  "FiniteStateMachineTimedMT",
    	  finitestatemachines.finitestatemachinetimed.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineComposite",
    	"finitestatemachines.FiniteStateMachineRTCMT",
    	finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineCompositeAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineRTCMT",
    	  finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineCompositeAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineComposite",
    	"finitestatemachines.FiniteStateMachineCompositeMT",
    	finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineCompositeMT",
    	  finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedComposite",
    	"finitestatemachines.FiniteStateMachineRTCMT",
    	finitestatemachines.finitestatemachinetimedcomposite.adapters.finitestatemachinertcmt.FiniteStateMachineTimedCompositeAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timedcomposite",
    	  "FiniteStateMachineRTCMT",
    	  finitestatemachines.finitestatemachinetimedcomposite.adapters.finitestatemachinertcmt.FiniteStateMachineTimedCompositeAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedComposite",
    	"finitestatemachines.FiniteStateMachineTimedMT",
    	finitestatemachines.finitestatemachinetimedcomposite.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedCompositeAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timedcomposite",
    	  "FiniteStateMachineTimedMT",
    	  finitestatemachines.finitestatemachinetimedcomposite.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedCompositeAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedComposite",
    	"finitestatemachines.FiniteStateMachineTimedCompositeMT",
    	finitestatemachines.finitestatemachinetimedcomposite.adapters.finitestatemachinetimedcompositemt.FiniteStateMachineTimedCompositeAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timedcomposite",
    	  "FiniteStateMachineTimedCompositeMT",
    	  finitestatemachines.finitestatemachinetimedcomposite.adapters.finitestatemachinetimedcompositemt.FiniteStateMachineTimedCompositeAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedSimultaneous",
    	"finitestatemachines.FiniteStateMachineRTCMT",
    	finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineTimedSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timed",
    	  "FiniteStateMachineRTCMT",
    	  finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineTimedSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedSimultaneous",
    	"finitestatemachines.FiniteStateMachineSimultaneousMT",
    	finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineTimedSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timed",
    	  "FiniteStateMachineSimultaneousMT",
    	  finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineTimedSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedSimultaneous",
    	"finitestatemachines.FiniteStateMachineTimedMT",
    	finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timed",
    	  "FiniteStateMachineTimedMT",
    	  finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedSimultaneous",
    	"finitestatemachines.FiniteStateMachineTimedSimultaneousMT",
    	finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinetimedsimultaneousmt.FiniteStateMachineTimedSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timed",
    	  "FiniteStateMachineTimedSimultaneousMT",
    	  finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinetimedsimultaneousmt.FiniteStateMachineTimedSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineCompositeSimultaneous",
    	"finitestatemachines.FiniteStateMachineRTCMT",
    	finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineRTCMT",
    	  finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineCompositeSimultaneous",
    	"finitestatemachines.FiniteStateMachineSimultaneousMT",
    	finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineSimultaneousMT",
    	  finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineCompositeSimultaneous",
    	"finitestatemachines.FiniteStateMachineCompositeMT",
    	finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineCompositeMT",
    	  finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineCompositeSimultaneous",
    	"finitestatemachines.FiniteStateMachineCompositeSimultaneousMT",
    	finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositesimultaneousmt.FiniteStateMachineCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineCompositeSimultaneousMT",
    	  finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositesimultaneousmt.FiniteStateMachineCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedCompositeSimultaneous",
    	"finitestatemachines.FiniteStateMachineRTCMT",
    	finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineTimedCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timedcomposite",
    	  "FiniteStateMachineRTCMT",
    	  finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineTimedCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedCompositeSimultaneous",
    	"finitestatemachines.FiniteStateMachineSimultaneousMT",
    	finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineTimedCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timedcomposite",
    	  "FiniteStateMachineSimultaneousMT",
    	  finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineTimedCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedCompositeSimultaneous",
    	"finitestatemachines.FiniteStateMachineTimedMT",
    	finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timedcomposite",
    	  "FiniteStateMachineTimedMT",
    	  finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedCompositeSimultaneous",
    	"finitestatemachines.FiniteStateMachineTimedCompositeMT",
    	finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedcompositemt.FiniteStateMachineTimedCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timedcomposite",
    	  "FiniteStateMachineTimedCompositeMT",
    	  finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedcompositemt.FiniteStateMachineTimedCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedCompositeSimultaneous",
    	"finitestatemachines.FiniteStateMachineTimedSimultaneousMT",
    	finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedsimultaneousmt.FiniteStateMachineTimedCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timedcomposite",
    	  "FiniteStateMachineTimedSimultaneousMT",
    	  finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedsimultaneousmt.FiniteStateMachineTimedCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineTimedCompositeSimultaneous",
    	"finitestatemachines.FiniteStateMachineTimedCompositeSimultaneousMT",
    	finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedcompositesimultaneousmt.FiniteStateMachineTimedCompositeSimultaneousAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.timedcomposite",
    	  "FiniteStateMachineTimedCompositeSimultaneousMT",
    	  finitestatemachines.finitestatemachinetimedcompositesimultaneous.adapters.finitestatemachinetimedcompositesimultaneousmt.FiniteStateMachineTimedCompositeSimultaneousAdapter.class
    ) ;
  }
}
