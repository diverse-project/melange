package finitestatemachines;

import finitestatemachines.FiniteStateMachineRTCMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FiniteStateMachineRTC implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static FiniteStateMachineRTC load(final String uri) {
    org.eclipse.emf.ecore.resource.ResourceSet rs = new org.eclipse.emf.ecore.resource.impl.ResourceSetImpl() ;
    Resource res = rs.getResource(org.eclipse.emf.common.util.URI.createURI(uri), true) ;
    FiniteStateMachineRTC mm = new FiniteStateMachineRTC() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FiniteStateMachineRTCMT toFiniteStateMachineRTCMT() {
    finitestatemachines.finitestatemachinertc.adapters.finitestatemachinertcmt.FiniteStateMachineRTCAdapter adaptee = new finitestatemachines.finitestatemachinertc.adapters.finitestatemachinertcmt.FiniteStateMachineRTCAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
