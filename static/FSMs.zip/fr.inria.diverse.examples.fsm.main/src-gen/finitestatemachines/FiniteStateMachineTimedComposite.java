package finitestatemachines;

import finitestatemachines.FiniteStateMachineRTCMT;
import finitestatemachines.FiniteStateMachineTimedCompositeMT;
import finitestatemachines.FiniteStateMachineTimedMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FiniteStateMachineTimedComposite implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static FiniteStateMachineTimedComposite load(final String uri) {
    org.eclipse.emf.ecore.resource.ResourceSet rs = new org.eclipse.emf.ecore.resource.impl.ResourceSetImpl() ;
    Resource res = rs.getResource(org.eclipse.emf.common.util.URI.createURI(uri), true) ;
    FiniteStateMachineTimedComposite mm = new FiniteStateMachineTimedComposite() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FiniteStateMachineRTCMT toFiniteStateMachineRTCMT() {
    finitestatemachines.finitestatemachinetimedcomposite.adapters.finitestatemachinertcmt.FiniteStateMachineTimedCompositeAdapter adaptee = new finitestatemachines.finitestatemachinetimedcomposite.adapters.finitestatemachinertcmt.FiniteStateMachineTimedCompositeAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineTimedMT toFiniteStateMachineTimedMT() {
    finitestatemachines.finitestatemachinetimedcomposite.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedCompositeAdapter adaptee = new finitestatemachines.finitestatemachinetimedcomposite.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedCompositeAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineTimedCompositeMT toFiniteStateMachineTimedCompositeMT() {
    finitestatemachines.finitestatemachinetimedcomposite.adapters.finitestatemachinetimedcompositemt.FiniteStateMachineTimedCompositeAdapter adaptee = new finitestatemachines.finitestatemachinetimedcomposite.adapters.finitestatemachinetimedcompositemt.FiniteStateMachineTimedCompositeAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
