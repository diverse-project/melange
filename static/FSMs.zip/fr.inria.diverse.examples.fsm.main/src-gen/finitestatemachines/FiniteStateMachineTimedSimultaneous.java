package finitestatemachines;

import finitestatemachines.FiniteStateMachineRTCMT;
import finitestatemachines.FiniteStateMachineSimultaneousMT;
import finitestatemachines.FiniteStateMachineTimedMT;
import finitestatemachines.FiniteStateMachineTimedSimultaneousMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FiniteStateMachineTimedSimultaneous implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static FiniteStateMachineTimedSimultaneous load(final String uri) {
    org.eclipse.emf.ecore.resource.ResourceSet rs = new org.eclipse.emf.ecore.resource.impl.ResourceSetImpl() ;
    Resource res = rs.getResource(org.eclipse.emf.common.util.URI.createURI(uri), true) ;
    FiniteStateMachineTimedSimultaneous mm = new FiniteStateMachineTimedSimultaneous() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FiniteStateMachineRTCMT toFiniteStateMachineRTCMT() {
    finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineTimedSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinertcmt.FiniteStateMachineTimedSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineSimultaneousMT toFiniteStateMachineSimultaneousMT() {
    finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineTimedSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinesimultaneousmt.FiniteStateMachineTimedSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineTimedMT toFiniteStateMachineTimedMT() {
    finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineTimedSimultaneousMT toFiniteStateMachineTimedSimultaneousMT() {
    finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinetimedsimultaneousmt.FiniteStateMachineTimedSimultaneousAdapter adaptee = new finitestatemachines.finitestatemachinetimedsimultaneous.adapters.finitestatemachinetimedsimultaneousmt.FiniteStateMachineTimedSimultaneousAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
