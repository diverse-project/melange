package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt;

import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTAdaptersFactory;
import finitestatemachines.finitestatemachinertcmt.StateMachine;
import finitestatemachines.finitestatemachinertcmt.Transition;
import finitestatemachinescomposite.FinalState;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class FinalStateAdapter extends EObjectAdapter<FinalState> implements finitestatemachines.finitestatemachinertcmt.FinalState {
  private FiniteStateMachineRTCMTAdaptersFactory adaptersFactory;
  
  public FinalStateAdapter() {
    super(finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public EList<Transition> getOutgoing() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getOutgoing(), finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<Transition> getIncoming() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getIncoming(), finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.TransitionAdapter.class) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return adaptersFactory.createStateMachineAdapter(adaptee.getStateMachine()) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    adaptee.setStateMachine(((finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.StateMachineAdapter) o).getAdaptee()) ;
  }
}
