package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt;

import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTAdaptersFactory;
import finitestatemachinescomposite.NamedElement;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class NamedElementAdapter extends EObjectAdapter<NamedElement> implements finitestatemachines.finitestatemachinertcmt.NamedElement {
  private FiniteStateMachineRTCMTAdaptersFactory adaptersFactory;
  
  public NamedElementAdapter() {
    super(finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
}
