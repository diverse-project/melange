package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt;

import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FinalStateAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.ForkAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.InitialStateAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.JoinAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.NamedElementAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.PseudostateAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.StateAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.StateMachineAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.TimedTransitionAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.TransitionAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.TriggerAdapter;
import finitestatemachinescomposite.FinalState;
import finitestatemachinescomposite.Fork;
import finitestatemachinescomposite.InitialState;
import finitestatemachinescomposite.Join;
import finitestatemachinescomposite.NamedElement;
import finitestatemachinescomposite.Pseudostate;
import finitestatemachinescomposite.State;
import finitestatemachinescomposite.StateMachine;
import finitestatemachinescomposite.TimedTransition;
import finitestatemachinescomposite.Transition;
import finitestatemachinescomposite.Trigger;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public class FiniteStateMachineRTCMTAdaptersFactory implements AdaptersFactory {
  private static FiniteStateMachineRTCMTAdaptersFactory instance;
  
  public static FiniteStateMachineRTCMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o) {
    if (o instanceof finitestatemachinescomposite.StateMachine)
    	return createStateMachineAdapter((finitestatemachinescomposite.StateMachine) o) ;
    if (o instanceof finitestatemachinescomposite.FinalState)
    	return createFinalStateAdapter((finitestatemachinescomposite.FinalState) o) ;
    if (o instanceof finitestatemachinescomposite.InitialState)
    	return createInitialStateAdapter((finitestatemachinescomposite.InitialState) o) ;
    if (o instanceof finitestatemachinescomposite.State)
    	return createStateAdapter((finitestatemachinescomposite.State) o) ;
    if (o instanceof finitestatemachinescomposite.TimedTransition)
    	return createTimedTransitionAdapter((finitestatemachinescomposite.TimedTransition) o) ;
    if (o instanceof finitestatemachinescomposite.Transition)
    	return createTransitionAdapter((finitestatemachinescomposite.Transition) o) ;
    if (o instanceof finitestatemachinescomposite.Fork)
    	return createForkAdapter((finitestatemachinescomposite.Fork) o) ;
    if (o instanceof finitestatemachinescomposite.Join)
    	return createJoinAdapter((finitestatemachinescomposite.Join) o) ;
    if (o instanceof finitestatemachinescomposite.Pseudostate)
    	return createPseudostateAdapter((finitestatemachinescomposite.Pseudostate) o) ;
    if (o instanceof finitestatemachinescomposite.NamedElement)
    	return createNamedElementAdapter((finitestatemachinescomposite.NamedElement) o) ;
    if (o instanceof finitestatemachinescomposite.Trigger)
    	return createTriggerAdapter((finitestatemachinescomposite.Trigger) o) ;
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.NamedElementAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.NamedElementAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.StateMachineAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.StateMachineAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public StateAdapter createStateAdapter(final State adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.StateAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.StateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FinalStateAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FinalStateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.InitialStateAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.InitialStateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.TransitionAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.TransitionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.TimedTransitionAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.TimedTransitionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.TriggerAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.TriggerAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.PseudostateAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.PseudostateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.ForkAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.ForkAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.JoinAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.JoinAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
}
