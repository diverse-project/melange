package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt;

import finitestatemachines.FiniteStateMachineRTCMT;
import finitestatemachines.finitestatemachinertcmt.FiniteStateMachineRTCMTFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;

@SuppressWarnings("all")
public class FiniteStateMachineCompositeAdapter extends ResourceAdapter implements FiniteStateMachineRTCMT {
  public FiniteStateMachineCompositeAdapter() {
    super(finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FiniteStateMachineRTCMTFactory getFactory() {
    return new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(org.eclipse.emf.common.util.URI.createURI(uri));
    this.adaptee.save(null);
  }
}
