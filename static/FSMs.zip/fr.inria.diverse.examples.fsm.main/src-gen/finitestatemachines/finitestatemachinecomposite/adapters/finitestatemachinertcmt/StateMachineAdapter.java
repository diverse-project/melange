package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTAdaptersFactory;
import finitestatemachines.finitestatemachinertcmt.State;
import finitestatemachines.finitestatemachinertcmt.Transition;
import finitestatemachinescomposite.StateMachine;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class StateMachineAdapter extends EObjectAdapter<StateMachine> implements finitestatemachines.finitestatemachinertcmt.StateMachine {
  private FiniteStateMachineRTCMTAdaptersFactory adaptersFactory;
  
  public StateMachineAdapter() {
    super(finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public EList<State> getStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.StateAdapter.class) ;
  }
  
  @Override
  public EList<Transition> getTransitions() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getTransitions(), finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.TransitionAdapter.class) ;
  }
  
  @Override
  public void eval(final Context context, final String filePath) {
    finitestatemachines.composite.StateMachineAspect.eval(adaptee, context
    , filePath
    ) ;
  }
}
