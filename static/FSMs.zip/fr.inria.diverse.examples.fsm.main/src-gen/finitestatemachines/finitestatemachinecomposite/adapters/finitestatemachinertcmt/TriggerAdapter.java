package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt;

import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTAdaptersFactory;
import finitestatemachinescomposite.Trigger;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class TriggerAdapter extends EObjectAdapter<Trigger> implements finitestatemachines.finitestatemachinertcmt.Trigger {
  private FiniteStateMachineRTCMTAdaptersFactory adaptersFactory;
  
  public TriggerAdapter() {
    super(finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
}
