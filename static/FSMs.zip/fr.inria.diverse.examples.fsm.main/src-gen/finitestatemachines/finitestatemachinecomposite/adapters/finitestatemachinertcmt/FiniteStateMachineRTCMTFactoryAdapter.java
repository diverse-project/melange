package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt;

import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTAdaptersFactory;
import finitestatemachines.finitestatemachinertcmt.FinalState;
import finitestatemachines.finitestatemachinertcmt.FiniteStateMachineRTCMTFactory;
import finitestatemachines.finitestatemachinertcmt.Fork;
import finitestatemachines.finitestatemachinertcmt.InitialState;
import finitestatemachines.finitestatemachinertcmt.Join;
import finitestatemachines.finitestatemachinertcmt.NamedElement;
import finitestatemachines.finitestatemachinertcmt.Pseudostate;
import finitestatemachines.finitestatemachinertcmt.State;
import finitestatemachines.finitestatemachinertcmt.StateMachine;
import finitestatemachines.finitestatemachinertcmt.TimedTransition;
import finitestatemachines.finitestatemachinertcmt.Transition;
import finitestatemachines.finitestatemachinertcmt.Trigger;
import finitestatemachinescomposite.FinitestatemachinescompositeFactory;

@SuppressWarnings("all")
public class FiniteStateMachineRTCMTFactoryAdapter implements FiniteStateMachineRTCMTFactory {
  private FiniteStateMachineRTCMTAdaptersFactory adaptersFactory = finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinertcmt.FiniteStateMachineRTCMTAdaptersFactory.getInstance();
  
  private FinitestatemachinescompositeFactory finitestatemachinescompositeAdaptee = finitestatemachinescomposite.FinitestatemachinescompositeFactory.eINSTANCE;
  
  @Override
  public NamedElement createNamedElement() {
    return adaptersFactory.createNamedElementAdapter(finitestatemachinescompositeAdaptee.createNamedElement()) ;
  }
  
  @Override
  public StateMachine createStateMachine() {
    return adaptersFactory.createStateMachineAdapter(finitestatemachinescompositeAdaptee.createStateMachine()) ;
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(finitestatemachinescompositeAdaptee.createState()) ;
  }
  
  @Override
  public FinalState createFinalState() {
    return adaptersFactory.createFinalStateAdapter(finitestatemachinescompositeAdaptee.createFinalState()) ;
  }
  
  @Override
  public InitialState createInitialState() {
    return adaptersFactory.createInitialStateAdapter(finitestatemachinescompositeAdaptee.createInitialState()) ;
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(finitestatemachinescompositeAdaptee.createTransition()) ;
  }
  
  @Override
  public TimedTransition createTimedTransition() {
    return adaptersFactory.createTimedTransitionAdapter(finitestatemachinescompositeAdaptee.createTimedTransition()) ;
  }
  
  @Override
  public Trigger createTrigger() {
    return adaptersFactory.createTriggerAdapter(finitestatemachinescompositeAdaptee.createTrigger()) ;
  }
  
  @Override
  public Pseudostate createPseudostate() {
    return adaptersFactory.createPseudostateAdapter(finitestatemachinescompositeAdaptee.createPseudostate()) ;
  }
  
  @Override
  public Fork createFork() {
    return adaptersFactory.createForkAdapter(finitestatemachinescompositeAdaptee.createFork()) ;
  }
  
  @Override
  public Join createJoin() {
    return adaptersFactory.createJoinAdapter(finitestatemachinescompositeAdaptee.createJoin()) ;
  }
}
