package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt;

import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory;
import finitestatemachines.finitestatemachinecompositemt.CompositeState;
import finitestatemachines.finitestatemachinecompositemt.State;
import finitestatemachinescomposite.Region;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class RegionAdapter extends EObjectAdapter<Region> implements finitestatemachines.finitestatemachinecompositemt.Region {
  private FiniteStateMachineCompositeMTAdaptersFactory adaptersFactory;
  
  public RegionAdapter() {
    super(finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public EList<State> getStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.StateAdapter.class) ;
  }
  
  @Override
  public CompositeState getParent() {
    return adaptersFactory.createCompositeStateAdapter(adaptee.getParent()) ;
  }
  
  @Override
  public void setParent(final CompositeState o) {
    adaptee.setParent(((finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.CompositeStateAdapter) o).getAdaptee()) ;
  }
}
