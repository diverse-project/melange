package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory;
import finitestatemachines.finitestatemachinecompositemt.State;
import finitestatemachines.finitestatemachinecompositemt.Transition;
import finitestatemachines.finitestatemachinecompositemt.Variable;
import finitestatemachinescomposite.StateMachine;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class StateMachineAdapter extends EObjectAdapter<StateMachine> implements finitestatemachines.finitestatemachinecompositemt.StateMachine {
  private FiniteStateMachineCompositeMTAdaptersFactory adaptersFactory;
  
  public StateMachineAdapter() {
    super(finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public EList<State> getStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.StateAdapter.class) ;
  }
  
  @Override
  public EList<Transition> getTransitions() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getTransitions(), finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<Variable> getVariables() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getVariables(), finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.VariableAdapter.class) ;
  }
  
  @Override
  public void eval(final Context context, final String filePath) {
    finitestatemachines.composite.StateMachineAspect.eval(adaptee, context
    , filePath
    ) ;
  }
}
