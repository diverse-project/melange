package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt;

import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory;
import finitestatemachinescomposite.Guard;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class GuardAdapter extends EObjectAdapter<Guard> implements finitestatemachines.finitestatemachinecompositemt.Guard {
  private FiniteStateMachineCompositeMTAdaptersFactory adaptersFactory;
  
  public GuardAdapter() {
    super(finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
}
