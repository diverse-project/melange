package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt;

import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory;
import finitestatemachinescomposite.Trigger;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class TriggerAdapter extends EObjectAdapter<Trigger> implements finitestatemachines.finitestatemachinecompositemt.Trigger {
  private FiniteStateMachineCompositeMTAdaptersFactory adaptersFactory;
  
  public TriggerAdapter() {
    super(finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
}
