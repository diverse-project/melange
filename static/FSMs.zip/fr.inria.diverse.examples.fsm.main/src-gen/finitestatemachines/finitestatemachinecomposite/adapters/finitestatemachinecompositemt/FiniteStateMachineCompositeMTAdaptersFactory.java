package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt;

import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.ActionAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.ChoiceAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.CompositeStateAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FinalStateAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.ForkAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.GuardAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.InitialStateAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.JoinAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.NamedElementAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.PseudostateAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.RegionAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.StateAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.StateMachineAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.TimedTransitionAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.TransitionAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.TriggerAdapter;
import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.VariableAdapter;
import finitestatemachinescomposite.Action;
import finitestatemachinescomposite.Choice;
import finitestatemachinescomposite.CompositeState;
import finitestatemachinescomposite.FinalState;
import finitestatemachinescomposite.Fork;
import finitestatemachinescomposite.Guard;
import finitestatemachinescomposite.InitialState;
import finitestatemachinescomposite.Join;
import finitestatemachinescomposite.NamedElement;
import finitestatemachinescomposite.Pseudostate;
import finitestatemachinescomposite.Region;
import finitestatemachinescomposite.State;
import finitestatemachinescomposite.StateMachine;
import finitestatemachinescomposite.TimedTransition;
import finitestatemachinescomposite.Transition;
import finitestatemachinescomposite.Trigger;
import finitestatemachinescomposite.Variable;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public class FiniteStateMachineCompositeMTAdaptersFactory implements AdaptersFactory {
  private static FiniteStateMachineCompositeMTAdaptersFactory instance;
  
  public static FiniteStateMachineCompositeMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o) {
    if (o instanceof finitestatemachinescomposite.StateMachine)
    	return createStateMachineAdapter((finitestatemachinescomposite.StateMachine) o) ;
    if (o instanceof finitestatemachinescomposite.FinalState)
    	return createFinalStateAdapter((finitestatemachinescomposite.FinalState) o) ;
    if (o instanceof finitestatemachinescomposite.InitialState)
    	return createInitialStateAdapter((finitestatemachinescomposite.InitialState) o) ;
    if (o instanceof finitestatemachinescomposite.State)
    	return createStateAdapter((finitestatemachinescomposite.State) o) ;
    if (o instanceof finitestatemachinescomposite.TimedTransition)
    	return createTimedTransitionAdapter((finitestatemachinescomposite.TimedTransition) o) ;
    if (o instanceof finitestatemachinescomposite.Transition)
    	return createTransitionAdapter((finitestatemachinescomposite.Transition) o) ;
    if (o instanceof finitestatemachinescomposite.Fork)
    	return createForkAdapter((finitestatemachinescomposite.Fork) o) ;
    if (o instanceof finitestatemachinescomposite.Join)
    	return createJoinAdapter((finitestatemachinescomposite.Join) o) ;
    if (o instanceof finitestatemachinescomposite.Pseudostate)
    	return createPseudostateAdapter((finitestatemachinescomposite.Pseudostate) o) ;
    if (o instanceof finitestatemachinescomposite.NamedElement)
    	return createNamedElementAdapter((finitestatemachinescomposite.NamedElement) o) ;
    if (o instanceof finitestatemachinescomposite.Trigger)
    	return createTriggerAdapter((finitestatemachinescomposite.Trigger) o) ;
    if (o instanceof finitestatemachinescomposite.CompositeState)
    	return createCompositeStateAdapter((finitestatemachinescomposite.CompositeState) o) ;
    if (o instanceof finitestatemachinescomposite.Region)
    	return createRegionAdapter((finitestatemachinescomposite.Region) o) ;
    if (o instanceof finitestatemachinescomposite.Action)
    	return createActionAdapter((finitestatemachinescomposite.Action) o) ;
    if (o instanceof finitestatemachinescomposite.Variable)
    	return createVariableAdapter((finitestatemachinescomposite.Variable) o) ;
    if (o instanceof finitestatemachinescomposite.Choice)
    	return createChoiceAdapter((finitestatemachinescomposite.Choice) o) ;
    if (o instanceof finitestatemachinescomposite.Guard)
    	return createGuardAdapter((finitestatemachinescomposite.Guard) o) ;
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.NamedElementAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.NamedElementAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.StateMachineAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.StateMachineAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public StateAdapter createStateAdapter(final State adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.StateAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.StateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FinalStateAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FinalStateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.InitialStateAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.InitialStateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.TransitionAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.TransitionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.TimedTransitionAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.TimedTransitionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.TriggerAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.TriggerAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.PseudostateAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.PseudostateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.ForkAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.ForkAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.JoinAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.JoinAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public CompositeStateAdapter createCompositeStateAdapter(final CompositeState adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.CompositeStateAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.CompositeStateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public RegionAdapter createRegionAdapter(final Region adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.RegionAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.RegionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public ActionAdapter createActionAdapter(final Action adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.ActionAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.ActionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public VariableAdapter createVariableAdapter(final Variable adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.VariableAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.VariableAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public ChoiceAdapter createChoiceAdapter(final Choice adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.ChoiceAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.ChoiceAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public GuardAdapter createGuardAdapter(final Guard adaptee) {
    finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.GuardAdapter adap = new finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.GuardAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
}
