package finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt;

import finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory;
import finitestatemachines.finitestatemachinecompositemt.Action;
import finitestatemachines.finitestatemachinecompositemt.Guard;
import finitestatemachines.finitestatemachinecompositemt.State;
import finitestatemachines.finitestatemachinecompositemt.StateMachine;
import finitestatemachines.finitestatemachinecompositemt.Trigger;
import finitestatemachinescomposite.TimedTransition;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class TimedTransitionAdapter extends EObjectAdapter<TimedTransition> implements finitestatemachines.finitestatemachinecompositemt.TimedTransition {
  private FiniteStateMachineCompositeMTAdaptersFactory adaptersFactory;
  
  public TimedTransitionAdapter() {
    super(finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public int getDuration() {
    return adaptee.getDuration() ;
  }
  
  @Override
  public void setDuration(final int o) {
    adaptee.setDuration(o) ;
  }
  
  @Override
  public State getTarget() {
    return adaptersFactory.createStateAdapter(adaptee.getTarget()) ;
  }
  
  @Override
  public void setTarget(final State o) {
    adaptee.setTarget(((finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.StateAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public State getSource() {
    return adaptersFactory.createStateAdapter(adaptee.getSource()) ;
  }
  
  @Override
  public void setSource(final State o) {
    adaptee.setSource(((finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.StateAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public Trigger getTrigger() {
    return adaptersFactory.createTriggerAdapter(adaptee.getTrigger()) ;
  }
  
  @Override
  public void setTrigger(final Trigger o) {
    adaptee.setTrigger(((finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.TriggerAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return adaptersFactory.createStateMachineAdapter(adaptee.getStateMachine()) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    adaptee.setStateMachine(((finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.StateMachineAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public Guard getGuard() {
    return adaptersFactory.createGuardAdapter(adaptee.getGuard()) ;
  }
  
  @Override
  public void setGuard(final Guard o) {
    adaptee.setGuard(((finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.GuardAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public Action getAction() {
    return adaptersFactory.createActionAdapter(adaptee.getAction()) ;
  }
  
  @Override
  public void setAction(final Action o) {
    adaptee.setAction(((finitestatemachines.finitestatemachinecomposite.adapters.finitestatemachinecompositemt.ActionAdapter) o).getAdaptee()) ;
  }
}
