package finitestatemachines;

import finitestatemachines.FiniteStateMachineRTCMT;
import finitestatemachines.FiniteStateMachineTimedMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FiniteStateMachineTimed implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static FiniteStateMachineTimed load(final String uri) {
    org.eclipse.emf.ecore.resource.ResourceSet rs = new org.eclipse.emf.ecore.resource.impl.ResourceSetImpl() ;
    Resource res = rs.getResource(org.eclipse.emf.common.util.URI.createURI(uri), true) ;
    FiniteStateMachineTimed mm = new FiniteStateMachineTimed() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FiniteStateMachineRTCMT toFiniteStateMachineRTCMT() {
    finitestatemachines.finitestatemachinetimed.adapters.finitestatemachinertcmt.FiniteStateMachineTimedAdapter adaptee = new finitestatemachines.finitestatemachinetimed.adapters.finitestatemachinertcmt.FiniteStateMachineTimedAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineTimedMT toFiniteStateMachineTimedMT() {
    finitestatemachines.finitestatemachinetimed.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedAdapter adaptee = new finitestatemachines.finitestatemachinetimed.adapters.finitestatemachinetimedmt.FiniteStateMachineTimedAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
