package finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt;

import finitestatemachines.finitestatemachinecompositemt.CompositeState;
import finitestatemachines.finitestatemachinecompositemt.StateMachine;
import finitestatemachines.finitestatemachinecompositemt.Transition;
import finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory;
import finitestatemachinescomposite.Fork;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class ForkAdapter extends EObjectAdapter<Fork> implements finitestatemachines.finitestatemachinecompositemt.Fork {
  private FiniteStateMachineCompositeMTAdaptersFactory adaptersFactory;
  
  public ForkAdapter() {
    super(finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public EList<Transition> getOutgoing() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getOutgoing(), finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<Transition> getIncoming() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getIncoming(), finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.TransitionAdapter.class) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return adaptersFactory.createStateMachineAdapter(adaptee.getStateMachine()) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    adaptee.setStateMachine(((finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.StateMachineAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public CompositeState getParentState() {
    return adaptersFactory.createCompositeStateAdapter(adaptee.getParentState()) ;
  }
  
  @Override
  public void setParentState(final CompositeState o) {
    adaptee.setParentState(((finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.CompositeStateAdapter) o).getAdaptee()) ;
  }
}
