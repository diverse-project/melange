package finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt;

import finitestatemachines.FiniteStateMachineCompositeMT;
import finitestatemachines.finitestatemachinecompositemt.FiniteStateMachineCompositeMTFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;

@SuppressWarnings("all")
public class FiniteStateMachineCompositeSimultaneousAdapter extends ResourceAdapter implements FiniteStateMachineCompositeMT {
  public FiniteStateMachineCompositeSimultaneousAdapter() {
    super(finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FiniteStateMachineCompositeMTFactory getFactory() {
    return new finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(org.eclipse.emf.common.util.URI.createURI(uri));
    this.adaptee.save(null);
  }
}
