package finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt;

import finitestatemachines.finitestatemachinecompositemt.Action;
import finitestatemachines.finitestatemachinecompositemt.Choice;
import finitestatemachines.finitestatemachinecompositemt.CompositeState;
import finitestatemachines.finitestatemachinecompositemt.FinalState;
import finitestatemachines.finitestatemachinecompositemt.FiniteStateMachineCompositeMTFactory;
import finitestatemachines.finitestatemachinecompositemt.Fork;
import finitestatemachines.finitestatemachinecompositemt.Guard;
import finitestatemachines.finitestatemachinecompositemt.InitialState;
import finitestatemachines.finitestatemachinecompositemt.Join;
import finitestatemachines.finitestatemachinecompositemt.NamedElement;
import finitestatemachines.finitestatemachinecompositemt.Pseudostate;
import finitestatemachines.finitestatemachinecompositemt.Region;
import finitestatemachines.finitestatemachinecompositemt.State;
import finitestatemachines.finitestatemachinecompositemt.StateMachine;
import finitestatemachines.finitestatemachinecompositemt.TimedTransition;
import finitestatemachines.finitestatemachinecompositemt.Transition;
import finitestatemachines.finitestatemachinecompositemt.Trigger;
import finitestatemachines.finitestatemachinecompositemt.Variable;
import finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory;
import finitestatemachinescomposite.FinitestatemachinescompositeFactory;

@SuppressWarnings("all")
public class FiniteStateMachineCompositeMTFactoryAdapter implements FiniteStateMachineCompositeMTFactory {
  private FiniteStateMachineCompositeMTAdaptersFactory adaptersFactory = finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory.getInstance();
  
  private FinitestatemachinescompositeFactory finitestatemachinescompositeAdaptee = finitestatemachinescomposite.FinitestatemachinescompositeFactory.eINSTANCE;
  
  @Override
  public NamedElement createNamedElement() {
    return adaptersFactory.createNamedElementAdapter(finitestatemachinescompositeAdaptee.createNamedElement()) ;
  }
  
  @Override
  public StateMachine createStateMachine() {
    return adaptersFactory.createStateMachineAdapter(finitestatemachinescompositeAdaptee.createStateMachine()) ;
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(finitestatemachinescompositeAdaptee.createState()) ;
  }
  
  @Override
  public FinalState createFinalState() {
    return adaptersFactory.createFinalStateAdapter(finitestatemachinescompositeAdaptee.createFinalState()) ;
  }
  
  @Override
  public InitialState createInitialState() {
    return adaptersFactory.createInitialStateAdapter(finitestatemachinescompositeAdaptee.createInitialState()) ;
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(finitestatemachinescompositeAdaptee.createTransition()) ;
  }
  
  @Override
  public TimedTransition createTimedTransition() {
    return adaptersFactory.createTimedTransitionAdapter(finitestatemachinescompositeAdaptee.createTimedTransition()) ;
  }
  
  @Override
  public Trigger createTrigger() {
    return adaptersFactory.createTriggerAdapter(finitestatemachinescompositeAdaptee.createTrigger()) ;
  }
  
  @Override
  public Pseudostate createPseudostate() {
    return adaptersFactory.createPseudostateAdapter(finitestatemachinescompositeAdaptee.createPseudostate()) ;
  }
  
  @Override
  public Fork createFork() {
    return adaptersFactory.createForkAdapter(finitestatemachinescompositeAdaptee.createFork()) ;
  }
  
  @Override
  public Join createJoin() {
    return adaptersFactory.createJoinAdapter(finitestatemachinescompositeAdaptee.createJoin()) ;
  }
  
  @Override
  public CompositeState createCompositeState() {
    return adaptersFactory.createCompositeStateAdapter(finitestatemachinescompositeAdaptee.createCompositeState()) ;
  }
  
  @Override
  public Region createRegion() {
    return adaptersFactory.createRegionAdapter(finitestatemachinescompositeAdaptee.createRegion()) ;
  }
  
  @Override
  public Action createAction() {
    return adaptersFactory.createActionAdapter(finitestatemachinescompositeAdaptee.createAction()) ;
  }
  
  @Override
  public Variable createVariable() {
    return adaptersFactory.createVariableAdapter(finitestatemachinescompositeAdaptee.createVariable()) ;
  }
  
  @Override
  public Choice createChoice() {
    return adaptersFactory.createChoiceAdapter(finitestatemachinescompositeAdaptee.createChoice()) ;
  }
  
  @Override
  public Guard createGuard() {
    return adaptersFactory.createGuardAdapter(finitestatemachinescompositeAdaptee.createGuard()) ;
  }
}
