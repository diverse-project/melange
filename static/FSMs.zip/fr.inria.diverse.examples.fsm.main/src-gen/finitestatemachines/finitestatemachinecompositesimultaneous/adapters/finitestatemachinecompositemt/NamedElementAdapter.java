package finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt;

import finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory;
import finitestatemachinescomposite.NamedElement;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class NamedElementAdapter extends EObjectAdapter<NamedElement> implements finitestatemachines.finitestatemachinecompositemt.NamedElement {
  private FiniteStateMachineCompositeMTAdaptersFactory adaptersFactory;
  
  public NamedElementAdapter() {
    super(finitestatemachines.finitestatemachinecompositesimultaneous.adapters.finitestatemachinecompositemt.FiniteStateMachineCompositeMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
}
