package finitestatemachines.timedcomposite;

@SuppressWarnings("all")
public class StateAspectStateAspectProperties {
}
