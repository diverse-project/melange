package finitestatemachines.timedcomposite;

import FSM.interfaces.Context;
import finitestatemachines.timedcomposite.StateAspectStateAspectProperties;
import finitestatemachinestimedcomposite.State;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;

@Aspect(className = State.class)
@SuppressWarnings("all")
public class StateAspect {
  public static void eval(final State _self, final Context context) {
    finitestatemachines.timedcomposite.StateAspectStateAspectProperties _self_ = finitestatemachines.timedcomposite.StateAspectStateAspectContext.getSelf(_self);
     if (_self instanceof finitestatemachinestimedcomposite.CompositeState){
     finitestatemachines.timedcomposite.CompositeStateAspect.eval((finitestatemachinestimedcomposite.CompositeState)_self,context);
    } else  if (_self instanceof finitestatemachinestimedcomposite.State){
     finitestatemachines.timedcomposite.StateAspect._privk3_eval(_self_, (finitestatemachinestimedcomposite.State)_self,context);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_eval(final StateAspectStateAspectProperties _self_, final State _self, final Context context) {
    long _currentTimeMillis = System.currentTimeMillis();
    _self.setInitialTime(((int) _currentTimeMillis));
    Context.stateWorking(1000);
    long _currentTimeMillis_1 = System.currentTimeMillis();
    _self.setFinalTime(((int) _currentTimeMillis_1));
  }
}
