package finitestatemachines.simultaneous;

@SuppressWarnings("all")
public class StateAspectStateAspectProperties {
}
