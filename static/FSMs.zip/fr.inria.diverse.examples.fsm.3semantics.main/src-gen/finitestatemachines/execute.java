package finitestatemachines;

import FSM.interfaces.Context;
import finitestatemachines.FiniteStateMachineUMLMT;
import finitestatemachines.finitestatemachineumlmt.StateMachine;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class execute {
  public static void call(final FiniteStateMachineUMLMT stateMachine, final String input, final String outputFile) {
    EList<EObject> _contents = stateMachine.getContents();
    EObject _head = IterableExtensions.<EObject>head(_contents);
    final StateMachine root = ((StateMachine) _head);
    Context _context = new Context(input);
    root.eval(_context, outputFile);
  }
}
