package finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachineclassicmt.Action;
import finitestatemachines.finitestatemachineclassicmt.State;
import finitestatemachines.finitestatemachineclassicmt.Transition;
import finitestatemachines.finitestatemachineclassicmt.Variable;
import finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachinescomposite.StateMachine;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class StateMachineAdapter extends EObjectAdapter<StateMachine> implements finitestatemachines.finitestatemachineclassicmt.StateMachine {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory;
  
  public StateMachineAdapter() {
    super(finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public EList<State> getStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.StateAdapter.class) ;
  }
  
  @Override
  public EList<Transition> getTransitions() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getTransitions(), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<Variable> getVariables() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getVariables(), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.VariableAdapter.class) ;
  }
  
  @Override
  public void eval(final Context context, final String filePath) {
    finitestatemachines.composite.uml.StateMachineAspect.eval(adaptee, context
    , filePath
    ) ;
  }
  
  @Override
  public EList<State> getAllCurrentStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.uml.StateMachineAspect.getAllCurrentStates(adaptee), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.StateAdapter.class) ;
  }
  
  @Override
  public boolean isValid(final String expression) {
    return finitestatemachines.composite.uml.StateMachineAspect.isValid(adaptee, expression
    ) ;
  }
  
  @Override
  public void update(final Action action) {
    finitestatemachines.composite.uml.StateMachineAspect.update(adaptee, ((finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.ActionAdapter) action).getAdaptee()
    ) ;
  }
  
  @Override
  public void addCurrentState(final State s) {
    finitestatemachines.composite.uml.StateMachineAspect.addCurrentState(adaptee, ((finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.StateAdapter) s).getAdaptee()
    ) ;
  }
  
  @Override
  public void removeCurrentState(final State s) {
    finitestatemachines.composite.uml.StateMachineAspect.removeCurrentState(adaptee, ((finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.StateAdapter) s).getAdaptee()
    ) ;
  }
  
  @Override
  public boolean isCurrentState(final State s) {
    return finitestatemachines.composite.uml.StateMachineAspect.isCurrentState(adaptee, ((finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.StateAdapter) s).getAdaptee()
    ) ;
  }
}
