package finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachineclassicmt.CompositeState;
import finitestatemachines.finitestatemachineclassicmt.State;
import finitestatemachines.finitestatemachineclassicmt.StateMachine;
import finitestatemachines.finitestatemachineclassicmt.Transition;
import finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachinescomposite.Join;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class JoinAdapter extends EObjectAdapter<Join> implements finitestatemachines.finitestatemachineclassicmt.Join {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory;
  
  public JoinAdapter() {
    super(finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public EList<Transition> getOutgoing() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getOutgoing(), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<Transition> getIncoming() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getIncoming(), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.TransitionAdapter.class) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return adaptersFactory.createStateMachineAdapter(adaptee.getStateMachine()) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    adaptee.setStateMachine(((finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.StateMachineAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public CompositeState getParentState() {
    return adaptersFactory.createCompositeStateAdapter(adaptee.getParentState()) ;
  }
  
  @Override
  public void setParentState(final CompositeState o) {
    adaptee.setParentState(((finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.CompositeStateAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public void run(final Context context) {
    finitestatemachines.composite.uml.StateAspect.run(adaptee, context
    ) ;
  }
  
  @Override
  public EList<Transition> getActiveTransitions(final String event) {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.uml.StateAspect.getActiveTransitions(adaptee, event
    ), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<State> getAllParents() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.uml.StateAspect.getAllParents(adaptee), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.StateAdapter.class) ;
  }
  
  @Override
  public EList<State> getAllChildren() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.uml.StateAspect.getAllChildren(adaptee), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.StateAdapter.class) ;
  }
}
