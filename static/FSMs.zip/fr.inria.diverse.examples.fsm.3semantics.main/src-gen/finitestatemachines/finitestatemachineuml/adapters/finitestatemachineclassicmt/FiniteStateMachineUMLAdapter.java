package finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt;

import finitestatemachines.FiniteStateMachineClassicMT;
import finitestatemachines.finitestatemachineclassicmt.FiniteStateMachineClassicMTFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;

@SuppressWarnings("all")
public class FiniteStateMachineUMLAdapter extends ResourceAdapter implements FiniteStateMachineClassicMT {
  public FiniteStateMachineUMLAdapter() {
    super(finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FiniteStateMachineClassicMTFactory getFactory() {
    return new finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(org.eclipse.emf.common.util.URI.createURI(uri));
    this.adaptee.save(null);
  }
}
