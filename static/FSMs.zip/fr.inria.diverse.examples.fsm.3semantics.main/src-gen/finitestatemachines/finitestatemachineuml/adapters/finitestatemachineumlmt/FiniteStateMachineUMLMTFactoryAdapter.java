package finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt;

import finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory;
import finitestatemachines.finitestatemachineumlmt.Action;
import finitestatemachines.finitestatemachineumlmt.Choice;
import finitestatemachines.finitestatemachineumlmt.CompositeState;
import finitestatemachines.finitestatemachineumlmt.FinalState;
import finitestatemachines.finitestatemachineumlmt.FiniteStateMachineUMLMTFactory;
import finitestatemachines.finitestatemachineumlmt.Fork;
import finitestatemachines.finitestatemachineumlmt.Guard;
import finitestatemachines.finitestatemachineumlmt.InitialState;
import finitestatemachines.finitestatemachineumlmt.Join;
import finitestatemachines.finitestatemachineumlmt.NamedElement;
import finitestatemachines.finitestatemachineumlmt.Pseudostate;
import finitestatemachines.finitestatemachineumlmt.Region;
import finitestatemachines.finitestatemachineumlmt.State;
import finitestatemachines.finitestatemachineumlmt.StateMachine;
import finitestatemachines.finitestatemachineumlmt.TimedTransition;
import finitestatemachines.finitestatemachineumlmt.Transition;
import finitestatemachines.finitestatemachineumlmt.Trigger;
import finitestatemachines.finitestatemachineumlmt.Variable;
import finitestatemachinescomposite.FinitestatemachinescompositeFactory;

@SuppressWarnings("all")
public class FiniteStateMachineUMLMTFactoryAdapter implements FiniteStateMachineUMLMTFactory {
  private FiniteStateMachineUMLMTAdaptersFactory adaptersFactory = finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory.getInstance();
  
  private FinitestatemachinescompositeFactory finitestatemachinescompositeAdaptee = finitestatemachinescomposite.FinitestatemachinescompositeFactory.eINSTANCE;
  
  @Override
  public NamedElement createNamedElement() {
    return adaptersFactory.createNamedElementAdapter(finitestatemachinescompositeAdaptee.createNamedElement()) ;
  }
  
  @Override
  public StateMachine createStateMachine() {
    return adaptersFactory.createStateMachineAdapter(finitestatemachinescompositeAdaptee.createStateMachine()) ;
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(finitestatemachinescompositeAdaptee.createState()) ;
  }
  
  @Override
  public FinalState createFinalState() {
    return adaptersFactory.createFinalStateAdapter(finitestatemachinescompositeAdaptee.createFinalState()) ;
  }
  
  @Override
  public InitialState createInitialState() {
    return adaptersFactory.createInitialStateAdapter(finitestatemachinescompositeAdaptee.createInitialState()) ;
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(finitestatemachinescompositeAdaptee.createTransition()) ;
  }
  
  @Override
  public TimedTransition createTimedTransition() {
    return adaptersFactory.createTimedTransitionAdapter(finitestatemachinescompositeAdaptee.createTimedTransition()) ;
  }
  
  @Override
  public Trigger createTrigger() {
    return adaptersFactory.createTriggerAdapter(finitestatemachinescompositeAdaptee.createTrigger()) ;
  }
  
  @Override
  public Pseudostate createPseudostate() {
    return adaptersFactory.createPseudostateAdapter(finitestatemachinescompositeAdaptee.createPseudostate()) ;
  }
  
  @Override
  public Fork createFork() {
    return adaptersFactory.createForkAdapter(finitestatemachinescompositeAdaptee.createFork()) ;
  }
  
  @Override
  public Join createJoin() {
    return adaptersFactory.createJoinAdapter(finitestatemachinescompositeAdaptee.createJoin()) ;
  }
  
  @Override
  public CompositeState createCompositeState() {
    return adaptersFactory.createCompositeStateAdapter(finitestatemachinescompositeAdaptee.createCompositeState()) ;
  }
  
  @Override
  public Region createRegion() {
    return adaptersFactory.createRegionAdapter(finitestatemachinescompositeAdaptee.createRegion()) ;
  }
  
  @Override
  public Action createAction() {
    return adaptersFactory.createActionAdapter(finitestatemachinescompositeAdaptee.createAction()) ;
  }
  
  @Override
  public Variable createVariable() {
    return adaptersFactory.createVariableAdapter(finitestatemachinescompositeAdaptee.createVariable()) ;
  }
  
  @Override
  public Choice createChoice() {
    return adaptersFactory.createChoiceAdapter(finitestatemachinescompositeAdaptee.createChoice()) ;
  }
  
  @Override
  public Guard createGuard() {
    return adaptersFactory.createGuardAdapter(finitestatemachinescompositeAdaptee.createGuard()) ;
  }
}
