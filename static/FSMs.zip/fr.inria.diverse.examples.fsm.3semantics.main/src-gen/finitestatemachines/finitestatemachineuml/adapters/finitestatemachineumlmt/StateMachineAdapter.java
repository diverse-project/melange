package finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory;
import finitestatemachines.finitestatemachineumlmt.Action;
import finitestatemachines.finitestatemachineumlmt.State;
import finitestatemachines.finitestatemachineumlmt.Transition;
import finitestatemachines.finitestatemachineumlmt.Variable;
import finitestatemachinescomposite.StateMachine;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class StateMachineAdapter extends EObjectAdapter<StateMachine> implements finitestatemachines.finitestatemachineumlmt.StateMachine {
  private FiniteStateMachineUMLMTAdaptersFactory adaptersFactory;
  
  public StateMachineAdapter() {
    super(finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public EList<State> getStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.StateAdapter.class) ;
  }
  
  @Override
  public EList<Transition> getTransitions() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getTransitions(), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<Variable> getVariables() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getVariables(), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.VariableAdapter.class) ;
  }
  
  @Override
  public void eval(final Context context, final String filePath) {
    finitestatemachines.composite.uml.StateMachineAspect.eval(adaptee, context
    , filePath
    ) ;
  }
  
  @Override
  public EList<State> getAllCurrentStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.uml.StateMachineAspect.getAllCurrentStates(adaptee), finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.StateAdapter.class) ;
  }
  
  @Override
  public boolean isValid(final String expression) {
    return finitestatemachines.composite.uml.StateMachineAspect.isValid(adaptee, expression
    ) ;
  }
  
  @Override
  public void update(final Action action) {
    finitestatemachines.composite.uml.StateMachineAspect.update(adaptee, ((finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.ActionAdapter) action).getAdaptee()
    ) ;
  }
  
  @Override
  public void addCurrentState(final State s) {
    finitestatemachines.composite.uml.StateMachineAspect.addCurrentState(adaptee, ((finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.StateAdapter) s).getAdaptee()
    ) ;
  }
  
  @Override
  public void removeCurrentState(final State s) {
    finitestatemachines.composite.uml.StateMachineAspect.removeCurrentState(adaptee, ((finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.StateAdapter) s).getAdaptee()
    ) ;
  }
  
  @Override
  public boolean isCurrentState(final State s) {
    return finitestatemachines.composite.uml.StateMachineAspect.isCurrentState(adaptee, ((finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.StateAdapter) s).getAdaptee()
    ) ;
  }
}
