package finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachinerhapsodymt.Action;
import finitestatemachines.finitestatemachinerhapsodymt.State;
import finitestatemachines.finitestatemachinerhapsodymt.Transition;
import finitestatemachines.finitestatemachinerhapsodymt.Variable;
import finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory;
import finitestatemachinescomposite.StateMachine;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class StateMachineAdapter extends EObjectAdapter<StateMachine> implements finitestatemachines.finitestatemachinerhapsodymt.StateMachine {
  private FiniteStateMachineRhapsodyMTAdaptersFactory adaptersFactory;
  
  public StateMachineAdapter() {
    super(finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public EList<State> getStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.StateAdapter.class) ;
  }
  
  @Override
  public EList<Transition> getTransitions() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getTransitions(), finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<Variable> getVariables() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getVariables(), finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.VariableAdapter.class) ;
  }
  
  @Override
  public void eval(final Context context, final String filePath) {
    finitestatemachines.composite.uml.StateMachineAspect.eval(adaptee, context
    , filePath
    ) ;
  }
  
  @Override
  public EList<State> getAllCurrentStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.uml.StateMachineAspect.getAllCurrentStates(adaptee), finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.StateAdapter.class) ;
  }
  
  @Override
  public boolean isValid(final String expression) {
    return finitestatemachines.composite.uml.StateMachineAspect.isValid(adaptee, expression
    ) ;
  }
  
  @Override
  public void update(final Action action) {
    finitestatemachines.composite.uml.StateMachineAspect.update(adaptee, ((finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.ActionAdapter) action).getAdaptee()
    ) ;
  }
  
  @Override
  public void addCurrentState(final State s) {
    finitestatemachines.composite.uml.StateMachineAspect.addCurrentState(adaptee, ((finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.StateAdapter) s).getAdaptee()
    ) ;
  }
  
  @Override
  public void removeCurrentState(final State s) {
    finitestatemachines.composite.uml.StateMachineAspect.removeCurrentState(adaptee, ((finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.StateAdapter) s).getAdaptee()
    ) ;
  }
  
  @Override
  public boolean isCurrentState(final State s) {
    return finitestatemachines.composite.uml.StateMachineAspect.isCurrentState(adaptee, ((finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.StateAdapter) s).getAdaptee()
    ) ;
  }
}
