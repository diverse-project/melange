package finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt;

import finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory;
import finitestatemachinescomposite.Guard;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class GuardAdapter extends EObjectAdapter<Guard> implements finitestatemachines.finitestatemachinerhapsodymt.Guard {
  private FiniteStateMachineRhapsodyMTAdaptersFactory adaptersFactory;
  
  public GuardAdapter() {
    super(finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
}
