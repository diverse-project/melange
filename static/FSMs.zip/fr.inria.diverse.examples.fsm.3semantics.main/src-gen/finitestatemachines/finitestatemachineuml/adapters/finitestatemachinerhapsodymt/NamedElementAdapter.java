package finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt;

import finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory;
import finitestatemachinescomposite.NamedElement;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class NamedElementAdapter extends EObjectAdapter<NamedElement> implements finitestatemachines.finitestatemachinerhapsodymt.NamedElement {
  private FiniteStateMachineRhapsodyMTAdaptersFactory adaptersFactory;
  
  public NamedElementAdapter() {
    super(finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
}
