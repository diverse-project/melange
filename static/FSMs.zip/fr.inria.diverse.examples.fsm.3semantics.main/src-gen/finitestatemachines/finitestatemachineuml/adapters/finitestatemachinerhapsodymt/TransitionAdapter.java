package finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachinerhapsodymt.Action;
import finitestatemachines.finitestatemachinerhapsodymt.Guard;
import finitestatemachines.finitestatemachinerhapsodymt.State;
import finitestatemachines.finitestatemachinerhapsodymt.StateMachine;
import finitestatemachines.finitestatemachinerhapsodymt.Trigger;
import finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory;
import finitestatemachinescomposite.Transition;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class TransitionAdapter extends EObjectAdapter<Transition> implements finitestatemachines.finitestatemachinerhapsodymt.Transition {
  private FiniteStateMachineRhapsodyMTAdaptersFactory adaptersFactory;
  
  public TransitionAdapter() {
    super(finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public State getTarget() {
    return adaptersFactory.createStateAdapter(adaptee.getTarget()) ;
  }
  
  @Override
  public void setTarget(final State o) {
    adaptee.setTarget(((finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.StateAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public State getSource() {
    return adaptersFactory.createStateAdapter(adaptee.getSource()) ;
  }
  
  @Override
  public void setSource(final State o) {
    adaptee.setSource(((finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.StateAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public Trigger getTrigger() {
    return adaptersFactory.createTriggerAdapter(adaptee.getTrigger()) ;
  }
  
  @Override
  public void setTrigger(final Trigger o) {
    adaptee.setTrigger(((finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.TriggerAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return adaptersFactory.createStateMachineAdapter(adaptee.getStateMachine()) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    adaptee.setStateMachine(((finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.StateMachineAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public Guard getGuard() {
    return adaptersFactory.createGuardAdapter(adaptee.getGuard()) ;
  }
  
  @Override
  public void setGuard(final Guard o) {
    adaptee.setGuard(((finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.GuardAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public Action getAction() {
    return adaptersFactory.createActionAdapter(adaptee.getAction()) ;
  }
  
  @Override
  public void setAction(final Action o) {
    adaptee.setAction(((finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.ActionAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public void fire(final Context context) {
    finitestatemachines.composite.uml.TransitionAspect.fire(adaptee, context
    ) ;
  }
}
