package finitestatemachines;

import finitestatemachines.finitestatemachineclassicmt.FiniteStateMachineClassicMTFactory;
import fr.inria.diverse.melange.lib.IModelType;
import java.io.IOException;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface FiniteStateMachineClassicMT extends IModelType {
  public abstract EList<EObject> getContents();
  
  public abstract FiniteStateMachineClassicMTFactory getFactory();
  
  public void save(final String uri) throws IOException;
}
