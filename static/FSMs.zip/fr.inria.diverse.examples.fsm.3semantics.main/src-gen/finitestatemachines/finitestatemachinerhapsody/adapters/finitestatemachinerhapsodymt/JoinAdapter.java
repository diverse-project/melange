package finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory;
import finitestatemachines.finitestatemachinerhapsodymt.CompositeState;
import finitestatemachines.finitestatemachinerhapsodymt.State;
import finitestatemachines.finitestatemachinerhapsodymt.StateMachine;
import finitestatemachines.finitestatemachinerhapsodymt.Transition;
import finitestatemachinescomposite.Join;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class JoinAdapter extends EObjectAdapter<Join> implements finitestatemachines.finitestatemachinerhapsodymt.Join {
  private FiniteStateMachineRhapsodyMTAdaptersFactory adaptersFactory;
  
  public JoinAdapter() {
    super(finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public EList<Transition> getOutgoing() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getOutgoing(), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<Transition> getIncoming() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getIncoming(), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.TransitionAdapter.class) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return adaptersFactory.createStateMachineAdapter(adaptee.getStateMachine()) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    adaptee.setStateMachine(((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.StateMachineAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public CompositeState getParentState() {
    return adaptersFactory.createCompositeStateAdapter(adaptee.getParentState()) ;
  }
  
  @Override
  public void setParentState(final CompositeState o) {
    adaptee.setParentState(((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.CompositeStateAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public void run(final Context context) {
    finitestatemachines.composite.rhapsody.StateAspect.run(adaptee, context
    ) ;
  }
  
  @Override
  public EList<Transition> getActiveTransitions(final String event) {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.rhapsody.StateAspect.getActiveTransitions(adaptee, event
    ), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<State> getAllParents() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.rhapsody.StateAspect.getAllParents(adaptee), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.StateAdapter.class) ;
  }
  
  @Override
  public EList<State> getAllChildren() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.rhapsody.StateAspect.getAllChildren(adaptee), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.StateAdapter.class) ;
  }
}
