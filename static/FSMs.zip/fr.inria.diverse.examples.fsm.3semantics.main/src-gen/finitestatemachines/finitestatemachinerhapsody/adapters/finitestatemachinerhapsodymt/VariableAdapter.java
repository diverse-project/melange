package finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt;

import finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory;
import finitestatemachinescomposite.Variable;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class VariableAdapter extends EObjectAdapter<Variable> implements finitestatemachines.finitestatemachinerhapsodymt.Variable {
  private FiniteStateMachineRhapsodyMTAdaptersFactory adaptersFactory;
  
  public VariableAdapter() {
    super(finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public boolean isValue() {
    return adaptee.isValue() ;
  }
  
  @Override
  public void setValue(final boolean o) {
    adaptee.setValue(o) ;
  }
}
