package finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt;

import finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory;
import finitestatemachinescomposite.Trigger;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class TriggerAdapter extends EObjectAdapter<Trigger> implements finitestatemachines.finitestatemachinerhapsodymt.Trigger {
  private FiniteStateMachineRhapsodyMTAdaptersFactory adaptersFactory;
  
  public TriggerAdapter() {
    super(finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
}
