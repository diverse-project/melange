package finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachineclassicmt.CompositeState;
import finitestatemachines.finitestatemachineclassicmt.State;
import finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachinescomposite.Region;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class RegionAdapter extends EObjectAdapter<Region> implements finitestatemachines.finitestatemachineclassicmt.Region {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory;
  
  public RegionAdapter() {
    super(finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public EList<State> getStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.StateAdapter.class) ;
  }
  
  @Override
  public CompositeState getParent() {
    return adaptersFactory.createCompositeStateAdapter(adaptee.getParent()) ;
  }
  
  @Override
  public void setParent(final CompositeState o) {
    adaptee.setParent(((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.CompositeStateAdapter) o).getAdaptee()) ;
  }
}
