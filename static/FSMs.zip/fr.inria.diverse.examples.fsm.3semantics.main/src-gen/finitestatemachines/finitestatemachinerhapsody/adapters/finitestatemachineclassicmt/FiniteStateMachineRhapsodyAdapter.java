package finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt;

import finitestatemachines.FiniteStateMachineClassicMT;
import finitestatemachines.finitestatemachineclassicmt.FiniteStateMachineClassicMTFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;

@SuppressWarnings("all")
public class FiniteStateMachineRhapsodyAdapter extends ResourceAdapter implements FiniteStateMachineClassicMT {
  public FiniteStateMachineRhapsodyAdapter() {
    super(finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FiniteStateMachineClassicMTFactory getFactory() {
    return new finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(org.eclipse.emf.common.util.URI.createURI(uri));
    this.adaptee.save(null);
  }
}
