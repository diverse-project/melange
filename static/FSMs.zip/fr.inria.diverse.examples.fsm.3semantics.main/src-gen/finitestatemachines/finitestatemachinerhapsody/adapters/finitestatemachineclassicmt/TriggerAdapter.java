package finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachinescomposite.Trigger;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class TriggerAdapter extends EObjectAdapter<Trigger> implements finitestatemachines.finitestatemachineclassicmt.Trigger {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory;
  
  public TriggerAdapter() {
    super(finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
}
