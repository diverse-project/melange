package finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachinescomposite.Guard;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class GuardAdapter extends EObjectAdapter<Guard> implements finitestatemachines.finitestatemachineclassicmt.Guard {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory;
  
  public GuardAdapter() {
    super(finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
}
