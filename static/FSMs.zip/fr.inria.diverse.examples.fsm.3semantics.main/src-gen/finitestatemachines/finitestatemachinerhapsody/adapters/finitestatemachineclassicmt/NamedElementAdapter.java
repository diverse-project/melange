package finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachinescomposite.NamedElement;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class NamedElementAdapter extends EObjectAdapter<NamedElement> implements finitestatemachines.finitestatemachineclassicmt.NamedElement {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory;
  
  public NamedElementAdapter() {
    super(finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
}
