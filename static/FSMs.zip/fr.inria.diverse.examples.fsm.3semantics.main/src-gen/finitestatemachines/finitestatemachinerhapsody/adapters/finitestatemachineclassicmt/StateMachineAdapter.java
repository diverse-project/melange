package finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachineclassicmt.Action;
import finitestatemachines.finitestatemachineclassicmt.State;
import finitestatemachines.finitestatemachineclassicmt.Transition;
import finitestatemachines.finitestatemachineclassicmt.Variable;
import finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachinescomposite.StateMachine;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class StateMachineAdapter extends EObjectAdapter<StateMachine> implements finitestatemachines.finitestatemachineclassicmt.StateMachine {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory;
  
  public StateMachineAdapter() {
    super(finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public EList<State> getStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.StateAdapter.class) ;
  }
  
  @Override
  public EList<Transition> getTransitions() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getTransitions(), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<Variable> getVariables() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getVariables(), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.VariableAdapter.class) ;
  }
  
  @Override
  public void eval(final Context context, final String filePath) {
    finitestatemachines.composite.rhapsody.StateMachineAspect.eval(adaptee, context
    , filePath
    ) ;
  }
  
  @Override
  public EList<State> getAllCurrentStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.rhapsody.StateMachineAspect.getAllCurrentStates(adaptee), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.StateAdapter.class) ;
  }
  
  @Override
  public boolean isValid(final String expression) {
    return finitestatemachines.composite.rhapsody.StateMachineAspect.isValid(adaptee, expression
    ) ;
  }
  
  @Override
  public void update(final Action action) {
    finitestatemachines.composite.rhapsody.StateMachineAspect.update(adaptee, ((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.ActionAdapter) action).getAdaptee()
    ) ;
  }
  
  @Override
  public void addCurrentState(final State s) {
    finitestatemachines.composite.rhapsody.StateMachineAspect.addCurrentState(adaptee, ((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.StateAdapter) s).getAdaptee()
    ) ;
  }
  
  @Override
  public void removeCurrentState(final State s) {
    finitestatemachines.composite.rhapsody.StateMachineAspect.removeCurrentState(adaptee, ((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.StateAdapter) s).getAdaptee()
    ) ;
  }
  
  @Override
  public boolean isCurrentState(final State s) {
    return finitestatemachines.composite.rhapsody.StateMachineAspect.isCurrentState(adaptee, ((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.StateAdapter) s).getAdaptee()
    ) ;
  }
}
