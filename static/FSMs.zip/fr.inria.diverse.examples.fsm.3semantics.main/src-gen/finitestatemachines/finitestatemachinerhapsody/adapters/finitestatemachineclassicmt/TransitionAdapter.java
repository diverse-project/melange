package finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachineclassicmt.Action;
import finitestatemachines.finitestatemachineclassicmt.Guard;
import finitestatemachines.finitestatemachineclassicmt.State;
import finitestatemachines.finitestatemachineclassicmt.StateMachine;
import finitestatemachines.finitestatemachineclassicmt.Trigger;
import finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachinescomposite.Transition;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class TransitionAdapter extends EObjectAdapter<Transition> implements finitestatemachines.finitestatemachineclassicmt.Transition {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory;
  
  public TransitionAdapter() {
    super(finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public State getTarget() {
    return adaptersFactory.createStateAdapter(adaptee.getTarget()) ;
  }
  
  @Override
  public void setTarget(final State o) {
    adaptee.setTarget(((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.StateAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public State getSource() {
    return adaptersFactory.createStateAdapter(adaptee.getSource()) ;
  }
  
  @Override
  public void setSource(final State o) {
    adaptee.setSource(((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.StateAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public Trigger getTrigger() {
    return adaptersFactory.createTriggerAdapter(adaptee.getTrigger()) ;
  }
  
  @Override
  public void setTrigger(final Trigger o) {
    adaptee.setTrigger(((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.TriggerAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return adaptersFactory.createStateMachineAdapter(adaptee.getStateMachine()) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    adaptee.setStateMachine(((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.StateMachineAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public Guard getGuard() {
    return adaptersFactory.createGuardAdapter(adaptee.getGuard()) ;
  }
  
  @Override
  public void setGuard(final Guard o) {
    adaptee.setGuard(((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.GuardAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public Action getAction() {
    return adaptersFactory.createActionAdapter(adaptee.getAction()) ;
  }
  
  @Override
  public void setAction(final Action o) {
    adaptee.setAction(((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.ActionAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public void fire(final Context context) {
    finitestatemachines.composite.rhapsody.TransitionAspect.fire(adaptee, context
    ) ;
  }
}
