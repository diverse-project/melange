package finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory;
import finitestatemachines.finitestatemachineumlmt.Action;
import finitestatemachines.finitestatemachineumlmt.State;
import finitestatemachines.finitestatemachineumlmt.Transition;
import finitestatemachines.finitestatemachineumlmt.Variable;
import finitestatemachinescomposite.StateMachine;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class StateMachineAdapter extends EObjectAdapter<StateMachine> implements finitestatemachines.finitestatemachineumlmt.StateMachine {
  private FiniteStateMachineUMLMTAdaptersFactory adaptersFactory;
  
  public StateMachineAdapter() {
    super(finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public EList<State> getStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.StateAdapter.class) ;
  }
  
  @Override
  public EList<Transition> getTransitions() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getTransitions(), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<Variable> getVariables() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getVariables(), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.VariableAdapter.class) ;
  }
  
  @Override
  public void eval(final Context context, final String filePath) {
    finitestatemachines.composite.rhapsody.StateMachineAspect.eval(adaptee, context
    , filePath
    ) ;
  }
  
  @Override
  public EList<State> getAllCurrentStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.rhapsody.StateMachineAspect.getAllCurrentStates(adaptee), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.StateAdapter.class) ;
  }
  
  @Override
  public boolean isValid(final String expression) {
    return finitestatemachines.composite.rhapsody.StateMachineAspect.isValid(adaptee, expression
    ) ;
  }
  
  @Override
  public void update(final Action action) {
    finitestatemachines.composite.rhapsody.StateMachineAspect.update(adaptee, ((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.ActionAdapter) action).getAdaptee()
    ) ;
  }
  
  @Override
  public void addCurrentState(final State s) {
    finitestatemachines.composite.rhapsody.StateMachineAspect.addCurrentState(adaptee, ((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.StateAdapter) s).getAdaptee()
    ) ;
  }
  
  @Override
  public void removeCurrentState(final State s) {
    finitestatemachines.composite.rhapsody.StateMachineAspect.removeCurrentState(adaptee, ((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.StateAdapter) s).getAdaptee()
    ) ;
  }
  
  @Override
  public boolean isCurrentState(final State s) {
    return finitestatemachines.composite.rhapsody.StateMachineAspect.isCurrentState(adaptee, ((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.StateAdapter) s).getAdaptee()
    ) ;
  }
}
