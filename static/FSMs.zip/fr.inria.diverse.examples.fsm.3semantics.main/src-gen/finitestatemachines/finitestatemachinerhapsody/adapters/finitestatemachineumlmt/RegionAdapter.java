package finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt;

import finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory;
import finitestatemachines.finitestatemachineumlmt.CompositeState;
import finitestatemachines.finitestatemachineumlmt.State;
import finitestatemachinescomposite.Region;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class RegionAdapter extends EObjectAdapter<Region> implements finitestatemachines.finitestatemachineumlmt.Region {
  private FiniteStateMachineUMLMTAdaptersFactory adaptersFactory;
  
  public RegionAdapter() {
    super(finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public EList<State> getStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.StateAdapter.class) ;
  }
  
  @Override
  public CompositeState getParent() {
    return adaptersFactory.createCompositeStateAdapter(adaptee.getParent()) ;
  }
  
  @Override
  public void setParent(final CompositeState o) {
    adaptee.setParent(((finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.CompositeStateAdapter) o).getAdaptee()) ;
  }
}
