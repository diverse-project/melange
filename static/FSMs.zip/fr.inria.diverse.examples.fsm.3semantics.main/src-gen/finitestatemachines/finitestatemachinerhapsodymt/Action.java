package finitestatemachines.finitestatemachinerhapsodymt;

import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface Action extends EObject {
  public String getVariable();
  
  public void setVariable(final String newVariable);
  
  public boolean isValue();
  
  public void setValue(final boolean newValue);
}
