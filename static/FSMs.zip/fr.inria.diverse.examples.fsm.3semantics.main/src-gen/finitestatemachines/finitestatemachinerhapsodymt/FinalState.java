package finitestatemachines.finitestatemachinerhapsodymt;

import finitestatemachines.finitestatemachinerhapsodymt.State;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface FinalState extends EObject, State {
}
