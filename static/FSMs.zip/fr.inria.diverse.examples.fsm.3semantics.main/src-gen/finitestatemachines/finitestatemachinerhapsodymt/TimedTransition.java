package finitestatemachines.finitestatemachinerhapsodymt;

import finitestatemachines.finitestatemachinerhapsodymt.Transition;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface TimedTransition extends EObject, Transition {
  public int getDuration();
  
  public void setDuration(final int newDuration);
}
