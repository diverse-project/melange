package finitestatemachines.finitestatemachinerhapsodymt;

import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface NamedElement extends EObject {
  public String getName();
  
  public void setName(final String newName);
}
