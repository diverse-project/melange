package finitestatemachines.finitestatemachinerhapsodymt;

import finitestatemachines.finitestatemachinerhapsodymt.Pseudostate;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface Join extends EObject, Pseudostate {
}
