package finitestatemachines.finitestatemachinerhapsodymt;

import finitestatemachines.finitestatemachinerhapsodymt.Action;
import finitestatemachines.finitestatemachinerhapsodymt.Choice;
import finitestatemachines.finitestatemachinerhapsodymt.CompositeState;
import finitestatemachines.finitestatemachinerhapsodymt.FinalState;
import finitestatemachines.finitestatemachinerhapsodymt.Fork;
import finitestatemachines.finitestatemachinerhapsodymt.Guard;
import finitestatemachines.finitestatemachinerhapsodymt.InitialState;
import finitestatemachines.finitestatemachinerhapsodymt.Join;
import finitestatemachines.finitestatemachinerhapsodymt.NamedElement;
import finitestatemachines.finitestatemachinerhapsodymt.Pseudostate;
import finitestatemachines.finitestatemachinerhapsodymt.Region;
import finitestatemachines.finitestatemachinerhapsodymt.State;
import finitestatemachines.finitestatemachinerhapsodymt.StateMachine;
import finitestatemachines.finitestatemachinerhapsodymt.TimedTransition;
import finitestatemachines.finitestatemachinerhapsodymt.Transition;
import finitestatemachines.finitestatemachinerhapsodymt.Trigger;
import finitestatemachines.finitestatemachinerhapsodymt.Variable;
import fr.inria.diverse.melange.lib.IFactory;

@SuppressWarnings("all")
public interface FiniteStateMachineRhapsodyMTFactory extends IFactory {
  public abstract NamedElement createNamedElement();
  
  public abstract StateMachine createStateMachine();
  
  public abstract State createState();
  
  public abstract FinalState createFinalState();
  
  public abstract InitialState createInitialState();
  
  public abstract Transition createTransition();
  
  public abstract TimedTransition createTimedTransition();
  
  public abstract Trigger createTrigger();
  
  public abstract Pseudostate createPseudostate();
  
  public abstract Fork createFork();
  
  public abstract Join createJoin();
  
  public abstract CompositeState createCompositeState();
  
  public abstract Region createRegion();
  
  public abstract Action createAction();
  
  public abstract Variable createVariable();
  
  public abstract Choice createChoice();
  
  public abstract Guard createGuard();
}
