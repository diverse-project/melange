package finitestatemachines.finitestatemachinerhapsodymt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachinerhapsodymt.Action;
import finitestatemachines.finitestatemachinerhapsodymt.Guard;
import finitestatemachines.finitestatemachinerhapsodymt.NamedElement;
import finitestatemachines.finitestatemachinerhapsodymt.State;
import finitestatemachines.finitestatemachinerhapsodymt.StateMachine;
import finitestatemachines.finitestatemachinerhapsodymt.Trigger;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface Transition extends EObject, NamedElement {
  public int getInitialTime();
  
  public void setInitialTime(final int newInitialTime);
  
  public int getFinalTime();
  
  public void setFinalTime(final int newFinalTime);
  
  public State getTarget();
  
  public void setTarget(final State newTarget);
  
  public State getSource();
  
  public void setSource(final State newSource);
  
  public Trigger getTrigger();
  
  public void setTrigger(final Trigger newTrigger);
  
  public StateMachine getStateMachine();
  
  public void setStateMachine(final StateMachine newStateMachine);
  
  public Guard getGuard();
  
  public void setGuard(final Guard newGuard);
  
  public Action getAction();
  
  public void setAction(final Action newAction);
  
  public void fire(final Context context);
}
