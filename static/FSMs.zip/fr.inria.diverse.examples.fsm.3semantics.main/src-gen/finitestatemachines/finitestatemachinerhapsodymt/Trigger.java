package finitestatemachines.finitestatemachinerhapsodymt;

import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface Trigger extends EObject {
  public String getExpression();
  
  public void setExpression(final String newExpression);
}
