package finitestatemachines.finitestatemachinerhapsodymt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachinerhapsodymt.CompositeState;
import finitestatemachines.finitestatemachinerhapsodymt.NamedElement;
import finitestatemachines.finitestatemachinerhapsodymt.StateMachine;
import finitestatemachines.finitestatemachinerhapsodymt.Transition;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface State extends EObject, NamedElement {
  public int getInitialTime();
  
  public void setInitialTime(final int newInitialTime);
  
  public int getFinalTime();
  
  public void setFinalTime(final int newFinalTime);
  
  public EList<Transition> getOutgoing();
  
  public EList<Transition> getIncoming();
  
  public StateMachine getStateMachine();
  
  public void setStateMachine(final StateMachine newStateMachine);
  
  public CompositeState getParentState();
  
  public void setParentState(final CompositeState newParentState);
  
  public void run(final Context context);
  
  public EList<Transition> getActiveTransitions(final String event);
  
  public EList<State> getAllParents();
  
  public EList<State> getAllChildren();
}
