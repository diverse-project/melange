package finitestatemachines.finitestatemachinerhapsodymt;

import finitestatemachines.finitestatemachinerhapsodymt.CompositeState;
import finitestatemachines.finitestatemachinerhapsodymt.State;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface Region extends EObject {
  public EList<State> getStates();
  
  public CompositeState getParent();
  
  public void setParent(final CompositeState newParent);
}
