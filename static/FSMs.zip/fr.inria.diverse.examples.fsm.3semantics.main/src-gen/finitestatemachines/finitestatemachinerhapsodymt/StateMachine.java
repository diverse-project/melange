package finitestatemachines.finitestatemachinerhapsodymt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachinerhapsodymt.Action;
import finitestatemachines.finitestatemachinerhapsodymt.NamedElement;
import finitestatemachines.finitestatemachinerhapsodymt.State;
import finitestatemachines.finitestatemachinerhapsodymt.Transition;
import finitestatemachines.finitestatemachinerhapsodymt.Variable;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface StateMachine extends EObject, NamedElement {
  public EList<State> getStates();
  
  public EList<Transition> getTransitions();
  
  public EList<Variable> getVariables();
  
  public void eval(final Context context, final String filePath);
  
  public EList<State> getAllCurrentStates();
  
  public boolean isValid(final String expression);
  
  public void update(final Action action);
  
  public void addCurrentState(final State s);
  
  public void removeCurrentState(final State s);
  
  public boolean isCurrentState(final State s);
}
