package finitestatemachines;

@SuppressWarnings("all")
public class StandaloneSetup {
  public static void doSetup() {
    StandaloneSetup setup = new StandaloneSetup() ;
    setup.doEMFRegistration() ;
    setup.doAdaptersRegistration() ;
  }
  
  public void doEMFRegistration() {
    org.eclipse.emf.ecore.EPackage.Registry.INSTANCE.put(
    	finitestatemachinescomposite.FinitestatemachinescompositePackage.eNS_URI,
    	finitestatemachinescomposite.FinitestatemachinescompositePackage.eINSTANCE
    ) ;
    org.eclipse.emf.ecore.EPackage.Registry.INSTANCE.put(
    	finitestatemachinescomposite.FinitestatemachinescompositePackage.eNS_URI,
    	finitestatemachinescomposite.FinitestatemachinescompositePackage.eINSTANCE
    ) ;
    org.eclipse.emf.ecore.EPackage.Registry.INSTANCE.put(
    	finitestatemachinescomposite.FinitestatemachinescompositePackage.eNS_URI,
    	finitestatemachinescomposite.FinitestatemachinescompositePackage.eINSTANCE
    ) ;
    
    org.eclipse.emf.ecore.resource.Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put(
    	"*",
    	new org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl()
    ) ;
  }
  
  public void doAdaptersRegistration() {
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineUML",
    	"finitestatemachines.FiniteStateMachineUMLMT",
    	finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.FiniteStateMachineUMLAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineUMLMT",
    	  finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.FiniteStateMachineUMLAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineUML",
    	"finitestatemachines.FiniteStateMachineRhapsodyMT",
    	finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.FiniteStateMachineUMLAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineRhapsodyMT",
    	  finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.FiniteStateMachineUMLAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineUML",
    	"finitestatemachines.FiniteStateMachineClassicMT",
    	finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.FiniteStateMachineUMLAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineClassicMT",
    	  finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.FiniteStateMachineUMLAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineRhapsody",
    	"finitestatemachines.FiniteStateMachineUMLMT",
    	finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.FiniteStateMachineRhapsodyAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineUMLMT",
    	  finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.FiniteStateMachineRhapsodyAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineRhapsody",
    	"finitestatemachines.FiniteStateMachineRhapsodyMT",
    	finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineRhapsodyMT",
    	  finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineRhapsody",
    	"finitestatemachines.FiniteStateMachineClassicMT",
    	finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineRhapsodyAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineClassicMT",
    	  finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineRhapsodyAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineClassic",
    	"finitestatemachines.FiniteStateMachineUMLMT",
    	finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineClassicAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineUMLMT",
    	  finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineClassicAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineClassic",
    	"finitestatemachines.FiniteStateMachineRhapsodyMT",
    	finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.FiniteStateMachineClassicAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineRhapsodyMT",
    	  finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.FiniteStateMachineClassicAdapter.class
    ) ;
    fr.inria.diverse.melange.lib.AdaptersRegistry.getInstance().registerAdapter(
    	"finitestatemachines.FiniteStateMachineClassic",
    	"finitestatemachines.FiniteStateMachineClassicMT",
    	finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicAdapter.class
    ) ;
    fr.inria.diverse.melange.resource.ModelTypeAdapter.Registry.INSTANCE.registerAdapter(
    	  "http://fr.inria.diverse.examples.fsm.composite",
    	  "FiniteStateMachineClassicMT",
    	  finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicAdapter.class
    ) ;
  }
}
