package finitestatemachines;

import finitestatemachines.FiniteStateMachineClassicMT;
import finitestatemachines.FiniteStateMachineRhapsodyMT;
import finitestatemachines.FiniteStateMachineUMLMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FiniteStateMachineUML implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static FiniteStateMachineUML load(final String uri) {
    org.eclipse.emf.ecore.resource.ResourceSet rs = new org.eclipse.emf.ecore.resource.impl.ResourceSetImpl() ;
    Resource res = rs.getResource(org.eclipse.emf.common.util.URI.createURI(uri), true) ;
    FiniteStateMachineUML mm = new FiniteStateMachineUML() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FiniteStateMachineUMLMT toFiniteStateMachineUMLMT() {
    finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.FiniteStateMachineUMLAdapter adaptee = new finitestatemachines.finitestatemachineuml.adapters.finitestatemachineumlmt.FiniteStateMachineUMLAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineRhapsodyMT toFiniteStateMachineRhapsodyMT() {
    finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.FiniteStateMachineUMLAdapter adaptee = new finitestatemachines.finitestatemachineuml.adapters.finitestatemachinerhapsodymt.FiniteStateMachineUMLAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineClassicMT toFiniteStateMachineClassicMT() {
    finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.FiniteStateMachineUMLAdapter adaptee = new finitestatemachines.finitestatemachineuml.adapters.finitestatemachineclassicmt.FiniteStateMachineUMLAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
