package finitestatemachines;

import finitestatemachines.FiniteStateMachineClassic;
import finitestatemachines.FiniteStateMachineRhapsody;
import finitestatemachines.FiniteStateMachineUML;
import finitestatemachines.execute;

@SuppressWarnings("all")
public class main {
  public static void call() {
    final FiniteStateMachineUML simpleProgram = FiniteStateMachineUML.load("input/exampleComposite.xmi");
    long _currentTimeMillis = System.currentTimeMillis();
    String _plus = ("output/UML-output " + Long.valueOf(_currentTimeMillis));
    String _plus_1 = (_plus + ".pdf");
    execute.call(simpleProgram.toFiniteStateMachineUMLMT(), "{e}", _plus_1);
    final FiniteStateMachineRhapsody simpleProgram2 = FiniteStateMachineRhapsody.load("input/exampleComposite.xmi");
    long _currentTimeMillis_1 = System.currentTimeMillis();
    String _plus_2 = ("output/Rhapsody-output " + Long.valueOf(_currentTimeMillis_1));
    String _plus_3 = (_plus_2 + ".pdf");
    execute.call(simpleProgram2.toFiniteStateMachineUMLMT(), "{e}", _plus_3);
    final FiniteStateMachineClassic simpleProgram3 = FiniteStateMachineClassic.load("input/exampleComposite.xmi");
    long _currentTimeMillis_2 = System.currentTimeMillis();
    String _plus_4 = ("output/Classic-output " + Long.valueOf(_currentTimeMillis_2));
    String _plus_5 = (_plus_4 + ".pdf");
    execute.call(simpleProgram3.toFiniteStateMachineUMLMT(), "{e}", _plus_5);
  }
  
  public static void main(final String[] args) {
    StandaloneSetup.doSetup() ;
    call() ;
  }
}
