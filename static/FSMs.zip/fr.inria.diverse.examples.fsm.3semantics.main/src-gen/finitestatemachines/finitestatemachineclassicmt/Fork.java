package finitestatemachines.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachineclassicmt.Pseudostate;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface Fork extends EObject, Pseudostate {
}
