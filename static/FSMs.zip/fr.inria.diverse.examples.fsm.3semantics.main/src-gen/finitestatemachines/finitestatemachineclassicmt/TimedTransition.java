package finitestatemachines.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachineclassicmt.Transition;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface TimedTransition extends EObject, Transition {
  public int getDuration();
  
  public void setDuration(final int newDuration);
}
