package finitestatemachines.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachineclassicmt.State;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface InitialState extends EObject, State {
}
