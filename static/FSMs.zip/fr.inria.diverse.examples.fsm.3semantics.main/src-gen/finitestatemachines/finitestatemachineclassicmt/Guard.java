package finitestatemachines.finitestatemachineclassicmt;

import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface Guard extends EObject {
  public String getExpression();
  
  public void setExpression(final String newExpression);
}
