package finitestatemachines.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachineclassicmt.Region;
import finitestatemachines.finitestatemachineclassicmt.State;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface CompositeState extends EObject, State {
  public EList<Region> getRegions();
}
