package finitestatemachines.finitestatemachineclassicmt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachineclassicmt.Action;
import finitestatemachines.finitestatemachineclassicmt.NamedElement;
import finitestatemachines.finitestatemachineclassicmt.State;
import finitestatemachines.finitestatemachineclassicmt.Transition;
import finitestatemachines.finitestatemachineclassicmt.Variable;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface StateMachine extends EObject, NamedElement {
  public EList<State> getStates();
  
  public EList<Transition> getTransitions();
  
  public EList<Variable> getVariables();
  
  public void eval(final Context context, final String filePath);
  
  public EList<State> getAllCurrentStates();
  
  public boolean isValid(final String expression);
  
  public void update(final Action action);
  
  public void addCurrentState(final State s);
  
  public void removeCurrentState(final State s);
  
  public boolean isCurrentState(final State s);
}
