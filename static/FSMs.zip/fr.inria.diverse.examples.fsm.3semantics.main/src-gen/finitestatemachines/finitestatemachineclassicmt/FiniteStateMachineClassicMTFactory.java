package finitestatemachines.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachineclassicmt.Action;
import finitestatemachines.finitestatemachineclassicmt.Choice;
import finitestatemachines.finitestatemachineclassicmt.CompositeState;
import finitestatemachines.finitestatemachineclassicmt.FinalState;
import finitestatemachines.finitestatemachineclassicmt.Fork;
import finitestatemachines.finitestatemachineclassicmt.Guard;
import finitestatemachines.finitestatemachineclassicmt.InitialState;
import finitestatemachines.finitestatemachineclassicmt.Join;
import finitestatemachines.finitestatemachineclassicmt.NamedElement;
import finitestatemachines.finitestatemachineclassicmt.Pseudostate;
import finitestatemachines.finitestatemachineclassicmt.Region;
import finitestatemachines.finitestatemachineclassicmt.State;
import finitestatemachines.finitestatemachineclassicmt.StateMachine;
import finitestatemachines.finitestatemachineclassicmt.TimedTransition;
import finitestatemachines.finitestatemachineclassicmt.Transition;
import finitestatemachines.finitestatemachineclassicmt.Trigger;
import finitestatemachines.finitestatemachineclassicmt.Variable;
import fr.inria.diverse.melange.lib.IFactory;

@SuppressWarnings("all")
public interface FiniteStateMachineClassicMTFactory extends IFactory {
  public abstract NamedElement createNamedElement();
  
  public abstract StateMachine createStateMachine();
  
  public abstract State createState();
  
  public abstract FinalState createFinalState();
  
  public abstract InitialState createInitialState();
  
  public abstract Transition createTransition();
  
  public abstract TimedTransition createTimedTransition();
  
  public abstract Trigger createTrigger();
  
  public abstract Pseudostate createPseudostate();
  
  public abstract Fork createFork();
  
  public abstract Join createJoin();
  
  public abstract CompositeState createCompositeState();
  
  public abstract Region createRegion();
  
  public abstract Action createAction();
  
  public abstract Variable createVariable();
  
  public abstract Choice createChoice();
  
  public abstract Guard createGuard();
}
