package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt;

import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.ActionAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.ChoiceAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.CompositeStateAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.FinalStateAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.ForkAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.GuardAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.InitialStateAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.JoinAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.NamedElementAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.PseudostateAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.RegionAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.StateAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.StateMachineAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.TimedTransitionAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.TransitionAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.TriggerAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.VariableAdapter;
import finitestatemachinescomposite.Action;
import finitestatemachinescomposite.Choice;
import finitestatemachinescomposite.CompositeState;
import finitestatemachinescomposite.FinalState;
import finitestatemachinescomposite.Fork;
import finitestatemachinescomposite.Guard;
import finitestatemachinescomposite.InitialState;
import finitestatemachinescomposite.Join;
import finitestatemachinescomposite.NamedElement;
import finitestatemachinescomposite.Pseudostate;
import finitestatemachinescomposite.Region;
import finitestatemachinescomposite.State;
import finitestatemachinescomposite.StateMachine;
import finitestatemachinescomposite.TimedTransition;
import finitestatemachinescomposite.Transition;
import finitestatemachinescomposite.Trigger;
import finitestatemachinescomposite.Variable;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public class FiniteStateMachineRhapsodyMTAdaptersFactory implements AdaptersFactory {
  private static FiniteStateMachineRhapsodyMTAdaptersFactory instance;
  
  public static FiniteStateMachineRhapsodyMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o) {
    if (o instanceof finitestatemachinescomposite.StateMachine)
    	return createStateMachineAdapter((finitestatemachinescomposite.StateMachine) o) ;
    if (o instanceof finitestatemachinescomposite.FinalState)
    	return createFinalStateAdapter((finitestatemachinescomposite.FinalState) o) ;
    if (o instanceof finitestatemachinescomposite.InitialState)
    	return createInitialStateAdapter((finitestatemachinescomposite.InitialState) o) ;
    if (o instanceof finitestatemachinescomposite.State)
    	return createStateAdapter((finitestatemachinescomposite.State) o) ;
    if (o instanceof finitestatemachinescomposite.TimedTransition)
    	return createTimedTransitionAdapter((finitestatemachinescomposite.TimedTransition) o) ;
    if (o instanceof finitestatemachinescomposite.Transition)
    	return createTransitionAdapter((finitestatemachinescomposite.Transition) o) ;
    if (o instanceof finitestatemachinescomposite.Fork)
    	return createForkAdapter((finitestatemachinescomposite.Fork) o) ;
    if (o instanceof finitestatemachinescomposite.Join)
    	return createJoinAdapter((finitestatemachinescomposite.Join) o) ;
    if (o instanceof finitestatemachinescomposite.Pseudostate)
    	return createPseudostateAdapter((finitestatemachinescomposite.Pseudostate) o) ;
    if (o instanceof finitestatemachinescomposite.NamedElement)
    	return createNamedElementAdapter((finitestatemachinescomposite.NamedElement) o) ;
    if (o instanceof finitestatemachinescomposite.Trigger)
    	return createTriggerAdapter((finitestatemachinescomposite.Trigger) o) ;
    if (o instanceof finitestatemachinescomposite.CompositeState)
    	return createCompositeStateAdapter((finitestatemachinescomposite.CompositeState) o) ;
    if (o instanceof finitestatemachinescomposite.Region)
    	return createRegionAdapter((finitestatemachinescomposite.Region) o) ;
    if (o instanceof finitestatemachinescomposite.Action)
    	return createActionAdapter((finitestatemachinescomposite.Action) o) ;
    if (o instanceof finitestatemachinescomposite.Variable)
    	return createVariableAdapter((finitestatemachinescomposite.Variable) o) ;
    if (o instanceof finitestatemachinescomposite.Choice)
    	return createChoiceAdapter((finitestatemachinescomposite.Choice) o) ;
    if (o instanceof finitestatemachinescomposite.Guard)
    	return createGuardAdapter((finitestatemachinescomposite.Guard) o) ;
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.NamedElementAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.NamedElementAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.StateMachineAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.StateMachineAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public StateAdapter createStateAdapter(final State adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.StateAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.StateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.FinalStateAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.FinalStateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.InitialStateAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.InitialStateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.TransitionAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.TransitionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.TimedTransitionAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.TimedTransitionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.TriggerAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.TriggerAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.PseudostateAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.PseudostateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.ForkAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.ForkAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.JoinAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.JoinAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public CompositeStateAdapter createCompositeStateAdapter(final CompositeState adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.CompositeStateAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.CompositeStateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public RegionAdapter createRegionAdapter(final Region adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.RegionAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.RegionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public ActionAdapter createActionAdapter(final Action adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.ActionAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.ActionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public VariableAdapter createVariableAdapter(final Variable adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.VariableAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.VariableAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public ChoiceAdapter createChoiceAdapter(final Choice adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.ChoiceAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.ChoiceAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public GuardAdapter createGuardAdapter(final Guard adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.GuardAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.GuardAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
}
