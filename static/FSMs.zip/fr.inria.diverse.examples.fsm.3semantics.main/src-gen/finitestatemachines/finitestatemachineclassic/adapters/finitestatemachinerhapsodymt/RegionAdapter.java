package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt;

import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory;
import finitestatemachines.finitestatemachinerhapsodymt.CompositeState;
import finitestatemachines.finitestatemachinerhapsodymt.State;
import finitestatemachinescomposite.Region;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class RegionAdapter extends EObjectAdapter<Region> implements finitestatemachines.finitestatemachinerhapsodymt.Region {
  private FiniteStateMachineRhapsodyMTAdaptersFactory adaptersFactory;
  
  public RegionAdapter() {
    super(finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public EList<State> getStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.StateAdapter.class) ;
  }
  
  @Override
  public CompositeState getParent() {
    return adaptersFactory.createCompositeStateAdapter(adaptee.getParent()) ;
  }
  
  @Override
  public void setParent(final CompositeState o) {
    adaptee.setParent(((finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.CompositeStateAdapter) o).getAdaptee()) ;
  }
}
