package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt;

import finitestatemachines.FiniteStateMachineRhapsodyMT;
import finitestatemachines.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;

@SuppressWarnings("all")
public class FiniteStateMachineClassicAdapter extends ResourceAdapter implements FiniteStateMachineRhapsodyMT {
  public FiniteStateMachineClassicAdapter() {
    super(finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FiniteStateMachineRhapsodyMTFactory getFactory() {
    return new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(org.eclipse.emf.common.util.URI.createURI(uri));
    this.adaptee.save(null);
  }
}
