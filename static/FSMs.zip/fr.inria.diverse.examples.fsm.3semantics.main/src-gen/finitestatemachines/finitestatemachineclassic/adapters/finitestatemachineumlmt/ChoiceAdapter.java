package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory;
import finitestatemachines.finitestatemachineumlmt.CompositeState;
import finitestatemachines.finitestatemachineumlmt.State;
import finitestatemachines.finitestatemachineumlmt.StateMachine;
import finitestatemachines.finitestatemachineumlmt.Transition;
import finitestatemachinescomposite.Choice;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class ChoiceAdapter extends EObjectAdapter<Choice> implements finitestatemachines.finitestatemachineumlmt.Choice {
  private FiniteStateMachineUMLMTAdaptersFactory adaptersFactory;
  
  public ChoiceAdapter() {
    super(finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public EList<Transition> getOutgoing() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getOutgoing(), finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<Transition> getIncoming() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getIncoming(), finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TransitionAdapter.class) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return adaptersFactory.createStateMachineAdapter(adaptee.getStateMachine()) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    adaptee.setStateMachine(((finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.StateMachineAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public CompositeState getParentState() {
    return adaptersFactory.createCompositeStateAdapter(adaptee.getParentState()) ;
  }
  
  @Override
  public void setParentState(final CompositeState o) {
    adaptee.setParentState(((finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.CompositeStateAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public void run(final Context context) {
    finitestatemachines.composite.classic.StateAspect.run(adaptee, context
    ) ;
  }
  
  @Override
  public EList<Transition> getActiveTransitions(final String event) {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.classic.StateAspect.getActiveTransitions(adaptee, event
    ), finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TransitionAdapter.class) ;
  }
  
  @Override
  public EList<State> getAllParents() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.classic.StateAspect.getAllParents(adaptee), finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.StateAdapter.class) ;
  }
  
  @Override
  public EList<State> getAllChildren() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(finitestatemachines.composite.classic.StateAspect.getAllChildren(adaptee), finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.StateAdapter.class) ;
  }
}
