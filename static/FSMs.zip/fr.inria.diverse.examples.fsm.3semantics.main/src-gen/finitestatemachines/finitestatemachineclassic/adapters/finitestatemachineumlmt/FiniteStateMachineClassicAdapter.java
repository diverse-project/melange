package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt;

import finitestatemachines.FiniteStateMachineUMLMT;
import finitestatemachines.finitestatemachineumlmt.FiniteStateMachineUMLMTFactory;
import fr.inria.diverse.melange.adapters.ResourceAdapter;
import java.io.IOException;

@SuppressWarnings("all")
public class FiniteStateMachineClassicAdapter extends ResourceAdapter implements FiniteStateMachineUMLMT {
  public FiniteStateMachineClassicAdapter() {
    super(finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public FiniteStateMachineUMLMTFactory getFactory() {
    return new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTFactoryAdapter() ;
  }
  
  @Override
  public void save(final String uri) throws IOException {
    this.adaptee.setURI(org.eclipse.emf.common.util.URI.createURI(uri));
    this.adaptee.save(null);
  }
}
