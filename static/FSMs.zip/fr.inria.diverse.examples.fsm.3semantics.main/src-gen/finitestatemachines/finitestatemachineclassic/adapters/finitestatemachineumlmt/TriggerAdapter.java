package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt;

import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory;
import finitestatemachinescomposite.Trigger;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class TriggerAdapter extends EObjectAdapter<Trigger> implements finitestatemachines.finitestatemachineumlmt.Trigger {
  private FiniteStateMachineUMLMTAdaptersFactory adaptersFactory;
  
  public TriggerAdapter() {
    super(finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
}
