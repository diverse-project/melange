package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt;

import FSM.interfaces.Context;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory;
import finitestatemachines.finitestatemachineumlmt.Action;
import finitestatemachines.finitestatemachineumlmt.Guard;
import finitestatemachines.finitestatemachineumlmt.State;
import finitestatemachines.finitestatemachineumlmt.StateMachine;
import finitestatemachines.finitestatemachineumlmt.Trigger;
import finitestatemachinescomposite.TimedTransition;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class TimedTransitionAdapter extends EObjectAdapter<TimedTransition> implements finitestatemachines.finitestatemachineumlmt.TimedTransition {
  private FiniteStateMachineUMLMTAdaptersFactory adaptersFactory;
  
  public TimedTransitionAdapter() {
    super(finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
  
  @Override
  public int getInitialTime() {
    return adaptee.getInitialTime() ;
  }
  
  @Override
  public void setInitialTime(final int o) {
    adaptee.setInitialTime(o) ;
  }
  
  @Override
  public int getFinalTime() {
    return adaptee.getFinalTime() ;
  }
  
  @Override
  public void setFinalTime(final int o) {
    adaptee.setFinalTime(o) ;
  }
  
  @Override
  public int getDuration() {
    return adaptee.getDuration() ;
  }
  
  @Override
  public void setDuration(final int o) {
    adaptee.setDuration(o) ;
  }
  
  @Override
  public State getTarget() {
    return adaptersFactory.createStateAdapter(adaptee.getTarget()) ;
  }
  
  @Override
  public void setTarget(final State o) {
    adaptee.setTarget(((finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.StateAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public State getSource() {
    return adaptersFactory.createStateAdapter(adaptee.getSource()) ;
  }
  
  @Override
  public void setSource(final State o) {
    adaptee.setSource(((finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.StateAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public Trigger getTrigger() {
    return adaptersFactory.createTriggerAdapter(adaptee.getTrigger()) ;
  }
  
  @Override
  public void setTrigger(final Trigger o) {
    adaptee.setTrigger(((finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TriggerAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public StateMachine getStateMachine() {
    return adaptersFactory.createStateMachineAdapter(adaptee.getStateMachine()) ;
  }
  
  @Override
  public void setStateMachine(final StateMachine o) {
    adaptee.setStateMachine(((finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.StateMachineAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public Guard getGuard() {
    return adaptersFactory.createGuardAdapter(adaptee.getGuard()) ;
  }
  
  @Override
  public void setGuard(final Guard o) {
    adaptee.setGuard(((finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.GuardAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public Action getAction() {
    return adaptersFactory.createActionAdapter(adaptee.getAction()) ;
  }
  
  @Override
  public void setAction(final Action o) {
    adaptee.setAction(((finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.ActionAdapter) o).getAdaptee()) ;
  }
  
  @Override
  public void fire(final Context context) {
    finitestatemachines.composite.classic.TransitionAspect.fire(adaptee, context
    ) ;
  }
}
