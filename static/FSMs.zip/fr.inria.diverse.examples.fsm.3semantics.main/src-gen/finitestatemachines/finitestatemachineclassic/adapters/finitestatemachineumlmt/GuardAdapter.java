package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt;

import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory;
import finitestatemachinescomposite.Guard;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class GuardAdapter extends EObjectAdapter<Guard> implements finitestatemachines.finitestatemachineumlmt.Guard {
  private FiniteStateMachineUMLMTAdaptersFactory adaptersFactory;
  
  public GuardAdapter() {
    super(finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
}
