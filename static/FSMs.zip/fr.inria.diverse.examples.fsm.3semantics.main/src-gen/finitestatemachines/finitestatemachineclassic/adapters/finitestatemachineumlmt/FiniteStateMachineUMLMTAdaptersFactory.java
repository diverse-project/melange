package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt;

import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.ActionAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.ChoiceAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.CompositeStateAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FinalStateAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.ForkAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.GuardAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.InitialStateAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.JoinAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.NamedElementAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.PseudostateAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.RegionAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.StateAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.StateMachineAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TimedTransitionAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TransitionAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TriggerAdapter;
import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.VariableAdapter;
import finitestatemachinescomposite.Action;
import finitestatemachinescomposite.Choice;
import finitestatemachinescomposite.CompositeState;
import finitestatemachinescomposite.FinalState;
import finitestatemachinescomposite.Fork;
import finitestatemachinescomposite.Guard;
import finitestatemachinescomposite.InitialState;
import finitestatemachinescomposite.Join;
import finitestatemachinescomposite.NamedElement;
import finitestatemachinescomposite.Pseudostate;
import finitestatemachinescomposite.Region;
import finitestatemachinescomposite.State;
import finitestatemachinescomposite.StateMachine;
import finitestatemachinescomposite.TimedTransition;
import finitestatemachinescomposite.Transition;
import finitestatemachinescomposite.Trigger;
import finitestatemachinescomposite.Variable;
import fr.inria.diverse.melange.adapters.AdaptersFactory;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public class FiniteStateMachineUMLMTAdaptersFactory implements AdaptersFactory {
  private static FiniteStateMachineUMLMTAdaptersFactory instance;
  
  public static FiniteStateMachineUMLMTAdaptersFactory getInstance() {
    if (instance == null) {
    	instance = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FiniteStateMachineUMLMTAdaptersFactory() ;
    }
    return instance ;
  }
  
  public EObjectAdapter createAdapter(final EObject o) {
    if (o instanceof finitestatemachinescomposite.StateMachine)
    	return createStateMachineAdapter((finitestatemachinescomposite.StateMachine) o) ;
    if (o instanceof finitestatemachinescomposite.FinalState)
    	return createFinalStateAdapter((finitestatemachinescomposite.FinalState) o) ;
    if (o instanceof finitestatemachinescomposite.InitialState)
    	return createInitialStateAdapter((finitestatemachinescomposite.InitialState) o) ;
    if (o instanceof finitestatemachinescomposite.State)
    	return createStateAdapter((finitestatemachinescomposite.State) o) ;
    if (o instanceof finitestatemachinescomposite.TimedTransition)
    	return createTimedTransitionAdapter((finitestatemachinescomposite.TimedTransition) o) ;
    if (o instanceof finitestatemachinescomposite.Transition)
    	return createTransitionAdapter((finitestatemachinescomposite.Transition) o) ;
    if (o instanceof finitestatemachinescomposite.Fork)
    	return createForkAdapter((finitestatemachinescomposite.Fork) o) ;
    if (o instanceof finitestatemachinescomposite.Join)
    	return createJoinAdapter((finitestatemachinescomposite.Join) o) ;
    if (o instanceof finitestatemachinescomposite.Pseudostate)
    	return createPseudostateAdapter((finitestatemachinescomposite.Pseudostate) o) ;
    if (o instanceof finitestatemachinescomposite.NamedElement)
    	return createNamedElementAdapter((finitestatemachinescomposite.NamedElement) o) ;
    if (o instanceof finitestatemachinescomposite.Trigger)
    	return createTriggerAdapter((finitestatemachinescomposite.Trigger) o) ;
    if (o instanceof finitestatemachinescomposite.CompositeState)
    	return createCompositeStateAdapter((finitestatemachinescomposite.CompositeState) o) ;
    if (o instanceof finitestatemachinescomposite.Region)
    	return createRegionAdapter((finitestatemachinescomposite.Region) o) ;
    if (o instanceof finitestatemachinescomposite.Action)
    	return createActionAdapter((finitestatemachinescomposite.Action) o) ;
    if (o instanceof finitestatemachinescomposite.Variable)
    	return createVariableAdapter((finitestatemachinescomposite.Variable) o) ;
    if (o instanceof finitestatemachinescomposite.Choice)
    	return createChoiceAdapter((finitestatemachinescomposite.Choice) o) ;
    if (o instanceof finitestatemachinescomposite.Guard)
    	return createGuardAdapter((finitestatemachinescomposite.Guard) o) ;
    return null ;
  }
  
  public NamedElementAdapter createNamedElementAdapter(final NamedElement adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.NamedElementAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.NamedElementAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public StateMachineAdapter createStateMachineAdapter(final StateMachine adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.StateMachineAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.StateMachineAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public StateAdapter createStateAdapter(final State adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.StateAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.StateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public FinalStateAdapter createFinalStateAdapter(final FinalState adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FinalStateAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.FinalStateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public InitialStateAdapter createInitialStateAdapter(final InitialState adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.InitialStateAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.InitialStateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public TransitionAdapter createTransitionAdapter(final Transition adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TransitionAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TransitionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public TimedTransitionAdapter createTimedTransitionAdapter(final TimedTransition adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TimedTransitionAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TimedTransitionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public TriggerAdapter createTriggerAdapter(final Trigger adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TriggerAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.TriggerAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public PseudostateAdapter createPseudostateAdapter(final Pseudostate adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.PseudostateAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.PseudostateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public ForkAdapter createForkAdapter(final Fork adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.ForkAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.ForkAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public JoinAdapter createJoinAdapter(final Join adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.JoinAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.JoinAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public CompositeStateAdapter createCompositeStateAdapter(final CompositeState adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.CompositeStateAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.CompositeStateAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public RegionAdapter createRegionAdapter(final Region adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.RegionAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.RegionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public ActionAdapter createActionAdapter(final Action adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.ActionAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.ActionAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public VariableAdapter createVariableAdapter(final Variable adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.VariableAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.VariableAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public ChoiceAdapter createChoiceAdapter(final Choice adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.ChoiceAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.ChoiceAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
  
  public GuardAdapter createGuardAdapter(final Guard adaptee) {
    finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.GuardAdapter adap = new finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineumlmt.GuardAdapter() ;
    adap.setAdaptee(adaptee) ;
    return adap ;
  }
}
