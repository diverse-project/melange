package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachines.finitestatemachineclassicmt.Action;
import finitestatemachines.finitestatemachineclassicmt.Choice;
import finitestatemachines.finitestatemachineclassicmt.CompositeState;
import finitestatemachines.finitestatemachineclassicmt.FinalState;
import finitestatemachines.finitestatemachineclassicmt.FiniteStateMachineClassicMTFactory;
import finitestatemachines.finitestatemachineclassicmt.Fork;
import finitestatemachines.finitestatemachineclassicmt.Guard;
import finitestatemachines.finitestatemachineclassicmt.InitialState;
import finitestatemachines.finitestatemachineclassicmt.Join;
import finitestatemachines.finitestatemachineclassicmt.NamedElement;
import finitestatemachines.finitestatemachineclassicmt.Pseudostate;
import finitestatemachines.finitestatemachineclassicmt.Region;
import finitestatemachines.finitestatemachineclassicmt.State;
import finitestatemachines.finitestatemachineclassicmt.StateMachine;
import finitestatemachines.finitestatemachineclassicmt.TimedTransition;
import finitestatemachines.finitestatemachineclassicmt.Transition;
import finitestatemachines.finitestatemachineclassicmt.Trigger;
import finitestatemachines.finitestatemachineclassicmt.Variable;
import finitestatemachinescomposite.FinitestatemachinescompositeFactory;

@SuppressWarnings("all")
public class FiniteStateMachineClassicMTFactoryAdapter implements FiniteStateMachineClassicMTFactory {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory = finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance();
  
  private FinitestatemachinescompositeFactory finitestatemachinescompositeAdaptee = finitestatemachinescomposite.FinitestatemachinescompositeFactory.eINSTANCE;
  
  @Override
  public NamedElement createNamedElement() {
    return adaptersFactory.createNamedElementAdapter(finitestatemachinescompositeAdaptee.createNamedElement()) ;
  }
  
  @Override
  public StateMachine createStateMachine() {
    return adaptersFactory.createStateMachineAdapter(finitestatemachinescompositeAdaptee.createStateMachine()) ;
  }
  
  @Override
  public State createState() {
    return adaptersFactory.createStateAdapter(finitestatemachinescompositeAdaptee.createState()) ;
  }
  
  @Override
  public FinalState createFinalState() {
    return adaptersFactory.createFinalStateAdapter(finitestatemachinescompositeAdaptee.createFinalState()) ;
  }
  
  @Override
  public InitialState createInitialState() {
    return adaptersFactory.createInitialStateAdapter(finitestatemachinescompositeAdaptee.createInitialState()) ;
  }
  
  @Override
  public Transition createTransition() {
    return adaptersFactory.createTransitionAdapter(finitestatemachinescompositeAdaptee.createTransition()) ;
  }
  
  @Override
  public TimedTransition createTimedTransition() {
    return adaptersFactory.createTimedTransitionAdapter(finitestatemachinescompositeAdaptee.createTimedTransition()) ;
  }
  
  @Override
  public Trigger createTrigger() {
    return adaptersFactory.createTriggerAdapter(finitestatemachinescompositeAdaptee.createTrigger()) ;
  }
  
  @Override
  public Pseudostate createPseudostate() {
    return adaptersFactory.createPseudostateAdapter(finitestatemachinescompositeAdaptee.createPseudostate()) ;
  }
  
  @Override
  public Fork createFork() {
    return adaptersFactory.createForkAdapter(finitestatemachinescompositeAdaptee.createFork()) ;
  }
  
  @Override
  public Join createJoin() {
    return adaptersFactory.createJoinAdapter(finitestatemachinescompositeAdaptee.createJoin()) ;
  }
  
  @Override
  public CompositeState createCompositeState() {
    return adaptersFactory.createCompositeStateAdapter(finitestatemachinescompositeAdaptee.createCompositeState()) ;
  }
  
  @Override
  public Region createRegion() {
    return adaptersFactory.createRegionAdapter(finitestatemachinescompositeAdaptee.createRegion()) ;
  }
  
  @Override
  public Action createAction() {
    return adaptersFactory.createActionAdapter(finitestatemachinescompositeAdaptee.createAction()) ;
  }
  
  @Override
  public Variable createVariable() {
    return adaptersFactory.createVariableAdapter(finitestatemachinescompositeAdaptee.createVariable()) ;
  }
  
  @Override
  public Choice createChoice() {
    return adaptersFactory.createChoiceAdapter(finitestatemachinescompositeAdaptee.createChoice()) ;
  }
  
  @Override
  public Guard createGuard() {
    return adaptersFactory.createGuardAdapter(finitestatemachinescompositeAdaptee.createGuard()) ;
  }
}
