package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachines.finitestatemachineclassicmt.CompositeState;
import finitestatemachines.finitestatemachineclassicmt.State;
import finitestatemachinescomposite.Region;
import fr.inria.diverse.melange.adapters.EObjectAdapter;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class RegionAdapter extends EObjectAdapter<Region> implements finitestatemachines.finitestatemachineclassicmt.Region {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory;
  
  public RegionAdapter() {
    super(finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public EList<State> getStates() {
    return fr.inria.diverse.melange.adapters.EListAdapter.newInstance(adaptee.getStates(), finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.StateAdapter.class) ;
  }
  
  @Override
  public CompositeState getParent() {
    return adaptersFactory.createCompositeStateAdapter(adaptee.getParent()) ;
  }
  
  @Override
  public void setParent(final CompositeState o) {
    adaptee.setParent(((finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.CompositeStateAdapter) o).getAdaptee()) ;
  }
}
