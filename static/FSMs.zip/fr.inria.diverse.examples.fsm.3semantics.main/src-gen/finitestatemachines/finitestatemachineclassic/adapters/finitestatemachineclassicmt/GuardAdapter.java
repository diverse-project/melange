package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachinescomposite.Guard;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class GuardAdapter extends EObjectAdapter<Guard> implements finitestatemachines.finitestatemachineclassicmt.Guard {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory;
  
  public GuardAdapter() {
    super(finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getExpression() {
    return adaptee.getExpression() ;
  }
  
  @Override
  public void setExpression(final String o) {
    adaptee.setExpression(o) ;
  }
}
