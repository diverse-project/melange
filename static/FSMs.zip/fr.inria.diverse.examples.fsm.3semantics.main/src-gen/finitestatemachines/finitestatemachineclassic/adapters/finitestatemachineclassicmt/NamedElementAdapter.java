package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachinescomposite.NamedElement;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class NamedElementAdapter extends EObjectAdapter<NamedElement> implements finitestatemachines.finitestatemachineclassicmt.NamedElement {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory;
  
  public NamedElementAdapter() {
    super(finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getName() {
    return adaptee.getName() ;
  }
  
  @Override
  public void setName(final String o) {
    adaptee.setName(o) ;
  }
}
