package finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt;

import finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory;
import finitestatemachinescomposite.Action;
import fr.inria.diverse.melange.adapters.EObjectAdapter;

@SuppressWarnings("all")
public class ActionAdapter extends EObjectAdapter<Action> implements finitestatemachines.finitestatemachineclassicmt.Action {
  private FiniteStateMachineClassicMTAdaptersFactory adaptersFactory;
  
  public ActionAdapter() {
    super(finitestatemachines.finitestatemachineclassic.adapters.finitestatemachineclassicmt.FiniteStateMachineClassicMTAdaptersFactory.getInstance()) ;
  }
  
  @Override
  public String getVariable() {
    return adaptee.getVariable() ;
  }
  
  @Override
  public void setVariable(final String o) {
    adaptee.setVariable(o) ;
  }
  
  @Override
  public boolean isValue() {
    return adaptee.isValue() ;
  }
  
  @Override
  public void setValue(final boolean o) {
    adaptee.setValue(o) ;
  }
}
