package finitestatemachines.finitestatemachineumlmt;

import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface Variable extends EObject {
  public String getName();
  
  public void setName(final String newName);
  
  public boolean isValue();
  
  public void setValue(final boolean newValue);
}
