package finitestatemachines.finitestatemachineumlmt;

import finitestatemachines.finitestatemachineumlmt.Action;
import finitestatemachines.finitestatemachineumlmt.Choice;
import finitestatemachines.finitestatemachineumlmt.CompositeState;
import finitestatemachines.finitestatemachineumlmt.FinalState;
import finitestatemachines.finitestatemachineumlmt.Fork;
import finitestatemachines.finitestatemachineumlmt.Guard;
import finitestatemachines.finitestatemachineumlmt.InitialState;
import finitestatemachines.finitestatemachineumlmt.Join;
import finitestatemachines.finitestatemachineumlmt.NamedElement;
import finitestatemachines.finitestatemachineumlmt.Pseudostate;
import finitestatemachines.finitestatemachineumlmt.Region;
import finitestatemachines.finitestatemachineumlmt.State;
import finitestatemachines.finitestatemachineumlmt.StateMachine;
import finitestatemachines.finitestatemachineumlmt.TimedTransition;
import finitestatemachines.finitestatemachineumlmt.Transition;
import finitestatemachines.finitestatemachineumlmt.Trigger;
import finitestatemachines.finitestatemachineumlmt.Variable;
import fr.inria.diverse.melange.lib.IFactory;

@SuppressWarnings("all")
public interface FiniteStateMachineUMLMTFactory extends IFactory {
  public abstract NamedElement createNamedElement();
  
  public abstract StateMachine createStateMachine();
  
  public abstract State createState();
  
  public abstract FinalState createFinalState();
  
  public abstract InitialState createInitialState();
  
  public abstract Transition createTransition();
  
  public abstract TimedTransition createTimedTransition();
  
  public abstract Trigger createTrigger();
  
  public abstract Pseudostate createPseudostate();
  
  public abstract Fork createFork();
  
  public abstract Join createJoin();
  
  public abstract CompositeState createCompositeState();
  
  public abstract Region createRegion();
  
  public abstract Action createAction();
  
  public abstract Variable createVariable();
  
  public abstract Choice createChoice();
  
  public abstract Guard createGuard();
}
