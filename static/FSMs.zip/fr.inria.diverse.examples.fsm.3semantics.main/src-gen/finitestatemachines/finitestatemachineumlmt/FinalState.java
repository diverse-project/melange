package finitestatemachines.finitestatemachineumlmt;

import finitestatemachines.finitestatemachineumlmt.State;
import org.eclipse.emf.ecore.EObject;

@SuppressWarnings("all")
public interface FinalState extends EObject, State {
}
