package finitestatemachines;

import finitestatemachines.FiniteStateMachineClassicMT;
import finitestatemachines.FiniteStateMachineRhapsodyMT;
import finitestatemachines.FiniteStateMachineUMLMT;
import fr.inria.diverse.melange.lib.IMetamodel;
import org.eclipse.emf.ecore.resource.Resource;

@SuppressWarnings("all")
public class FiniteStateMachineRhapsody implements IMetamodel {
  private Resource resource;
  
  public Resource getResource() {
    return this.resource;
  }
  
  public void setResource(final Resource resource) {
    this.resource = resource;
  }
  
  public static FiniteStateMachineRhapsody load(final String uri) {
    org.eclipse.emf.ecore.resource.ResourceSet rs = new org.eclipse.emf.ecore.resource.impl.ResourceSetImpl() ;
    Resource res = rs.getResource(org.eclipse.emf.common.util.URI.createURI(uri), true) ;
    FiniteStateMachineRhapsody mm = new FiniteStateMachineRhapsody() ;
    mm.setResource(res) ;
    return mm ;
  }
  
  public FiniteStateMachineUMLMT toFiniteStateMachineUMLMT() {
    finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.FiniteStateMachineRhapsodyAdapter adaptee = new finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineumlmt.FiniteStateMachineRhapsodyAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineRhapsodyMT toFiniteStateMachineRhapsodyMT() {
    finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyAdapter adaptee = new finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachinerhapsodymt.FiniteStateMachineRhapsodyAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
  
  public FiniteStateMachineClassicMT toFiniteStateMachineClassicMT() {
    finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineRhapsodyAdapter adaptee = new finitestatemachines.finitestatemachinerhapsody.adapters.finitestatemachineclassicmt.FiniteStateMachineRhapsodyAdapter() ;
    adaptee.setAdaptee(resource) ;
    return adaptee ;
  }
}
