package finitestatemachines.rtc;

@SuppressWarnings("all")
public class StateAspectStateAspectProperties {
}
