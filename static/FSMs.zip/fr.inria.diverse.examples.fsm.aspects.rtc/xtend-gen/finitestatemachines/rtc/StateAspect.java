package finitestatemachines.rtc;

import FSM.interfaces.Context;
import finitestatemachines.State;
import finitestatemachines.rtc.StateAspectStateAspectProperties;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;

@Aspect(className = State.class)
@SuppressWarnings("all")
public class StateAspect {
  public static void eval(final State _self, final Context context) {
    finitestatemachines.rtc.StateAspectStateAspectProperties _self_ = finitestatemachines.rtc.StateAspectStateAspectContext.getSelf(_self);
    _privk3_eval(_self_, _self,context);
  }
  
  protected static void _privk3_eval(final StateAspectStateAspectProperties _self_, final State _self, final Context context) {
    long _currentTimeMillis = System.currentTimeMillis();
    _self.setInitialTime(((int) _currentTimeMillis));
    Context.stateWorking(1000);
    long _currentTimeMillis_1 = System.currentTimeMillis();
    _self.setFinalTime(((int) _currentTimeMillis_1));
  }
}
