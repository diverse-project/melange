package finitestatemachines.rtc;

import FSM.interfaces.Context;
import finitestatemachines.Fork;
import finitestatemachines.InitialState;
import finitestatemachines.Join;
import finitestatemachines.State;
import finitestatemachines.StateMachine;
import finitestatemachines.Transition;
import finitestatemachines.Trigger;
import finitestatemachines.rtc.ForkThread;
import finitestatemachines.rtc.Printer;
import finitestatemachines.rtc.StateAspect;
import finitestatemachines.rtc.StateMachineAspectStateMachineAspectProperties;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import java.util.ArrayList;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.InputOutput;

/**
 * StateMachineAspect: Aspects for the State Machine meta-class
 * Serves as the interpreter of the state machine (the controller of the )
 */
@Aspect(className = StateMachine.class)
@SuppressWarnings("all")
public class StateMachineAspect {
  /**
   * Evaluates the input and sequentially executes the steps in the state machine.
   */
  public static void eval(final StateMachine _self, final Context context, final String filePath) {
    finitestatemachines.rtc.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.rtc.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_eval(_self_, _self,context,filePath);
  }
  
  /**
   * Performs a step in the state machine i.e., reads an entry of the input stack and executes it.
   * If there are several events in the same step they are executed sequentially.
   */
  private static void step(final StateMachine _self, final Context context, final EList<String> eventsGroup) {
    finitestatemachines.rtc.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.rtc.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_step(_self_, _self,context,eventsGroup);
  }
  
  /**
   * Processes the current active transitions by activating their target states
   * and executing the steps on the states (should the evaluation of the states be called from here?).
   */
  private static void processTransitions(final StateMachine _self, final Context context) {
    finitestatemachines.rtc.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.rtc.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_processTransitions(_self_, _self,context);
  }
  
  /**
   * Returns the (unique?) initial state of the state machine.
   */
  private static EList<State> getInitialState(final StateMachine _self) {
    finitestatemachines.rtc.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.rtc.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_getInitialState(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachines.State>)result;
  }
  
  private static EList<State> currentState(final StateMachine _self) {
    finitestatemachines.rtc.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.rtc.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_currentState(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachines.State>)result;
  }
  
  private static void currentState(final StateMachine _self, final EList<State> currentState) {
    finitestatemachines.rtc.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.rtc.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_currentState(_self_, _self,currentState);
  }
  
  private static EList<Transition> currentTransitions(final StateMachine _self) {
    finitestatemachines.rtc.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.rtc.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_currentTransitions(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachines.Transition>)result;
  }
  
  private static void currentTransitions(final StateMachine _self, final EList<Transition> currentTransitions) {
    finitestatemachines.rtc.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.rtc.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_currentTransitions(_self_, _self,currentTransitions);
  }
  
  protected static void _privk3_eval(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final Context context, final String filePath) {
    InputOutput.<String>println("\nExecuting the state machine. Please wait for the results...\n");
    InputOutput.<String>println(" ... executing input ...\n");
    ArrayList<EList<String>> events = context.events;
    EList<State> _initialState = StateMachineAspect.getInitialState(_self);
    StateMachineAspect.currentState(_self, _initialState);
    EList<State> _currentState = StateMachineAspect.currentState(_self);
    State _get = _currentState.get(0);
    StateAspect.eval(_get, context);
    for (final EList<String> eventsGroup : events) {
      {
        InputOutput.<String>println(((("  input item: " + eventsGroup) + " time: ") + Integer.valueOf(((int) System.currentTimeMillis()))));
        StateMachineAspect.step(_self, context, eventsGroup);
      }
    }
    InputOutput.<String>println("\n *.* Your results are ready! \n");
    Printer _printer = new Printer();
    _printer.printFinalStateInConsole(_self);
    Printer _printer_1 = new Printer();
    _printer_1.printFinalStateInFile(_self, filePath);
  }
  
  protected static void _privk3_step(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final Context context, final EList<String> eventsGroup) {
    BasicEList<Transition> _basicEList = new BasicEList<Transition>();
    StateMachineAspect.currentTransitions(_self, _basicEList);
    ArrayList<State> attendedStates = new ArrayList<State>();
    for (final String event : eventsGroup) {
      {
        EList<State> _currentState = StateMachineAspect.currentState(_self);
        for (final State _state : _currentState) {
          EList<Transition> _outgoing = _state.getOutgoing();
          for (final Transition transition : _outgoing) {
            Trigger _trigger = transition.getTrigger();
            String _expression = _trigger.getExpression();
            boolean _equals = _expression.equals(event);
            if (_equals) {
              attendedStates.add(_state);
              EList<Transition> _currentTransitions = StateMachineAspect.currentTransitions(_self);
              _currentTransitions.add(transition);
            }
          }
        }
        EList<State> _currentState_1 = StateMachineAspect.currentState(_self);
        _currentState_1.removeAll(attendedStates);
      }
    }
    StateMachineAspect.processTransitions(_self, context);
  }
  
  protected static void _privk3_processTransitions(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final Context context) {
    EList<Transition> _currentTransitions = StateMachineAspect.currentTransitions(_self);
    for (final Transition _transition : _currentTransitions) {
      State _target = _transition.getTarget();
      if ((_target instanceof Fork)) {
        ArrayList<ForkThread> threads = new ArrayList<ForkThread>();
        State _target_1 = _transition.getTarget();
        EList<Transition> _outgoing = _target_1.getOutgoing();
        for (final Transition _forkTransition : _outgoing) {
          {
            EList<State> _currentState = StateMachineAspect.currentState(_self);
            State _target_2 = _forkTransition.getTarget();
            _currentState.add(_target_2);
            State _target_3 = _forkTransition.getTarget();
            ForkThread _forkThread = new ForkThread(_target_3, context);
            threads.add(_forkThread);
            _forkThread.start();
          }
        }
        boolean threadsAlive = true;
        while (threadsAlive) {
          {
            int stillAlive = 0;
            for (final Thread _thread : threads) {
              boolean _isAlive = _thread.isAlive();
              if (_isAlive) {
                stillAlive++;
              }
            }
            if ((stillAlive == 0)) {
              threadsAlive = false;
            }
          }
        }
      } else {
        EList<State> _currentState = StateMachineAspect.currentState(_self);
        State _target_2 = _transition.getTarget();
        _currentState.add(_target_2);
        State _target_3 = _transition.getTarget();
        StateAspect.eval(_target_3, context);
      }
    }
    ArrayList<State> toAdd = new ArrayList<State>();
    ArrayList<State> toRemove = new ArrayList<State>();
    EList<State> _currentState_1 = StateMachineAspect.currentState(_self);
    for (final State _state : _currentState_1) {
      boolean _and = false;
      EList<Transition> _outgoing_1 = _state.getOutgoing();
      int _size = _outgoing_1.size();
      boolean _greaterThan = (_size > 0);
      if (!_greaterThan) {
        _and = false;
      } else {
        EList<Transition> _outgoing_2 = _state.getOutgoing();
        Transition _get = _outgoing_2.get(0);
        State _target_4 = _get.getTarget();
        _and = (_target_4 instanceof Join);
      }
      if (_and) {
        boolean _and_1 = false;
        EList<Transition> _outgoing_3 = _state.getOutgoing();
        Transition _get_1 = _outgoing_3.get(0);
        State _target_5 = _get_1.getTarget();
        boolean _contains = toAdd.contains(_target_5);
        boolean _not = (!_contains);
        if (!_not) {
          _and_1 = false;
        } else {
          EList<State> _currentState_2 = StateMachineAspect.currentState(_self);
          EList<Transition> _outgoing_4 = _state.getOutgoing();
          Transition _get_2 = _outgoing_4.get(0);
          State _target_6 = _get_2.getTarget();
          boolean _contains_1 = _currentState_2.contains(_target_6);
          boolean _not_1 = (!_contains_1);
          _and_1 = _not_1;
        }
        if (_and_1) {
          EList<Transition> _outgoing_5 = _state.getOutgoing();
          Transition _get_3 = _outgoing_5.get(0);
          State _target_7 = _get_3.getTarget();
          toAdd.add(_target_7);
        }
        boolean _contains_2 = toRemove.contains(_state);
        boolean _not_2 = (!_contains_2);
        if (_not_2) {
          toRemove.add(_state);
        }
      }
    }
    EList<State> _currentState_3 = StateMachineAspect.currentState(_self);
    _currentState_3.removeAll(toRemove);
    EList<State> _currentState_4 = StateMachineAspect.currentState(_self);
    _currentState_4.addAll(toAdd);
  }
  
  protected static EList<State> _privk3_getInitialState(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self) {
    BasicEList<State> answer = new BasicEList<State>();
    EList<State> _states = _self.getStates();
    for (final State state : _states) {
      if ((state instanceof InitialState)) {
        answer.add(state);
      }
    }
    return answer;
  }
  
  protected static EList<State> _privk3_currentState(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self) {
     return _self_.currentState; 
  }
  
  protected static void _privk3_currentState(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final EList<State> currentState) {
    _self_.currentState = currentState; try {
    
    			for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    				if (m.getName().equals("set" + "CurrentState")
    						&& m.getParameterTypes().length == 1) {
    					m.invoke(_self, currentState);
    
    				}
    			}
    		} catch (Exception e) {
    			// Chut !
    		} 
  }
  
  protected static EList<Transition> _privk3_currentTransitions(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self) {
     return _self_.currentTransitions; 
  }
  
  protected static void _privk3_currentTransitions(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final EList<Transition> currentTransitions) {
    _self_.currentTransitions = currentTransitions; try {
    
    			for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    				if (m.getName().equals("set" + "CurrentTransitions")
    						&& m.getParameterTypes().length == 1) {
    					m.invoke(_self, currentTransitions);
    
    				}
    			}
    		} catch (Exception e) {
    			// Chut !
    		} 
  }
}
