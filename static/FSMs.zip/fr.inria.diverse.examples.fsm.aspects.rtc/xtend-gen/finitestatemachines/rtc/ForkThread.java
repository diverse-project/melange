package finitestatemachines.rtc;

import FSM.interfaces.Context;
import finitestatemachines.rtc.StateAspect;

@SuppressWarnings("all")
public class ForkThread extends Thread {
  private finitestatemachines.State state;
  
  private Context context;
  
  public ForkThread(final finitestatemachines.State _state, final Context _context) {
    this.state = _state;
    this.context = _context;
  }
  
  public void run() {
    StateAspect.eval(this.state, this.context);
  }
}
