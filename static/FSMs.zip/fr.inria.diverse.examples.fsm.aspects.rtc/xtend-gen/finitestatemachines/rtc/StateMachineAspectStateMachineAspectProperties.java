package finitestatemachines.rtc;

import finitestatemachines.State;
import finitestatemachines.Transition;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class StateMachineAspectStateMachineAspectProperties {
  public EList<State> currentState = null;
  
  public EList<Transition> currentTransitions = null;
}
