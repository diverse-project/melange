package finitestatemachines.composite.rhapsody;

@SuppressWarnings("all")
public class StateAspectStateAspectProperties {
}
