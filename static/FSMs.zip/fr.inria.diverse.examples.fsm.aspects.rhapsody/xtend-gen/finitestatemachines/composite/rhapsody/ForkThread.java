package finitestatemachines.composite.rhapsody;

import FSM.interfaces.Context;
import finitestatemachines.composite.rhapsody.StateAspect;

@SuppressWarnings("all")
public class ForkThread extends Thread {
  private finitestatemachinescomposite.State state;
  
  private Context context;
  
  public ForkThread(final finitestatemachinescomposite.State _state, final Context _context) {
    this.state = _state;
    this.context = _context;
  }
  
  public void run() {
    StateAspect.eval(this.state, this.context);
  }
}
