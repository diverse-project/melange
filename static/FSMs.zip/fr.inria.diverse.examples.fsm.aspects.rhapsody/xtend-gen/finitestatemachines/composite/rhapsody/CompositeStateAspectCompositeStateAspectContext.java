package finitestatemachines.composite.rhapsody;

import finitestatemachines.composite.rhapsody.CompositeStateAspectCompositeStateAspectProperties;
import finitestatemachinescomposite.CompositeState;
import java.util.Map;

@SuppressWarnings("all")
public class CompositeStateAspectCompositeStateAspectContext {
  public final static CompositeStateAspectCompositeStateAspectContext INSTANCE = new CompositeStateAspectCompositeStateAspectContext();
  
  public static CompositeStateAspectCompositeStateAspectProperties getSelf(final CompositeState _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new finitestatemachines.composite.rhapsody.CompositeStateAspectCompositeStateAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<CompositeState, CompositeStateAspectCompositeStateAspectProperties> map = new java.util.WeakHashMap<finitestatemachinescomposite.CompositeState, finitestatemachines.composite.rhapsody.CompositeStateAspectCompositeStateAspectProperties>();
  
  public Map<CompositeState, CompositeStateAspectCompositeStateAspectProperties> getMap() {
    return map;
  }
}
