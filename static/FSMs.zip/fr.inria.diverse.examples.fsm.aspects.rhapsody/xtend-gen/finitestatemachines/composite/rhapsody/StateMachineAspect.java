package finitestatemachines.composite.rhapsody;

import FSM.interfaces.Context;
import com.google.common.base.Objects;
import finitestatemachines.composite.rhapsody.Printer;
import finitestatemachines.composite.rhapsody.StateAspect;
import finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties;
import finitestatemachines.composite.rhapsody.TransitionAspect;
import finitestatemachinescomposite.Action;
import finitestatemachinescomposite.FinitestatemachinescompositeFactory;
import finitestatemachinescomposite.InitialState;
import finitestatemachinescomposite.State;
import finitestatemachinescomposite.StateMachine;
import finitestatemachinescomposite.Transition;
import finitestatemachinescomposite.Variable;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

/**
 * StateMachineAspect: Aspects for the State Machine meta-class
 * Serves as the interpreter of the state machine (the controller of the )
 */
@Aspect(className = StateMachine.class)
@SuppressWarnings("all")
public class StateMachineAspect {
  /**
   * Evaluates the input and sequentially executes the steps in the state machine.
   */
  public static void eval(final StateMachine _self, final Context context, final String filePath) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_eval(_self_, _self,context,filePath);
  }
  
  /**
   * Performs a step in the state machine i.e., reads an entry of the input stack and executes it.
   * If there are several events in the same step they are executed sequentially.
   */
  private static void step(final StateMachine _self, final Context context, final EList<String> eventsGroup) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_step(_self_, _self,context,eventsGroup);
  }
  
  public static EList<State> getAllCurrentStates(final StateMachine _self) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_getAllCurrentStates(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.State>)result;
  }
  
  /**
   * Get all states concerned by this event and remove those contained
   */
  private static EList<State> getHigherCurrent(final StateMachine _self, final String event) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_getHigherCurrent(_self_, _self,event);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.State>)result;
  }
  
  /**
   * Get all the deepest states concerned by this event
   */
  private static EList<State> getDeepestCurrent(final StateMachine _self, final String event) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_getDeepestCurrent(_self_, _self,event);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.State>)result;
  }
  
  /**
   * Returns the (unique?) initial state of the state machine.
   */
  private static EList<State> getInitialState(final StateMachine _self) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_getInitialState(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.State>)result;
  }
  
  /**
   * Intended format for @expression:
   * <String>=<true|false>
   */
  public static boolean isValid(final StateMachine _self, final String expression) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_isValid(_self_, _self,expression);
    return (boolean)result;
  }
  
  /**
   * Creates or update a variable
   */
  public static void update(final StateMachine _self, final Action action) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_update(_self_, _self,action);
  }
  
  public static void addCurrentState(final StateMachine _self, final State s) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_addCurrentState(_self_, _self,s);
  }
  
  public static void removeCurrentState(final StateMachine _self, final State s) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_removeCurrentState(_self_, _self,s);
  }
  
  public static boolean isCurrentState(final StateMachine _self, final State s) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_isCurrentState(_self_, _self,s);
    return (boolean)result;
  }
  
  private static EList<State> currentState(final StateMachine _self) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_currentState(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.State>)result;
  }
  
  private static void currentState(final StateMachine _self, final EList<State> currentState) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_currentState(_self_, _self,currentState);
  }
  
  private static EList<Transition> currentTransitions(final StateMachine _self) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_currentTransitions(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.Transition>)result;
  }
  
  private static void currentTransitions(final StateMachine _self, final EList<Transition> currentTransitions) {
    finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.rhapsody.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_currentTransitions(_self_, _self,currentTransitions);
  }
  
  protected static void _privk3_eval(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final Context context, final String filePath) {
    InputOutput.<String>println("\nExecuting the state machine. Please wait for the results...\n");
    InputOutput.<String>println(" ... executing input ...\n");
    ArrayList<EList<String>> events = context.events;
    EList<State> _initialState = StateMachineAspect.getInitialState(_self);
    StateMachineAspect.currentState(_self, _initialState);
    EList<State> _currentState = StateMachineAspect.currentState(_self);
    State _get = _currentState.get(0);
    StateAspect.eval(_get, context);
    for (final EList<String> eventsGroup : events) {
      {
        InputOutput.<String>println(((("  input item: " + eventsGroup) + " time: ") + Integer.valueOf(((int) System.currentTimeMillis()))));
        StateMachineAspect.step(_self, context, eventsGroup);
      }
    }
    InputOutput.<String>println("\n *.* Your results are ready! \n");
    Printer _printer = new Printer();
    _printer.printFinalStateInConsole(_self);
    Printer _printer_1 = new Printer();
    _printer_1.printFinalStateInFile(_self, filePath);
  }
  
  protected static void _privk3_step(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final Context context, final EList<String> eventsGroup) {
    BasicEList<Transition> _basicEList = new BasicEList<Transition>();
    StateMachineAspect.currentTransitions(_self, _basicEList);
    for (final String event : eventsGroup) {
      EList<State> _deepestCurrent = StateMachineAspect.getDeepestCurrent(_self, event);
      for (final State state : _deepestCurrent) {
        EList<Transition> _activeTransitions = StateAspect.getActiveTransitions(state, event);
        final Procedure1<Transition> _function = new Procedure1<Transition>() {
          public void apply(final Transition it) {
            TransitionAspect.fire(it, context);
          }
        };
        IterableExtensions.<Transition>forEach(_activeTransitions, _function);
      }
    }
  }
  
  protected static EList<State> _privk3_getAllCurrentStates(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self) {
    return StateMachineAspect.currentState(_self);
  }
  
  protected static EList<State> _privk3_getHigherCurrent(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final String event) {
    final BasicEList<State> res = new BasicEList<State>();
    final List<State> candidates = new ArrayList<State>();
    EList<State> _currentState = StateMachineAspect.currentState(_self);
    for (final State state : _currentState) {
      EList<Transition> _activeTransitions = StateAspect.getActiveTransitions(state, event);
      boolean _isEmpty = _activeTransitions.isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        candidates.add(state);
      }
    }
    final Procedure1<State> _function = new Procedure1<State>() {
      public void apply(final State state) {
        final EList<State> parents = StateAspect.getAllParents(state);
        final Function1<State, Boolean> _function = new Function1<State, Boolean>() {
          public Boolean apply(final State c) {
            return Boolean.valueOf(parents.contains(c));
          }
        };
        boolean _exists = IterableExtensions.<State>exists(candidates, _function);
        boolean _not = (!_exists);
        if (_not) {
          res.add(state);
        }
      }
    };
    IterableExtensions.<State>forEach(candidates, _function);
    return res;
  }
  
  protected static EList<State> _privk3_getDeepestCurrent(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final String event) {
    final BasicEList<State> res = new BasicEList<State>();
    final List<State> candidates = new ArrayList<State>();
    EList<State> _currentState = StateMachineAspect.currentState(_self);
    for (final State state : _currentState) {
      EList<Transition> _activeTransitions = StateAspect.getActiveTransitions(state, event);
      boolean _isEmpty = _activeTransitions.isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        candidates.add(state);
      }
    }
    final Procedure1<State> _function = new Procedure1<State>() {
      public void apply(final State state) {
        final EList<State> children = StateAspect.getAllChildren(state);
        final Function1<State, Boolean> _function = new Function1<State, Boolean>() {
          public Boolean apply(final State c) {
            return Boolean.valueOf(children.contains(c));
          }
        };
        boolean _exists = IterableExtensions.<State>exists(candidates, _function);
        boolean _not = (!_exists);
        if (_not) {
          res.add(state);
        }
      }
    };
    IterableExtensions.<State>forEach(candidates, _function);
    return res;
  }
  
  protected static EList<State> _privk3_getInitialState(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self) {
    BasicEList<State> answer = new BasicEList<State>();
    EList<State> _states = _self.getStates();
    for (final State state : _states) {
      if ((state instanceof InitialState)) {
        answer.add(state);
      }
    }
    return answer;
  }
  
  protected static boolean _privk3_isValid(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final String expression) {
    boolean _contains = expression.contains("=");
    if (_contains) {
      final String[] segments = expression.split("=");
      final String varName = segments[0];
      final String varValue = segments[1];
      EList<Variable> _variables = _self.getVariables();
      final Function1<Variable, Boolean> _function = new Function1<Variable, Boolean>() {
        public Boolean apply(final Variable it) {
          String _name = it.getName();
          return Boolean.valueOf(Objects.equal(_name, varName));
        }
      };
      Variable variable = IterableExtensions.<Variable>findFirst(_variables, _function);
      boolean _notEquals = (!Objects.equal(variable, null));
      if (_notEquals) {
        boolean _isValue = variable.isValue();
        return Objects.equal(Boolean.valueOf(_isValue), varValue);
      }
    } else {
      boolean _startsWith = expression.startsWith("!");
      if (_startsWith) {
        final String varName_1 = expression.substring(1);
        EList<Variable> _variables_1 = _self.getVariables();
        final Function1<Variable, Boolean> _function_1 = new Function1<Variable, Boolean>() {
          public Boolean apply(final Variable it) {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equal(_name, varName_1));
          }
        };
        Variable variable_1 = IterableExtensions.<Variable>findFirst(_variables_1, _function_1);
        boolean _notEquals_1 = (!Objects.equal(variable_1, null));
        if (_notEquals_1) {
          boolean _isValue_1 = variable_1.isValue();
          return (!_isValue_1);
        }
      } else {
        final String varName_2 = expression.substring(0);
        EList<Variable> _variables_2 = _self.getVariables();
        final Function1<Variable, Boolean> _function_2 = new Function1<Variable, Boolean>() {
          public Boolean apply(final Variable it) {
            String _name = it.getName();
            return Boolean.valueOf(Objects.equal(_name, varName_2));
          }
        };
        Variable variable_2 = IterableExtensions.<Variable>findFirst(_variables_2, _function_2);
        boolean _notEquals_2 = (!Objects.equal(variable_2, null));
        if (_notEquals_2) {
          return variable_2.isValue();
        }
      }
    }
    return false;
  }
  
  protected static void _privk3_update(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final Action action) {
    boolean _notEquals = (!Objects.equal(action, null));
    if (_notEquals) {
      EList<Variable> _variables = _self.getVariables();
      final Function1<Variable, Boolean> _function = new Function1<Variable, Boolean>() {
        public Boolean apply(final Variable it) {
          String _name = it.getName();
          String _variable = action.getVariable();
          return Boolean.valueOf(Objects.equal(_name, _variable));
        }
      };
      Variable variable = IterableExtensions.<Variable>findFirst(_variables, _function);
      boolean _equals = Objects.equal(variable, null);
      if (_equals) {
        Variable _createVariable = FinitestatemachinescompositeFactory.eINSTANCE.createVariable();
        variable = _createVariable;
        String _variable = action.getVariable();
        variable.setName(_variable);
        EList<Variable> _variables_1 = _self.getVariables();
        _variables_1.add(variable);
      }
      boolean _isValue = action.isValue();
      variable.setValue(_isValue);
    }
  }
  
  protected static void _privk3_addCurrentState(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final State s) {
    EList<State> _currentState = StateMachineAspect.currentState(_self);
    _currentState.add(s);
  }
  
  protected static void _privk3_removeCurrentState(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final State s) {
    EList<State> _currentState = StateMachineAspect.currentState(_self);
    _currentState.remove(s);
  }
  
  protected static boolean _privk3_isCurrentState(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final State s) {
    EList<State> _currentState = StateMachineAspect.currentState(_self);
    return _currentState.contains(s);
  }
  
  protected static EList<State> _privk3_currentState(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self) {
     return _self_.currentState; 
  }
  
  protected static void _privk3_currentState(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final EList<State> currentState) {
    _self_.currentState = currentState; try {
    
    			for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    				if (m.getName().equals("set" + "CurrentState")
    						&& m.getParameterTypes().length == 1) {
    					m.invoke(_self, currentState);
    
    				}
    			}
    		} catch (Exception e) {
    			// Chut !
    		} 
  }
  
  protected static EList<Transition> _privk3_currentTransitions(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self) {
     return _self_.currentTransitions; 
  }
  
  protected static void _privk3_currentTransitions(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final EList<Transition> currentTransitions) {
    _self_.currentTransitions = currentTransitions; try {
    
    			for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    				if (m.getName().equals("set" + "CurrentTransitions")
    						&& m.getParameterTypes().length == 1) {
    					m.invoke(_self, currentTransitions);
    
    				}
    			}
    		} catch (Exception e) {
    			// Chut !
    		} 
  }
}
