package finitestatemachines.timed;

import FSM.interfaces.Context;
import finitestatemachines.timed.StateAspect;

@SuppressWarnings("all")
public class ForkThread extends Thread {
  private finitestatemachinestimed.State state;
  
  private Context context;
  
  public ForkThread(final finitestatemachinestimed.State _state, final Context _context) {
    this.state = _state;
    this.context = _context;
  }
  
  public void run() {
    StateAspect.eval(this.state, this.context);
  }
}
