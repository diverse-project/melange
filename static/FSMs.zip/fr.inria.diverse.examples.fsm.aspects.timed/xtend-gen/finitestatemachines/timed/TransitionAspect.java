package finitestatemachines.timed;

import FSM.interfaces.Context;
import finitestatemachines.timed.TransitionAspectTransitionAspectProperties;
import finitestatemachinestimed.Transition;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;

@Aspect(className = Transition.class)
@SuppressWarnings("all")
public class TransitionAspect {
  public static void process(final Transition _self, final Context context) {
    finitestatemachines.timed.TransitionAspectTransitionAspectProperties _self_ = finitestatemachines.timed.TransitionAspectTransitionAspectContext.getSelf(_self);
    _privk3_process(_self_, _self,context);
  }
  
  protected static void _privk3_process(final TransitionAspectTransitionAspectProperties _self_, final Transition _self, final Context context) {
    int _time = _self.getTime();
    Context.stateWorking(_time);
  }
}
