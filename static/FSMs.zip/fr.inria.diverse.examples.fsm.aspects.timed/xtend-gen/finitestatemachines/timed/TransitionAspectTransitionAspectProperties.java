package finitestatemachines.timed;

@SuppressWarnings("all")
public class TransitionAspectTransitionAspectProperties {
}
