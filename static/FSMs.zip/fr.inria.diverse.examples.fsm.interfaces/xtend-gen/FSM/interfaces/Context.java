package FSM.interfaces;

import java.util.ArrayList;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class Context {
  public String chain;
  
  public ArrayList<EList<String>> events;
  
  public Context(final String chain) {
    this.chain = chain;
    int _length = chain.length();
    int _minus = (_length - 1);
    String noBrackets = chain.substring(1, _minus);
    String[] eventGroups = noBrackets.split(";");
    ArrayList<EList<String>> _arrayList = new ArrayList<EList<String>>();
    this.events = _arrayList;
    for (final String eventGroup : eventGroups) {
      {
        String[] _event = eventGroup.split(",");
        BasicEList<String> internalArray = new BasicEList<String>();
        for (final String event : _event) {
          internalArray.add(event);
        }
        this.events.add(internalArray);
      }
    }
  }
  
  public static void stateWorking(final int workingTime) {
    long initialTime = System.currentTimeMillis();
    boolean finish = false;
    while ((!finish)) {
      {
        long now = System.currentTimeMillis();
        if (((now - initialTime) >= workingTime)) {
          finish = true;
        }
      }
    }
  }
}
