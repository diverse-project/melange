package FSM.interfaces;

@SuppressWarnings("all")
public interface Interpreter {
  public abstract void execute(final String modelPath, final String input);
}
