package finitestatemachines.composite.simultaneous;

import FSM.interfaces.Context;
import finitestatemachines.composite.simultaneous.Printer;
import finitestatemachines.composite.simultaneous.SimultaneousEventsThread;
import finitestatemachines.composite.simultaneous.StateAspect;
import finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectProperties;
import finitestatemachinescomposite.InitialState;
import finitestatemachinescomposite.State;
import finitestatemachinescomposite.StateMachine;
import finitestatemachinescomposite.Transition;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import java.util.ArrayList;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.InputOutput;

/**
 * StateMachineAspect: Aspects for the State Machine meta-class
 * Serves as the interpreter of the state machine (the controller of the )
 */
@Aspect(className = StateMachine.class)
@SuppressWarnings("all")
public class StateMachineAspect {
  /**
   * Evaluates the input and sequentially executes the steps in the state machine.
   */
  public static void eval(final StateMachine _self, final Context context, final String filePath) {
    finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_eval(_self_, _self,context,filePath);
  }
  
  /**
   * Performs a step in the state machine i.e., reads an entry of the input stack and executes it.
   * If there are several events in the same step they are executed in parallel.
   */
  public static void step(final StateMachine _self, final Context context, final EList<String> eventsGroup) {
    finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_step(_self_, _self,context,eventsGroup);
  }
  
  /**
   * Returns the (unique?) initial state of the state machine.
   */
  private static EList<State> getInitialState(final StateMachine _self) {
    finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_getInitialState(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.State>)result;
  }
  
  /**
   * Removes a list of states from the currentStates list.
   */
  public static synchronized void removeCurrentStates(final StateMachine _self, final EList<State> statesToRemove) {
    finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_removeCurrentStates(_self_, _self,statesToRemove);
  }
  
  /**
   * Removes a list of states from the currentStates list.
   */
  public static synchronized void addCurrentStates(final StateMachine _self, final EList<State> statesToAdd) {
    finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_addCurrentStates(_self_, _self,statesToAdd);
  }
  
  public static EList<State> currentState(final StateMachine _self) {
    finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_currentState(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.State>)result;
  }
  
  public static void currentState(final StateMachine _self, final EList<State> currentState) {
    finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_currentState(_self_, _self,currentState);
  }
  
  private static EList<Transition> currentTransitions(final StateMachine _self) {
    finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_currentTransitions(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.Transition>)result;
  }
  
  private static void currentTransitions(final StateMachine _self, final EList<Transition> currentTransitions) {
    finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectProperties _self_ = finitestatemachines.composite.simultaneous.StateMachineAspectStateMachineAspectContext.getSelf(_self);
    _privk3_currentTransitions(_self_, _self,currentTransitions);
  }
  
  protected static void _privk3_eval(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final Context context, final String filePath) {
    InputOutput.<String>println("\nExecuting the state machine. Please wait for the results...\n");
    InputOutput.<String>println(" ... executing input ...\n");
    ArrayList<EList<String>> events = context.events;
    EList<State> _initialState = StateMachineAspect.getInitialState(_self);
    StateMachineAspect.currentState(_self, _initialState);
    EList<State> _currentState = StateMachineAspect.currentState(_self);
    State _get = _currentState.get(0);
    StateAspect.eval(_get, context);
    for (final EList<String> eventsGroup : events) {
      {
        InputOutput.<String>println(((("  input item: " + eventsGroup) + " time: ") + Integer.valueOf(((int) System.currentTimeMillis()))));
        StateMachineAspect.step(_self, context, eventsGroup);
      }
    }
    InputOutput.<String>println("\n *.* Your results are ready! \n");
    Printer _printer = new Printer();
    _printer.printFinalStateInConsole(_self);
    Printer _printer_1 = new Printer();
    _printer_1.printFinalStateInFile(_self, filePath);
  }
  
  protected static void _privk3_step(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final Context context, final EList<String> eventsGroup) {
    BasicEList<Transition> _basicEList = new BasicEList<Transition>();
    StateMachineAspect.currentTransitions(_self, _basicEList);
    ArrayList<Thread> threads = new ArrayList<Thread>();
    for (final String event : eventsGroup) {
      {
        SimultaneousEventsThread thread = new SimultaneousEventsThread(event, _self, context);
        threads.add(thread);
        thread.start();
      }
    }
    boolean threadsAlive = true;
    while (threadsAlive) {
      {
        int stillAlive = 0;
        for (final Thread _thread : threads) {
          boolean _isAlive = _thread.isAlive();
          if (_isAlive) {
            stillAlive++;
          }
        }
        if ((stillAlive == 0)) {
          threadsAlive = false;
        }
      }
    }
  }
  
  protected static EList<State> _privk3_getInitialState(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self) {
    BasicEList<State> answer = new BasicEList<State>();
    EList<State> _states = _self.getStates();
    for (final State state : _states) {
      if ((state instanceof InitialState)) {
        answer.add(state);
      }
    }
    return answer;
  }
  
  protected static void _privk3_removeCurrentStates(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final EList<State> statesToRemove) {
    EList<State> _currentState = StateMachineAspect.currentState(_self);
    _currentState.removeAll(statesToRemove);
  }
  
  protected static void _privk3_addCurrentStates(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final EList<State> statesToAdd) {
    for (final State _state : statesToAdd) {
      EList<State> _currentState = StateMachineAspect.currentState(_self);
      boolean _contains = _currentState.contains(_state);
      boolean _not = (!_contains);
      if (_not) {
        EList<State> _currentState_1 = StateMachineAspect.currentState(_self);
        _currentState_1.add(_state);
      }
    }
  }
  
  protected static EList<State> _privk3_currentState(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self) {
     return _self_.currentState; 
  }
  
  protected static void _privk3_currentState(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final EList<State> currentState) {
    _self_.currentState = currentState; try {
    
    			for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    				if (m.getName().equals("set" + "CurrentState")
    						&& m.getParameterTypes().length == 1) {
    					m.invoke(_self, currentState);
    
    				}
    			}
    		} catch (Exception e) {
    			// Chut !
    		} 
  }
  
  protected static EList<Transition> _privk3_currentTransitions(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self) {
     return _self_.currentTransitions; 
  }
  
  protected static void _privk3_currentTransitions(final StateMachineAspectStateMachineAspectProperties _self_, final StateMachine _self, final EList<Transition> currentTransitions) {
    _self_.currentTransitions = currentTransitions; try {
    
    			for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    				if (m.getName().equals("set" + "CurrentTransitions")
    						&& m.getParameterTypes().length == 1) {
    					m.invoke(_self, currentTransitions);
    
    				}
    			}
    		} catch (Exception e) {
    			// Chut !
    		} 
  }
}
