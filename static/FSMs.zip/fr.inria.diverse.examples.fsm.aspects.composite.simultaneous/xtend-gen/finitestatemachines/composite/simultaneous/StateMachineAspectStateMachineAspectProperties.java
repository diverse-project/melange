package finitestatemachines.composite.simultaneous;

import finitestatemachinescomposite.State;
import finitestatemachinescomposite.Transition;
import org.eclipse.emf.common.util.EList;

@SuppressWarnings("all")
public class StateMachineAspectStateMachineAspectProperties {
  public EList<State> currentState = null;
  
  public EList<Transition> currentTransitions = null;
}
