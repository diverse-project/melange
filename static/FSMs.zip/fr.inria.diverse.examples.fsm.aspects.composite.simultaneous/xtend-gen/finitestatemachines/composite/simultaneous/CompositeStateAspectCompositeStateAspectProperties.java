package finitestatemachines.composite.simultaneous;

@SuppressWarnings("all")
public class CompositeStateAspectCompositeStateAspectProperties {
}
