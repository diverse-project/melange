package finitestatemachines.composite.classic;

@SuppressWarnings("all")
public class CompositeStateAspectCompositeStateAspectProperties {
}
