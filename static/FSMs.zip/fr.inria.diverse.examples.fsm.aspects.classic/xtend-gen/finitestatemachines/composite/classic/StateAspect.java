package finitestatemachines.composite.classic;

import FSM.interfaces.Context;
import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import finitestatemachines.composite.classic.CompositeStateAspect;
import finitestatemachines.composite.classic.ForkThread;
import finitestatemachines.composite.classic.StateAspectStateAspectProperties;
import finitestatemachines.composite.classic.StateMachineAspect;
import finitestatemachines.composite.classic.TransitionAspect;
import finitestatemachinescomposite.CompositeState;
import finitestatemachinescomposite.Fork;
import finitestatemachinescomposite.Guard;
import finitestatemachinescomposite.InitialState;
import finitestatemachinescomposite.Join;
import finitestatemachinescomposite.Region;
import finitestatemachinescomposite.State;
import finitestatemachinescomposite.StateMachine;
import finitestatemachinescomposite.Transition;
import finitestatemachinescomposite.Trigger;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@Aspect(className = State.class)
@SuppressWarnings("all")
public class StateAspect {
  public static void run(final State _self, final Context context) {
    finitestatemachines.composite.classic.StateAspectStateAspectProperties _self_ = finitestatemachines.composite.classic.StateAspectStateAspectContext.getSelf(_self);
    _privk3_run(_self_, _self,context);
  }
  
  /**
   * Get transitions that can be fired by this event
   * If even is null all transitions without event are candidate
   */
  public static EList<Transition> getActiveTransitions(final State _self, final String event) {
    finitestatemachines.composite.classic.StateAspectStateAspectProperties _self_ = finitestatemachines.composite.classic.StateAspectStateAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_getActiveTransitions(_self_, _self,event);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.Transition>)result;
  }
  
  public static EList<State> getAllParents(final State _self) {
    finitestatemachines.composite.classic.StateAspectStateAspectProperties _self_ = finitestatemachines.composite.classic.StateAspectStateAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_getAllParents(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.State>)result;
  }
  
  public static EList<State> getAllChildren(final State _self) {
    finitestatemachines.composite.classic.StateAspectStateAspectProperties _self_ = finitestatemachines.composite.classic.StateAspectStateAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_getAllChildren(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.State>)result;
  }
  
  public static void eval(final State _self, final Context context) {
    finitestatemachines.composite.classic.StateAspectStateAspectProperties _self_ = finitestatemachines.composite.classic.StateAspectStateAspectContext.getSelf(_self);
    _privk3_eval(_self_, _self,context);
  }
  
  protected static void _privk3_run(final StateAspectStateAspectProperties _self_, final State _self, final Context context) {
    long _currentTimeMillis = System.currentTimeMillis();
    _self.setInitialTime(((int) _currentTimeMillis));
    Context.stateWorking(1000);
    long _currentTimeMillis_1 = System.currentTimeMillis();
    _self.setFinalTime(((int) _currentTimeMillis_1));
  }
  
  protected static EList<Transition> _privk3_getActiveTransitions(final StateAspectStateAspectProperties _self_, final State _self, final String event) {
    final BasicEList<Transition> res = new BasicEList<Transition>();
    EList<Transition> _outgoing = _self.getOutgoing();
    for (final Transition transition : _outgoing) {
      boolean _or = false;
      boolean _and = false;
      boolean _equals = Objects.equal(event, null);
      if (!_equals) {
        _and = false;
      } else {
        Trigger _trigger = transition.getTrigger();
        boolean _equals_1 = Objects.equal(_trigger, null);
        _and = _equals_1;
      }
      if (_and) {
        _or = true;
      } else {
        Trigger _trigger_1 = transition.getTrigger();
        String _expression = _trigger_1.getExpression();
        boolean _equals_2 = _expression.equals(event);
        _or = _equals_2;
      }
      if (_or) {
        boolean _or_1 = false;
        Guard _guard = transition.getGuard();
        boolean _equals_3 = Objects.equal(_guard, null);
        if (_equals_3) {
          _or_1 = true;
        } else {
          StateMachine _stateMachine = _self.getStateMachine();
          Guard _guard_1 = transition.getGuard();
          String _expression_1 = _guard_1.getExpression();
          boolean _isValid = StateMachineAspect.isValid(_stateMachine, _expression_1);
          _or_1 = _isValid;
        }
        if (_or_1) {
          res.add(transition);
        }
      }
    }
    return res;
  }
  
  protected static EList<State> _privk3_getAllParents(final StateAspectStateAspectProperties _self_, final State _self) {
    final BasicEList<State> res = new BasicEList<State>();
    CompositeState _parentState = _self.getParentState();
    boolean _notEquals = (!Objects.equal(_parentState, null));
    if (_notEquals) {
      CompositeState _parentState_1 = _self.getParentState();
      EList<State> _allParents = StateAspect.getAllParents(_parentState_1);
      res.addAll(_allParents);
      CompositeState _parentState_2 = _self.getParentState();
      res.add(_parentState_2);
    }
    return res;
  }
  
  protected static EList<State> _privk3_getAllChildren(final StateAspectStateAspectProperties _self_, final State _self) {
    final BasicEList<State> res = new BasicEList<State>();
    if ((_self instanceof CompositeState)) {
      final CompositeState composite = ((CompositeState) _self);
      EList<Region> _regions = composite.getRegions();
      final Function1<Region, EList<State>> _function = new Function1<Region, EList<State>>() {
        public EList<State> apply(final Region it) {
          return it.getStates();
        }
      };
      List<EList<State>> _map = ListExtensions.<Region, EList<State>>map(_regions, _function);
      final Iterable<State> subStates = Iterables.<State>concat(_map);
      final Function1<State, EList<State>> _function_1 = new Function1<State, EList<State>>() {
        public EList<State> apply(final State s) {
          return StateAspect.getAllChildren(s);
        }
      };
      Iterable<EList<State>> _map_1 = IterableExtensions.<State, EList<State>>map(subStates, _function_1);
      final Iterable<State> allSubStates = Iterables.<State>concat(_map_1);
      Iterables.<State>addAll(res, subStates);
      Iterables.<State>addAll(res, allSubStates);
    }
    return res;
  }
  
  protected static void _privk3_eval(final StateAspectStateAspectProperties _self_, final State _self, final Context context) {
    String _name = _self.getName();
    InputOutput.<String>println(_name);
    final StateMachine fsm = _self.getStateMachine();
    if ((_self instanceof Fork)) {
      ArrayList<ForkThread> threads = new ArrayList<ForkThread>();
      EList<Transition> _outgoing = ((Fork)_self).getOutgoing();
      for (final Transition _forkTransition : _outgoing) {
        {
          State _target = _forkTransition.getTarget();
          ForkThread _forkThread = new ForkThread(_target, context);
          threads.add(_forkThread);
          _forkThread.start();
        }
      }
      boolean threadsAlive = true;
      while (threadsAlive) {
        {
          int stillAlive = 0;
          for (final Thread _thread : threads) {
            boolean _isAlive = _thread.isAlive();
            if (_isAlive) {
              stillAlive++;
            }
          }
          if ((stillAlive == 0)) {
            threadsAlive = false;
          }
        }
      }
    } else {
      if ((_self instanceof Join)) {
        final Join join = ((Join) _self);
        EList<Transition> _incoming = join.getIncoming();
        final Function1<Transition, State> _function = new Function1<Transition, State>() {
          public State apply(final Transition it) {
            return it.getSource();
          }
        };
        final List<State> sources = ListExtensions.<Transition, State>map(_incoming, _function);
        EList<State> _allCurrentStates = StateMachineAspect.getAllCurrentStates(fsm);
        boolean _containsAll = _allCurrentStates.containsAll(sources);
        if (_containsAll) {
          final Procedure1<State> _function_1 = new Procedure1<State>() {
            public void apply(final State s) {
              if ((s instanceof CompositeState)) {
                final CompositeState composite = ((CompositeState) s);
                EList<State> _allStates = CompositeStateAspect.getAllStates(composite);
                final Procedure1<State> _function = new Procedure1<State>() {
                  public void apply(final State subS) {
                    StateMachineAspect.removeCurrentState(fsm, subS);
                  }
                };
                IterableExtensions.<State>forEach(_allStates, _function);
              } else {
                StateMachineAspect.removeCurrentState(fsm, s);
              }
            }
          };
          IterableExtensions.<State>forEach(sources, _function_1);
          EList<Transition> _outgoing_1 = join.getOutgoing();
          final Procedure1<Transition> _function_2 = new Procedure1<Transition>() {
            public void apply(final Transition out) {
              TransitionAspect.fire(out, context);
            }
          };
          IterableExtensions.<Transition>forEach(_outgoing_1, _function_2);
        }
      } else {
        if ((_self instanceof CompositeState)) {
          final EList<Transition> nextTransition = StateAspect.getActiveTransitions(_self, null);
          boolean _isEmpty = nextTransition.isEmpty();
          if (_isEmpty) {
            StateMachineAspect.addCurrentState(fsm, _self);
            final CompositeState composite = ((CompositeState) _self);
            EList<Region> _regions = composite.getRegions();
            final Function1<Region, EList<State>> _function_3 = new Function1<Region, EList<State>>() {
              public EList<State> apply(final Region r) {
                return r.getStates();
              }
            };
            List<EList<State>> _map = ListExtensions.<Region, EList<State>>map(_regions, _function_3);
            Iterable<State> _flatten = Iterables.<State>concat(_map);
            final Function1<State, Boolean> _function_4 = new Function1<State, Boolean>() {
              public Boolean apply(final State s) {
                return Boolean.valueOf((s instanceof InitialState));
              }
            };
            final Iterable<State> initStates = IterableExtensions.<State>filter(_flatten, _function_4);
            final ArrayList<ForkThread> threads_1 = new ArrayList<ForkThread>();
            final Procedure1<State> _function_5 = new Procedure1<State>() {
              public void apply(final State init) {
                ForkThread _forkThread = new ForkThread(init, context);
                threads_1.add(_forkThread);
                _forkThread.start();
              }
            };
            IterableExtensions.<State>forEach(initStates, _function_5);
            boolean threadsAlive_1 = true;
            while (threadsAlive_1) {
              {
                int stillAlive = 0;
                for (final Thread _thread : threads_1) {
                  boolean _isAlive = _thread.isAlive();
                  if (_isAlive) {
                    stillAlive++;
                  }
                }
                if ((stillAlive == 0)) {
                  threadsAlive_1 = false;
                }
              }
            }
          } else {
            EList<Transition> _activeTransitions = StateAspect.getActiveTransitions(_self, null);
            final Procedure1<Transition> _function_6 = new Procedure1<Transition>() {
              public void apply(final Transition it) {
                TransitionAspect.fire(it, context);
              }
            };
            IterableExtensions.<Transition>forEach(_activeTransitions, _function_6);
          }
        } else {
          StateAspect.run(_self, context);
          final EList<Transition> nextTransition_1 = StateAspect.getActiveTransitions(_self, null);
          boolean _isEmpty_1 = nextTransition_1.isEmpty();
          if (_isEmpty_1) {
            StateMachineAspect.addCurrentState(fsm, _self);
            CompositeState parent = _self.getParentState();
            while (((!Objects.equal(parent, null)) && (!StateMachineAspect.isCurrentState(fsm, parent)))) {
              {
                StateMachineAspect.addCurrentState(fsm, parent);
                CompositeState _parentState = parent.getParentState();
                parent = _parentState;
              }
            }
          } else {
            EList<Transition> _activeTransitions_1 = StateAspect.getActiveTransitions(_self, null);
            final Procedure1<Transition> _function_7 = new Procedure1<Transition>() {
              public void apply(final Transition it) {
                TransitionAspect.fire(it, context);
              }
            };
            IterableExtensions.<Transition>forEach(_activeTransitions_1, _function_7);
          }
        }
      }
    }
  }
}
