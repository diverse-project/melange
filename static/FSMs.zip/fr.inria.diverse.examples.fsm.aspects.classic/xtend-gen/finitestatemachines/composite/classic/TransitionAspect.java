package finitestatemachines.composite.classic;

import FSM.interfaces.Context;
import finitestatemachines.composite.classic.CompositeStateAspect;
import finitestatemachines.composite.classic.StateAspect;
import finitestatemachines.composite.classic.StateMachineAspect;
import finitestatemachines.composite.classic.TransitionAspectTransitionAspectProperties;
import finitestatemachinescomposite.Action;
import finitestatemachinescomposite.CompositeState;
import finitestatemachinescomposite.State;
import finitestatemachinescomposite.StateMachine;
import finitestatemachinescomposite.Transition;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@Aspect(className = Transition.class)
@SuppressWarnings("all")
public class TransitionAspect {
  public static void fire(final Transition _self, final Context context) {
    finitestatemachines.composite.classic.TransitionAspectTransitionAspectProperties _self_ = finitestatemachines.composite.classic.TransitionAspectTransitionAspectContext.getSelf(_self);
    _privk3_fire(_self_, _self,context);
  }
  
  protected static void _privk3_fire(final TransitionAspectTransitionAspectProperties _self_, final Transition _self, final Context context) {
    final StateMachine fsm = _self.getStateMachine();
    final State source = _self.getSource();
    if ((source instanceof CompositeState)) {
      final CompositeState composite = ((CompositeState) source);
      EList<State> _allStates = CompositeStateAspect.getAllStates(composite);
      final Procedure1<State> _function = new Procedure1<State>() {
        public void apply(final State s) {
          StateMachineAspect.removeCurrentState(fsm, s);
        }
      };
      IterableExtensions.<State>forEach(_allStates, _function);
    } else {
      State _source = _self.getSource();
      StateMachineAspect.removeCurrentState(fsm, _source);
    }
    final State target = _self.getTarget();
    StateAspect.eval(target, context);
    final Action action = _self.getAction();
    StateMachine _stateMachine = _self.getStateMachine();
    StateMachineAspect.update(_stateMachine, action);
  }
}
