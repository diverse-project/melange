package finitestatemachines.composite.classic;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import com.itextpdf.awt.DefaultFontMapper;
import com.itextpdf.text.Document;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;
import finitestatemachinescomposite.CompositeState;
import finitestatemachinescomposite.Fork;
import finitestatemachinescomposite.Join;
import finitestatemachinescomposite.Region;
import finitestatemachinescomposite.State;
import finitestatemachinescomposite.StateMachine;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.IntervalCategoryDataset;
import org.jfree.data.gantt.Task;
import org.jfree.data.gantt.TaskSeries;
import org.jfree.data.gantt.TaskSeriesCollection;
import org.jfree.data.time.SimpleTimePeriod;
import org.jfree.data.time.TimePeriod;

@SuppressWarnings("all")
public class Printer {
  /**
   * Prints time final state of the states machine i.e., the schedule after the evaluation
   */
  public void printFinalStateInConsole(final StateMachine stateMachine) {
    EList<State> _states = stateMachine.getStates();
    for (final State _state : _states) {
      this.printState(_state);
    }
  }
  
  public void printState(final State _state) {
    if (((!(_state instanceof Fork)) && (!(_state instanceof Join)))) {
      String _name = _state.getName();
      String _plus = ("   - State: " + _name);
      String _plus_1 = (_plus + " [initialTime: ");
      int _initialTime = _state.getInitialTime();
      String _plus_2 = (_plus_1 + Integer.valueOf(_initialTime));
      String _plus_3 = (_plus_2 + " finalTime: ");
      int _finalTime = _state.getFinalTime();
      String _plus_4 = (_plus_3 + Integer.valueOf(_finalTime));
      String _plus_5 = (_plus_4 + "]");
      InputOutput.<String>println(_plus_5);
      if ((_state instanceof CompositeState)) {
        final CompositeState composite = ((CompositeState) _state);
        this.printSubStates(composite);
      }
    }
  }
  
  public void printSubStates(final CompositeState composite) {
    EList<Region> _regions = composite.getRegions();
    final Function1<Region, EList<State>> _function = new Function1<Region, EList<State>>() {
      public EList<State> apply(final Region r) {
        return r.getStates();
      }
    };
    List<EList<State>> _map = ListExtensions.<Region, EList<State>>map(_regions, _function);
    Iterable<State> _flatten = Iterables.<State>concat(_map);
    final Procedure1<State> _function_1 = new Procedure1<State>() {
      public void apply(final State s) {
        Printer.this.printState(s);
      }
    };
    IterableExtensions.<State>forEach(_flatten, _function_1);
  }
  
  /**
   * Prints as a Gantt diagram the final state of the states machine
   * i.e., the schedule after the evaluation
   */
  public void printFinalStateInFile(final StateMachine stateMachine, final String filePath) {
    try {
      IntervalCategoryDataset dataset = Printer.createDataset(stateMachine);
      JFreeChart chart = this.createChart(dataset);
      this.saveChartToPDF(chart, filePath, 500, 300);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  /**
   * Returns the Gantt model according to the final state of the state machine.
   */
  public static IntervalCategoryDataset createDataset(final StateMachine stateMachine) {
    final TaskSeries s1 = new TaskSeries("State Machine");
    EList<State> _states = stateMachine.getStates();
    for (final State _state : _states) {
      List<Task> _createTasks = Printer.createTasks(_state);
      final Procedure1<Task> _function = new Procedure1<Task>() {
        public void apply(final Task t) {
          s1.add(t);
        }
      };
      IterableExtensions.<Task>forEach(_createTasks, _function);
    }
    TaskSeriesCollection collection = new TaskSeriesCollection();
    collection.add(s1);
    return ((IntervalCategoryDataset) collection);
  }
  
  public static List<Task> createTasks(final State _state) {
    final List<Task> res = new ArrayList<Task>();
    if ((_state instanceof CompositeState)) {
      final CompositeState composite = ((CompositeState) _state);
      final List<Task> subTasks = Printer.createCompositeTasks(composite);
      res.addAll(subTasks);
      final Comparator<Task> _function = new Comparator<Task>() {
        public int compare(final Task a, final Task b) {
          int _xifexpression = (int) 0;
          TimePeriod _duration = a.getDuration();
          Date _start = _duration.getStart();
          TimePeriod _duration_1 = b.getDuration();
          Date _start_1 = _duration_1.getStart();
          boolean _lessThan = (_start.compareTo(_start_1) < 0);
          if (_lessThan) {
            _xifexpression = (-1);
          } else {
            _xifexpression = 1;
          }
          return _xifexpression;
        }
      };
      Task _min = IterableExtensions.<Task>min(subTasks, _function);
      TimePeriod _duration = _min.getDuration();
      final Date min = _duration.getStart();
      final Comparator<Task> _function_1 = new Comparator<Task>() {
        public int compare(final Task a, final Task b) {
          int _xifexpression = (int) 0;
          TimePeriod _duration = a.getDuration();
          Date _end = _duration.getEnd();
          TimePeriod _duration_1 = b.getDuration();
          Date _end_1 = _duration_1.getEnd();
          boolean _lessThan = (_end.compareTo(_end_1) < 0);
          if (_lessThan) {
            _xifexpression = (-1);
          } else {
            _xifexpression = 1;
          }
          return _xifexpression;
        }
      };
      Task _max = IterableExtensions.<Task>max(subTasks, _function_1);
      TimePeriod _duration_1 = _max.getDuration();
      final Date max = _duration_1.getEnd();
      String _name = ((CompositeState)_state).getName();
      SimpleTimePeriod _simpleTimePeriod = new SimpleTimePeriod(min, max);
      Task _task = new Task(_name, _simpleTimePeriod);
      res.add(_task);
    } else {
      if (((!(_state instanceof Fork)) && (!(_state instanceof Join)))) {
        String _name_1 = _state.getName();
        int _initialTime = _state.getInitialTime();
        Date _date = new Date(_initialTime);
        int _finalTime = _state.getFinalTime();
        Date _date_1 = new Date(_finalTime);
        SimpleTimePeriod _simpleTimePeriod_1 = new SimpleTimePeriod(_date, _date_1);
        Task _task_1 = new Task(_name_1, _simpleTimePeriod_1);
        res.add(_task_1);
      }
    }
    return res;
  }
  
  public static List<Task> createCompositeTasks(final CompositeState composite) {
    final List<Task> res = new ArrayList<Task>();
    EList<Region> _regions = composite.getRegions();
    final Function1<Region, EList<State>> _function = new Function1<Region, EList<State>>() {
      public EList<State> apply(final Region r) {
        return r.getStates();
      }
    };
    List<EList<State>> _map = ListExtensions.<Region, EList<State>>map(_regions, _function);
    Iterable<State> _flatten = Iterables.<State>concat(_map);
    final Procedure1<State> _function_1 = new Procedure1<State>() {
      public void apply(final State s) {
        List<Task> _createTasks = Printer.createTasks(s);
        res.addAll(_createTasks);
      }
    };
    IterableExtensions.<State>forEach(_flatten, _function_1);
    return res;
  }
  
  /**
   * Creates a Gantt diagram according to the Gantt model in the parameter.
   */
  private JFreeChart createChart(final IntervalCategoryDataset dataset) {
    JFreeChart chart = ChartFactory.createGanttChart(
      "Execution results", 
      "State", 
      "Time", dataset, 
      true, 
      true, 
      false);
    return chart;
  }
  
  /**
   * Exports the Gantt diagram to the PDF file specified in the parameter.
   */
  public void saveChartToPDF(final JFreeChart chart, final String fileName, final int width, final int height) throws Exception {
    boolean _notEquals = (!Objects.equal(chart, null));
    if (_notEquals) {
      BufferedOutputStream out = null;
      try {
        FileOutputStream _fileOutputStream = new FileOutputStream(fileName);
        BufferedOutputStream _bufferedOutputStream = new BufferedOutputStream(_fileOutputStream);
        out = _bufferedOutputStream;
        Rectangle pagesize = new Rectangle(width, height);
        Document document = new Document(pagesize, 50, 50, 50, 50);
        try {
          PdfWriter writer = PdfWriter.getInstance(document, out);
          document.addAuthor("JFreeChart");
          document.open();
          PdfContentByte cb = writer.getDirectContent();
          PdfTemplate tp = cb.createTemplate(width, height);
          DefaultFontMapper _defaultFontMapper = new DefaultFontMapper();
          Graphics2D g2 = tp.createGraphics(width, height, _defaultFontMapper);
          Rectangle2D r2D = new Rectangle2D.Double(0, 0, width, height);
          chart.draw(g2, r2D, null);
          g2.dispose();
          cb.addTemplate(tp, 0, 0);
        } finally {
          document.close();
        }
      } finally {
        boolean _notEquals_1 = (!Objects.equal(out, null));
        if (_notEquals_1) {
          out.close();
        }
      }
    }
  }
}
