package finitestatemachines.composite;

import FSM.interfaces.Context;
import finitestatemachines.composite.StateAspectStateAspectProperties;
import finitestatemachinescomposite.State;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;

@Aspect(className = State.class)
@SuppressWarnings("all")
public class StateAspect {
  public static void eval(final State _self, final Context context) {
    finitestatemachines.composite.StateAspectStateAspectProperties _self_ = finitestatemachines.composite.StateAspectStateAspectContext.getSelf(_self);
     if (_self instanceof finitestatemachinescomposite.CompositeState){
     finitestatemachines.composite.CompositeStateAspect.eval((finitestatemachinescomposite.CompositeState)_self,context);
    } else  if (_self instanceof finitestatemachinescomposite.State){
     finitestatemachines.composite.StateAspect._privk3_eval(_self_, (finitestatemachinescomposite.State)_self,context);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_eval(final StateAspectStateAspectProperties _self_, final State _self, final Context context) {
    long _currentTimeMillis = System.currentTimeMillis();
    _self.setInitialTime(((int) _currentTimeMillis));
    Context.stateWorking(1000);
    long _currentTimeMillis_1 = System.currentTimeMillis();
    _self.setFinalTime(((int) _currentTimeMillis_1));
  }
}
