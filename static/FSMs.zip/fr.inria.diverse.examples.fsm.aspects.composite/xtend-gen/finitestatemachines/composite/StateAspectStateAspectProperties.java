package finitestatemachines.composite;

@SuppressWarnings("all")
public class StateAspectStateAspectProperties {
}
