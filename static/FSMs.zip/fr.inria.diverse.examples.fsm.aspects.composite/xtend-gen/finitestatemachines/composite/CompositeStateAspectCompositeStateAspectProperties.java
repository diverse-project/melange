package finitestatemachines.composite;

@SuppressWarnings("all")
public class CompositeStateAspectCompositeStateAspectProperties {
}
