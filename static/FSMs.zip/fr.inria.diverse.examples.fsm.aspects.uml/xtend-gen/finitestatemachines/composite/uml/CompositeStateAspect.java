package finitestatemachines.composite.uml;

import com.google.common.collect.Iterables;
import finitestatemachines.composite.uml.CompositeStateAspectCompositeStateAspectProperties;
import finitestatemachines.composite.uml.StateAspect;
import finitestatemachinescomposite.CompositeState;
import finitestatemachinescomposite.Region;
import finitestatemachinescomposite.State;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import java.util.List;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;

@Aspect(className = CompositeState.class)
@SuppressWarnings("all")
public class CompositeStateAspect extends StateAspect {
  /**
   * Get all sub states
   */
  public static EList<State> getAllStates(final CompositeState _self) {
    finitestatemachines.composite.uml.CompositeStateAspectCompositeStateAspectProperties _self_ = finitestatemachines.composite.uml.CompositeStateAspectCompositeStateAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_getAllStates(_self_, _self);
    return (org.eclipse.emf.common.util.EList<finitestatemachinescomposite.State>)result;
  }
  
  protected static EList<State> _privk3_getAllStates(final CompositeStateAspectCompositeStateAspectProperties _self_, final CompositeState _self) {
    BasicEList<State> attendedStates = new BasicEList<State>();
    EList<Region> _regions = _self.getRegions();
    final Function1<Region, EList<State>> _function = new Function1<Region, EList<State>>() {
      public EList<State> apply(final Region r) {
        return r.getStates();
      }
    };
    List<EList<State>> _map = ListExtensions.<Region, EList<State>>map(_regions, _function);
    Iterable<State> subStates = Iterables.<State>concat(_map);
    while ((!IterableExtensions.isEmpty(subStates))) {
      {
        Iterables.<State>addAll(attendedStates, subStates);
        final Function1<State, Boolean> _function_1 = new Function1<State, Boolean>() {
          public Boolean apply(final State s) {
            return Boolean.valueOf((s instanceof CompositeState));
          }
        };
        Iterable<State> _filter = IterableExtensions.<State>filter(subStates, _function_1);
        final Function1<State, CompositeState> _function_2 = new Function1<State, CompositeState>() {
          public CompositeState apply(final State s) {
            return ((CompositeState) s);
          }
        };
        Iterable<CompositeState> subComposite = IterableExtensions.<State, CompositeState>map(_filter, _function_2);
        final Function1<CompositeState, Iterable<State>> _function_3 = new Function1<CompositeState, Iterable<State>>() {
          public Iterable<State> apply(final CompositeState c) {
            EList<Region> _regions = c.getRegions();
            final Function1<Region, EList<State>> _function = new Function1<Region, EList<State>>() {
              public EList<State> apply(final Region r) {
                return r.getStates();
              }
            };
            List<EList<State>> _map = ListExtensions.<Region, EList<State>>map(_regions, _function);
            return Iterables.<State>concat(_map);
          }
        };
        Iterable<Iterable<State>> _map_1 = IterableExtensions.<CompositeState, Iterable<State>>map(subComposite, _function_3);
        Iterable<State> _flatten = Iterables.<State>concat(_map_1);
        subStates = _flatten;
      }
    }
    return attendedStates;
  }
}
