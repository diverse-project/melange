package finitestatemachines.composite.uml;

@SuppressWarnings("all")
public class TransitionAspectTransitionAspectProperties {
}
