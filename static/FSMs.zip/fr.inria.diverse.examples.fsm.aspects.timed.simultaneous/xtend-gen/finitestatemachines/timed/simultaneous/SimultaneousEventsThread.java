package finitestatemachines.timed.simultaneous;

import FSM.interfaces.Context;
import com.google.common.base.Objects;
import finitestatemachines.timed.simultaneous.ForkThread;
import finitestatemachines.timed.simultaneous.StateAspect;
import finitestatemachines.timed.simultaneous.StateMachineAspect;
import finitestatemachines.timed.simultaneous.TransitionAspect;
import finitestatemachinestimed.Fork;
import finitestatemachinestimed.Join;
import finitestatemachinestimed.StateMachine;
import finitestatemachinestimed.Transition;
import finitestatemachinestimed.Trigger;
import java.util.ArrayList;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;

/**
 * Class for executing events in parallel.
 */
@SuppressWarnings("all")
public class SimultaneousEventsThread extends Thread {
  private String event;
  
  private StateMachine stateMachine;
  
  private Context context;
  
  private ArrayList<finitestatemachinestimed.State> currentState;
  
  private ArrayList<Transition> currentTransitions;
  
  /**
   * Constructor of the class. Initializes the attributes with the values
   * in the parameters
   */
  public SimultaneousEventsThread(final String _event, final StateMachine _stateMachine, final Context _context) {
    this.event = _event;
    this.stateMachine = _stateMachine;
    this.context = _context;
    ArrayList<finitestatemachinestimed.State> _arrayList = new ArrayList<finitestatemachinestimed.State>();
    this.currentState = _arrayList;
    ArrayList<Transition> _arrayList_1 = new ArrayList<Transition>();
    this.currentTransitions = _arrayList_1;
  }
  
  /**
   * Runs the thread!
   */
  public void run() {
    EList<finitestatemachinestimed.State> attendedStates = new BasicEList<finitestatemachinestimed.State>();
    EList<finitestatemachinestimed.State> _currentState = StateMachineAspect.currentState(this.stateMachine);
    for (final finitestatemachinestimed.State _state : _currentState) {
      EList<Transition> _outgoing = _state.getOutgoing();
      for (final Transition transition : _outgoing) {
        boolean _and = false;
        Trigger _trigger = transition.getTrigger();
        boolean _notEquals = (!Objects.equal(_trigger, null));
        if (!_notEquals) {
          _and = false;
        } else {
          Trigger _trigger_1 = transition.getTrigger();
          String _expression = _trigger_1.getExpression();
          boolean _equals = _expression.equals(this.event);
          _and = _equals;
        }
        if (_and) {
          this.currentState.add(_state);
        }
      }
    }
    for (final finitestatemachinestimed.State _state_1 : this.currentState) {
      EList<Transition> _outgoing_1 = _state_1.getOutgoing();
      for (final Transition transition_1 : _outgoing_1) {
        Trigger _trigger_2 = transition_1.getTrigger();
        String _expression_1 = _trigger_2.getExpression();
        boolean _equals_1 = _expression_1.equals(this.event);
        if (_equals_1) {
          attendedStates.add(_state_1);
          this.currentTransitions.add(transition_1);
        }
      }
    }
    this.currentState.removeAll(attendedStates);
    StateMachineAspect.removeCurrentStates(this.stateMachine, attendedStates);
    this.processTransitions(this.context);
  }
  
  /**
   * Processes the current active transitions by activating their target states
   * and executing the steps on the states (should the evaluation of the states be called from here?).
   */
  private void processTransitions(final Context context) {
    for (final Transition _transition : this.currentTransitions) {
      {
        TransitionAspect.process(_transition, context);
        finitestatemachinestimed.State _target = _transition.getTarget();
        if ((_target instanceof Fork)) {
          ArrayList<ForkThread> threads = new ArrayList<ForkThread>();
          finitestatemachinestimed.State _target_1 = _transition.getTarget();
          EList<Transition> _outgoing = _target_1.getOutgoing();
          for (final Transition _forkTransition : _outgoing) {
            {
              finitestatemachinestimed.State _target_2 = _forkTransition.getTarget();
              this.currentState.add(_target_2);
              EList<finitestatemachinestimed.State> _currentState = StateMachineAspect.currentState(this.stateMachine);
              finitestatemachinestimed.State _target_3 = _forkTransition.getTarget();
              _currentState.add(_target_3);
              finitestatemachinestimed.State _target_4 = _forkTransition.getTarget();
              ForkThread _forkThread = new ForkThread(_target_4, context);
              threads.add(_forkThread);
              _forkThread.start();
            }
          }
          boolean threadsAlive = true;
          while (threadsAlive) {
            {
              int stillAlive = 0;
              for (final Thread _thread : threads) {
                boolean _isAlive = _thread.isAlive();
                if (_isAlive) {
                  stillAlive++;
                }
              }
              if ((stillAlive == 0)) {
                threadsAlive = false;
              }
            }
          }
        } else {
          finitestatemachinestimed.State _target_2 = _transition.getTarget();
          this.currentState.add(_target_2);
          EList<finitestatemachinestimed.State> _currentState = StateMachineAspect.currentState(this.stateMachine);
          finitestatemachinestimed.State _target_3 = _transition.getTarget();
          _currentState.add(_target_3);
          finitestatemachinestimed.State _target_4 = _transition.getTarget();
          StateAspect.eval(_target_4, context);
        }
      }
    }
    EList<finitestatemachinestimed.State> toAdd = new BasicEList<finitestatemachinestimed.State>();
    EList<finitestatemachinestimed.State> toRemove = new BasicEList<finitestatemachinestimed.State>();
    for (final finitestatemachinestimed.State _state : this.currentState) {
      boolean _and = false;
      EList<Transition> _outgoing = _state.getOutgoing();
      int _size = _outgoing.size();
      boolean _greaterThan = (_size > 0);
      if (!_greaterThan) {
        _and = false;
      } else {
        EList<Transition> _outgoing_1 = _state.getOutgoing();
        Transition _get = _outgoing_1.get(0);
        finitestatemachinestimed.State _target = _get.getTarget();
        _and = (_target instanceof Join);
      }
      if (_and) {
        boolean _and_1 = false;
        EList<Transition> _outgoing_2 = _state.getOutgoing();
        Transition _get_1 = _outgoing_2.get(0);
        finitestatemachinestimed.State _target_1 = _get_1.getTarget();
        boolean _contains = toAdd.contains(_target_1);
        boolean _not = (!_contains);
        if (!_not) {
          _and_1 = false;
        } else {
          EList<Transition> _outgoing_3 = _state.getOutgoing();
          Transition _get_2 = _outgoing_3.get(0);
          finitestatemachinestimed.State _target_2 = _get_2.getTarget();
          boolean _contains_1 = this.currentState.contains(_target_2);
          boolean _not_1 = (!_contains_1);
          _and_1 = _not_1;
        }
        if (_and_1) {
          EList<Transition> _outgoing_4 = _state.getOutgoing();
          Transition _get_3 = _outgoing_4.get(0);
          finitestatemachinestimed.State _target_3 = _get_3.getTarget();
          toAdd.add(_target_3);
        }
        boolean _contains_2 = toRemove.contains(_state);
        boolean _not_2 = (!_contains_2);
        if (_not_2) {
          toRemove.add(_state);
        }
      }
    }
    this.currentState.removeAll(toRemove);
    this.currentState.addAll(toAdd);
    StateMachineAspect.removeCurrentStates(this.stateMachine, toRemove);
    StateMachineAspect.addCurrentStates(this.stateMachine, toAdd);
  }
}
