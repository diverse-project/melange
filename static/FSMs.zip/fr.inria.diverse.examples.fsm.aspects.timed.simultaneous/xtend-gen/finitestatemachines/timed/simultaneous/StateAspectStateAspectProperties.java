package finitestatemachines.timed.simultaneous;

@SuppressWarnings("all")
public class StateAspectStateAspectProperties {
}
