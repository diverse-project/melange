package finitestatemachines.timed.composite.simultaneous;

import FSM.interfaces.Context;
import finitestatemachines.timed.composite.simultaneous.StateAspect;

@SuppressWarnings("all")
public class ForkThread extends Thread {
  private finitestatemachinestimedcomposite.State state;
  
  private Context context;
  
  public ForkThread(final finitestatemachinestimedcomposite.State _state, final Context _context) {
    this.state = _state;
    this.context = _context;
  }
  
  public void run() {
    StateAspect.eval(this.state, this.context);
  }
}
