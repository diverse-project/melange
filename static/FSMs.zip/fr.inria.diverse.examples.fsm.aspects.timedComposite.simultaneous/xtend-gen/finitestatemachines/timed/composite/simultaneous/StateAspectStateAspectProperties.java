package finitestatemachines.timed.composite.simultaneous;

@SuppressWarnings("all")
public class StateAspectStateAspectProperties {
}
