package org.k3.lua.dynamic;

import activitydiagram.Functioncall_Arguments;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectProperties;

@Aspect(className = Functioncall_Arguments.class)
@SuppressWarnings("all")
public class Functioncall_ArgumentsAspect {
  public static void execute(final Functioncall_Arguments _self, final Environment c) {
    org.k3.lua.dynamic.Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectProperties _self_ = org.k3.lua.dynamic.Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectContext.getSelf(_self);
    _privk3_execute(_self_, _self,c);
  }
  
  protected static void _privk3_execute(final Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectProperties _self_, final Functioncall_Arguments _self, final Environment c) {
  }
}
