package org.k3.lua.dynamic;

import activitydiagram.Expression_False;
import java.util.Map;
import org.k3.lua.dynamic.Expression_FalseAspectExpression_FalseAspectProperties;

@SuppressWarnings("all")
public class Expression_FalseAspectExpression_FalseAspectContext {
  public final static Expression_FalseAspectExpression_FalseAspectContext INSTANCE = new Expression_FalseAspectExpression_FalseAspectContext();
  
  public static Expression_FalseAspectExpression_FalseAspectProperties getSelf(final Expression_False _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_FalseAspectExpression_FalseAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_False, Expression_FalseAspectExpression_FalseAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_False, org.k3.lua.dynamic.Expression_FalseAspectExpression_FalseAspectProperties>();
  
  public Map<Expression_False, Expression_FalseAspectExpression_FalseAspectProperties> getMap() {
    return map;
  }
}
