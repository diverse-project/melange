package org.k3.lua.dynamic;

import activitydiagram.Field_AddEntryToTable_Brackets;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.FieldAspect;
import org.k3.lua.dynamic.Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectProperties;

@Aspect(className = Field_AddEntryToTable_Brackets.class)
@SuppressWarnings("all")
public class Field_AddEntryToTable_BracketsAspect extends FieldAspect {
  public static void execute(final Field_AddEntryToTable_Brackets _self, final Environment c) {
    org.k3.lua.dynamic.Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectProperties _self_ = org.k3.lua.dynamic.Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Field_AddEntryToTable_Brackets){
     org.k3.lua.dynamic.Field_AddEntryToTable_BracketsAspect._privk3_execute(_self_, (activitydiagram.Field_AddEntryToTable_Brackets)_self,c);
    } else  if (_self instanceof activitydiagram.Field){
     org.k3.lua.dynamic.FieldAspect.execute((activitydiagram.Field)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectProperties _self_, final Field_AddEntryToTable_Brackets _self, final Environment c) {
  }
}
