package org.k3.lua.dynamic;

import activitydiagram.Expression_Function;
import java.util.Map;
import org.k3.lua.dynamic.Expression_FunctionAspectExpression_FunctionAspectProperties;

@SuppressWarnings("all")
public class Expression_FunctionAspectExpression_FunctionAspectContext {
  public final static Expression_FunctionAspectExpression_FunctionAspectContext INSTANCE = new Expression_FunctionAspectExpression_FunctionAspectContext();
  
  public static Expression_FunctionAspectExpression_FunctionAspectProperties getSelf(final Expression_Function _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_FunctionAspectExpression_FunctionAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Function, Expression_FunctionAspectExpression_FunctionAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Function, org.k3.lua.dynamic.Expression_FunctionAspectExpression_FunctionAspectProperties>();
  
  public Map<Expression_Function, Expression_FunctionAspectExpression_FunctionAspectProperties> getMap() {
    return map;
  }
}
