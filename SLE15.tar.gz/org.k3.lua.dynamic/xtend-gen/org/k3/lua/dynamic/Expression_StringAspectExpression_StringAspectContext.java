package org.k3.lua.dynamic;

import activitydiagram.Expression_String;
import java.util.Map;
import org.k3.lua.dynamic.Expression_StringAspectExpression_StringAspectProperties;

@SuppressWarnings("all")
public class Expression_StringAspectExpression_StringAspectContext {
  public final static Expression_StringAspectExpression_StringAspectContext INSTANCE = new Expression_StringAspectExpression_StringAspectContext();
  
  public static Expression_StringAspectExpression_StringAspectProperties getSelf(final Expression_String _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_StringAspectExpression_StringAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_String, Expression_StringAspectExpression_StringAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_String, org.k3.lua.dynamic.Expression_StringAspectExpression_StringAspectProperties>();
  
  public Map<Expression_String, Expression_StringAspectExpression_StringAspectProperties> getMap() {
    return map;
  }
}
