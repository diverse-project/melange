package org.k3.lua.dynamic;

import activitydiagram.Field_AppendEntryToTable;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.FieldAspect;
import org.k3.lua.dynamic.Field_AppendEntryToTableAspectField_AppendEntryToTableAspectProperties;

@Aspect(className = Field_AppendEntryToTable.class)
@SuppressWarnings("all")
public class Field_AppendEntryToTableAspect extends FieldAspect {
  public static void execute(final Field_AppendEntryToTable _self, final Environment c) {
    org.k3.lua.dynamic.Field_AppendEntryToTableAspectField_AppendEntryToTableAspectProperties _self_ = org.k3.lua.dynamic.Field_AppendEntryToTableAspectField_AppendEntryToTableAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Field_AppendEntryToTable){
     org.k3.lua.dynamic.Field_AppendEntryToTableAspect._privk3_execute(_self_, (activitydiagram.Field_AppendEntryToTable)_self,c);
    } else  if (_self instanceof activitydiagram.Field){
     org.k3.lua.dynamic.FieldAspect.execute((activitydiagram.Field)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Field_AppendEntryToTableAspectField_AppendEntryToTableAspectProperties _self_, final Field_AppendEntryToTable _self, final Environment c) {
  }
}
