package org.k3.lua.dynamic;

import activitydiagram.Expression_Number;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.ExpressionAspect;
import org.k3.lua.dynamic.Expression_NumberAspectExpression_NumberAspectProperties;

@Aspect(className = Expression_Number.class)
@SuppressWarnings("all")
public class Expression_NumberAspect extends ExpressionAspect {
  public static void execute(final Expression_Number _self, final Environment c) {
    org.k3.lua.dynamic.Expression_NumberAspectExpression_NumberAspectProperties _self_ = org.k3.lua.dynamic.Expression_NumberAspectExpression_NumberAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Expression_Number){
     org.k3.lua.dynamic.Expression_NumberAspect._privk3_execute(_self_, (activitydiagram.Expression_Number)_self,c);
    } else  if (_self instanceof activitydiagram.Expression){
     org.k3.lua.dynamic.ExpressionAspect.execute((activitydiagram.Expression)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_FunctioncallOrAssignment){
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect.execute((activitydiagram.Statement_FunctioncallOrAssignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect.execute((activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Expression_NumberAspectExpression_NumberAspectProperties _self_, final Expression_Number _self, final Environment c) {
    double _value = _self.getValue();
    c.values.push(Double.valueOf(_value));
  }
}
