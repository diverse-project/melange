package org.k3.lua.dynamic;

import activitydiagram.Expression_Plus;
import java.util.Map;
import org.k3.lua.dynamic.Expression_PlusAspectExpression_PlusAspectProperties;

@SuppressWarnings("all")
public class Expression_PlusAspectExpression_PlusAspectContext {
  public final static Expression_PlusAspectExpression_PlusAspectContext INSTANCE = new Expression_PlusAspectExpression_PlusAspectContext();
  
  public static Expression_PlusAspectExpression_PlusAspectProperties getSelf(final Expression_Plus _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_PlusAspectExpression_PlusAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Plus, Expression_PlusAspectExpression_PlusAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Plus, org.k3.lua.dynamic.Expression_PlusAspectExpression_PlusAspectProperties>();
  
  public Map<Expression_Plus, Expression_PlusAspectExpression_PlusAspectProperties> getMap() {
    return map;
  }
}
