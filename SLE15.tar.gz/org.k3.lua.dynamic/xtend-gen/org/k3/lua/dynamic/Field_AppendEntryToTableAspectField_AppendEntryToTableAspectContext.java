package org.k3.lua.dynamic;

import activitydiagram.Field_AppendEntryToTable;
import java.util.Map;
import org.k3.lua.dynamic.Field_AppendEntryToTableAspectField_AppendEntryToTableAspectProperties;

@SuppressWarnings("all")
public class Field_AppendEntryToTableAspectField_AppendEntryToTableAspectContext {
  public final static Field_AppendEntryToTableAspectField_AppendEntryToTableAspectContext INSTANCE = new Field_AppendEntryToTableAspectField_AppendEntryToTableAspectContext();
  
  public static Field_AppendEntryToTableAspectField_AppendEntryToTableAspectProperties getSelf(final Field_AppendEntryToTable _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Field_AppendEntryToTableAspectField_AppendEntryToTableAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Field_AppendEntryToTable, Field_AppendEntryToTableAspectField_AppendEntryToTableAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Field_AppendEntryToTable, org.k3.lua.dynamic.Field_AppendEntryToTableAspectField_AppendEntryToTableAspectProperties>();
  
  public Map<Field_AppendEntryToTable, Field_AppendEntryToTableAspectField_AppendEntryToTableAspectProperties> getMap() {
    return map;
  }
}
