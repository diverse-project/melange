package org.k3.lua.dynamic;

import activitydiagram.Chunk;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.ChunkAspectChunkAspectProperties;
import org.k3.lua.dynamic.Environment;

@Aspect(className = Chunk.class)
@SuppressWarnings("all")
public class ChunkAspect {
  public static void execute(final Chunk _self, final Environment c) {
    org.k3.lua.dynamic.ChunkAspectChunkAspectProperties _self_ = org.k3.lua.dynamic.ChunkAspectChunkAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Block){
     org.k3.lua.dynamic.BlockAspect.execute((activitydiagram.Block)_self,c);
    } else  if (_self instanceof activitydiagram.Chunk){
     org.k3.lua.dynamic.ChunkAspect._privk3_execute(_self_, (activitydiagram.Chunk)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final ChunkAspectChunkAspectProperties _self_, final Chunk _self, final Environment c) {
  }
}
