package org.k3.lua.dynamic;

@SuppressWarnings("all")
public class LastStatement_BreakAspectLastStatement_BreakAspectProperties {
}
