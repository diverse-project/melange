package org.k3.lua.dynamic;

@SuppressWarnings("all")
public class FieldAspectFieldAspectProperties {
}
