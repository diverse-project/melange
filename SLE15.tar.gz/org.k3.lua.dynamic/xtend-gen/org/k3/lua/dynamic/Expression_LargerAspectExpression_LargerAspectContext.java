package org.k3.lua.dynamic;

import activitydiagram.Expression_Larger;
import java.util.Map;
import org.k3.lua.dynamic.Expression_LargerAspectExpression_LargerAspectProperties;

@SuppressWarnings("all")
public class Expression_LargerAspectExpression_LargerAspectContext {
  public final static Expression_LargerAspectExpression_LargerAspectContext INSTANCE = new Expression_LargerAspectExpression_LargerAspectContext();
  
  public static Expression_LargerAspectExpression_LargerAspectProperties getSelf(final Expression_Larger _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_LargerAspectExpression_LargerAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Larger, Expression_LargerAspectExpression_LargerAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Larger, org.k3.lua.dynamic.Expression_LargerAspectExpression_LargerAspectProperties>();
  
  public Map<Expression_Larger, Expression_LargerAspectExpression_LargerAspectProperties> getMap() {
    return map;
  }
}
