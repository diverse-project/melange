package org.k3.lua.dynamic;

import activitydiagram.Expression;
import activitydiagram.Expression_Multiplication;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.xtext.xbase.lib.DoubleExtensions;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.ExpressionAspect;
import org.k3.lua.dynamic.Expression_MultiplicationAspectExpression_MultiplicationAspectProperties;

@Aspect(className = Expression_Multiplication.class)
@SuppressWarnings("all")
public class Expression_MultiplicationAspect extends ExpressionAspect {
  public static void execute(final Expression_Multiplication _self, final Environment c) {
    org.k3.lua.dynamic.Expression_MultiplicationAspectExpression_MultiplicationAspectProperties _self_ = org.k3.lua.dynamic.Expression_MultiplicationAspectExpression_MultiplicationAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Expression_Multiplication){
     org.k3.lua.dynamic.Expression_MultiplicationAspect._privk3_execute(_self_, (activitydiagram.Expression_Multiplication)_self,c);
    } else  if (_self instanceof activitydiagram.Expression){
     org.k3.lua.dynamic.ExpressionAspect.execute((activitydiagram.Expression)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_FunctioncallOrAssignment){
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect.execute((activitydiagram.Statement_FunctioncallOrAssignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect.execute((activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Expression_MultiplicationAspectExpression_MultiplicationAspectProperties _self_, final Expression_Multiplication _self, final Environment c) {
    Expression _left = _self.getLeft();
    ExpressionAspect.execute(_left, c);
    Object _pop = c.values.pop();
    Double left = ((Double) _pop);
    Expression _right = _self.getRight();
    ExpressionAspect.execute(_right, c);
    Object _pop_1 = c.values.pop();
    Double right = ((Double) _pop_1);
    double _multiply = DoubleExtensions.operator_multiply(left, right);
    c.values.push(Double.valueOf(_multiply));
  }
}
