package org.k3.lua.dynamic;

import activitydiagram.Field;
import java.util.Map;
import org.k3.lua.dynamic.FieldAspectFieldAspectProperties;

@SuppressWarnings("all")
public class FieldAspectFieldAspectContext {
  public final static FieldAspectFieldAspectContext INSTANCE = new FieldAspectFieldAspectContext();
  
  public static FieldAspectFieldAspectProperties getSelf(final Field _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.FieldAspectFieldAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Field, FieldAspectFieldAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Field, org.k3.lua.dynamic.FieldAspectFieldAspectProperties>();
  
  public Map<Field, FieldAspectFieldAspectProperties> getMap() {
    return map;
  }
}
