package org.k3.lua.dynamic;

import activitydiagram.Expression_Number;
import java.util.Map;
import org.k3.lua.dynamic.Expression_NumberAspectExpression_NumberAspectProperties;

@SuppressWarnings("all")
public class Expression_NumberAspectExpression_NumberAspectContext {
  public final static Expression_NumberAspectExpression_NumberAspectContext INSTANCE = new Expression_NumberAspectExpression_NumberAspectContext();
  
  public static Expression_NumberAspectExpression_NumberAspectProperties getSelf(final Expression_Number _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_NumberAspectExpression_NumberAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Number, Expression_NumberAspectExpression_NumberAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Number, org.k3.lua.dynamic.Expression_NumberAspectExpression_NumberAspectProperties>();
  
  public Map<Expression_Number, Expression_NumberAspectExpression_NumberAspectProperties> getMap() {
    return map;
  }
}
