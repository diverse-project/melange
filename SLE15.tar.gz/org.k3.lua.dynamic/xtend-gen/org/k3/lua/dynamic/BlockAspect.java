package org.k3.lua.dynamic;

import activitydiagram.Block;
import activitydiagram.LastStatement;
import activitydiagram.Statement;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.EList;
import org.k3.lua.dynamic.BlockAspectBlockAspectProperties;
import org.k3.lua.dynamic.ChunkAspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.LastStatementAspect;
import org.k3.lua.dynamic.StatementAspect;

@Aspect(className = Block.class)
@SuppressWarnings("all")
public class BlockAspect extends ChunkAspect {
  @OverrideAspectMethod
  public static void execute(final Block _self, final Environment c) {
    org.k3.lua.dynamic.BlockAspectBlockAspectProperties _self_ = org.k3.lua.dynamic.BlockAspectBlockAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Block){
     org.k3.lua.dynamic.BlockAspect._privk3_execute(_self_, (activitydiagram.Block)_self,c);
    } else  if (_self instanceof activitydiagram.Chunk){
     org.k3.lua.dynamic.ChunkAspect.execute((activitydiagram.Chunk)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  private static void super_execute(final Block _self, final Environment c) {
    org.k3.lua.dynamic.ChunkAspectChunkAspectProperties _self_ = org.k3.lua.dynamic.ChunkAspectChunkAspectContext.getSelf(_self);
     org.k3.lua.dynamic.ChunkAspect._privk3_execute(_self_, _self,c);
  }
  
  protected static void _privk3_execute(final BlockAspectBlockAspectProperties _self_, final Block _self, final Environment c) {
    EList<Statement> _statements = _self.getStatements();
    final Consumer<Statement> _function = (Statement s) -> {
      StatementAspect.execute(s, c);
    };
    _statements.forEach(_function);
    LastStatement _returnValue = _self.getReturnValue();
    if (_returnValue!=null) {
      LastStatementAspect.execute(_returnValue, c);
    }
  }
}
