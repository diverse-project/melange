package org.k3.lua.dynamic;

import activitydiagram.Chunk;
import java.util.Map;
import org.k3.lua.dynamic.ChunkAspectChunkAspectProperties;

@SuppressWarnings("all")
public class ChunkAspectChunkAspectContext {
  public final static ChunkAspectChunkAspectContext INSTANCE = new ChunkAspectChunkAspectContext();
  
  public static ChunkAspectChunkAspectProperties getSelf(final Chunk _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.ChunkAspectChunkAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Chunk, ChunkAspectChunkAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Chunk, org.k3.lua.dynamic.ChunkAspectChunkAspectProperties>();
  
  public Map<Chunk, ChunkAspectChunkAspectProperties> getMap() {
    return map;
  }
}
