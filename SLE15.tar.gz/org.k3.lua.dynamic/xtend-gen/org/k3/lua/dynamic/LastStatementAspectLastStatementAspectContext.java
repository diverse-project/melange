package org.k3.lua.dynamic;

import activitydiagram.LastStatement;
import java.util.Map;
import org.k3.lua.dynamic.LastStatementAspectLastStatementAspectProperties;

@SuppressWarnings("all")
public class LastStatementAspectLastStatementAspectContext {
  public final static LastStatementAspectLastStatementAspectContext INSTANCE = new LastStatementAspectLastStatementAspectContext();
  
  public static LastStatementAspectLastStatementAspectProperties getSelf(final LastStatement _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.LastStatementAspectLastStatementAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<LastStatement, LastStatementAspectLastStatementAspectProperties> map = new java.util.WeakHashMap<activitydiagram.LastStatement, org.k3.lua.dynamic.LastStatementAspectLastStatementAspectProperties>();
  
  public Map<LastStatement, LastStatementAspectLastStatementAspectProperties> getMap() {
    return map;
  }
}
