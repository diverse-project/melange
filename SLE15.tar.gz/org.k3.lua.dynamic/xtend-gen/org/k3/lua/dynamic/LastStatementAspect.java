package org.k3.lua.dynamic;

import activitydiagram.LastStatement;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.LastStatementAspectLastStatementAspectProperties;

@Aspect(className = LastStatement.class)
@SuppressWarnings("all")
public class LastStatementAspect {
  public static void execute(final LastStatement _self, final Environment c) {
    org.k3.lua.dynamic.LastStatementAspectLastStatementAspectProperties _self_ = org.k3.lua.dynamic.LastStatementAspectLastStatementAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.LastStatement_ReturnWithValue){
     org.k3.lua.dynamic.LastStatement_ReturnWithValueAspect.execute((activitydiagram.LastStatement_ReturnWithValue)_self,c);
    } else  if (_self instanceof activitydiagram.LastStatement_Return){
     org.k3.lua.dynamic.LastStatement_ReturnAspect.execute((activitydiagram.LastStatement_Return)_self,c);
    } else  if (_self instanceof activitydiagram.LastStatement){
     org.k3.lua.dynamic.LastStatementAspect._privk3_execute(_self_, (activitydiagram.LastStatement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final LastStatementAspectLastStatementAspectProperties _self_, final LastStatement _self, final Environment c) {
  }
}
