package org.k3.lua.dynamic;

import activitydiagram.Statement_CallFunction;
import java.util.Map;
import org.k3.lua.dynamic.Statement_CallFunctionAspectStatement_CallFunctionAspectProperties;

@SuppressWarnings("all")
public class Statement_CallFunctionAspectStatement_CallFunctionAspectContext {
  public final static Statement_CallFunctionAspectStatement_CallFunctionAspectContext INSTANCE = new Statement_CallFunctionAspectStatement_CallFunctionAspectContext();
  
  public static Statement_CallFunctionAspectStatement_CallFunctionAspectProperties getSelf(final Statement_CallFunction _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Statement_CallFunctionAspectStatement_CallFunctionAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Statement_CallFunction, Statement_CallFunctionAspectStatement_CallFunctionAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Statement_CallFunction, org.k3.lua.dynamic.Statement_CallFunctionAspectStatement_CallFunctionAspectProperties>();
  
  public Map<Statement_CallFunction, Statement_CallFunctionAspectStatement_CallFunctionAspectProperties> getMap() {
    return map;
  }
}
