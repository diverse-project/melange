package org.k3.lua.dynamic;

import activitydiagram.Expression_Length;
import java.util.Map;
import org.k3.lua.dynamic.Expression_LengthAspectExpression_LengthAspectProperties;

@SuppressWarnings("all")
public class Expression_LengthAspectExpression_LengthAspectContext {
  public final static Expression_LengthAspectExpression_LengthAspectContext INSTANCE = new Expression_LengthAspectExpression_LengthAspectContext();
  
  public static Expression_LengthAspectExpression_LengthAspectProperties getSelf(final Expression_Length _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_LengthAspectExpression_LengthAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Length, Expression_LengthAspectExpression_LengthAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Length, org.k3.lua.dynamic.Expression_LengthAspectExpression_LengthAspectProperties>();
  
  public Map<Expression_Length, Expression_LengthAspectExpression_LengthAspectProperties> getMap() {
    return map;
  }
}
