package org.k3.lua.dynamic;

import activitydiagram.Expression_CallMemberFunction;
import java.util.Map;
import org.k3.lua.dynamic.Expression_CallMemberFunctionAspectExpression_CallMemberFunctionAspectProperties;

@SuppressWarnings("all")
public class Expression_CallMemberFunctionAspectExpression_CallMemberFunctionAspectContext {
  public final static Expression_CallMemberFunctionAspectExpression_CallMemberFunctionAspectContext INSTANCE = new Expression_CallMemberFunctionAspectExpression_CallMemberFunctionAspectContext();
  
  public static Expression_CallMemberFunctionAspectExpression_CallMemberFunctionAspectProperties getSelf(final Expression_CallMemberFunction _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_CallMemberFunctionAspectExpression_CallMemberFunctionAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_CallMemberFunction, Expression_CallMemberFunctionAspectExpression_CallMemberFunctionAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_CallMemberFunction, org.k3.lua.dynamic.Expression_CallMemberFunctionAspectExpression_CallMemberFunctionAspectProperties>();
  
  public Map<Expression_CallMemberFunction, Expression_CallMemberFunctionAspectExpression_CallMemberFunctionAspectProperties> getMap() {
    return map;
  }
}
