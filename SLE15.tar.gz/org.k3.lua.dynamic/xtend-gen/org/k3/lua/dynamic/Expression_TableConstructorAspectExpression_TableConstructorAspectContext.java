package org.k3.lua.dynamic;

import activitydiagram.Expression_TableConstructor;
import java.util.Map;
import org.k3.lua.dynamic.Expression_TableConstructorAspectExpression_TableConstructorAspectProperties;

@SuppressWarnings("all")
public class Expression_TableConstructorAspectExpression_TableConstructorAspectContext {
  public final static Expression_TableConstructorAspectExpression_TableConstructorAspectContext INSTANCE = new Expression_TableConstructorAspectExpression_TableConstructorAspectContext();
  
  public static Expression_TableConstructorAspectExpression_TableConstructorAspectProperties getSelf(final Expression_TableConstructor _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_TableConstructorAspectExpression_TableConstructorAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_TableConstructor, Expression_TableConstructorAspectExpression_TableConstructorAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_TableConstructor, org.k3.lua.dynamic.Expression_TableConstructorAspectExpression_TableConstructorAspectProperties>();
  
  public Map<Expression_TableConstructor, Expression_TableConstructorAspectExpression_TableConstructorAspectProperties> getMap() {
    return map;
  }
}
