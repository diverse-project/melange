package org.k3.lua.dynamic;

import activitydiagram.Expression_Larger_Equal;
import java.util.Map;
import org.k3.lua.dynamic.Expression_Larger_EqualAspectExpression_Larger_EqualAspectProperties;

@SuppressWarnings("all")
public class Expression_Larger_EqualAspectExpression_Larger_EqualAspectContext {
  public final static Expression_Larger_EqualAspectExpression_Larger_EqualAspectContext INSTANCE = new Expression_Larger_EqualAspectExpression_Larger_EqualAspectContext();
  
  public static Expression_Larger_EqualAspectExpression_Larger_EqualAspectProperties getSelf(final Expression_Larger_Equal _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_Larger_EqualAspectExpression_Larger_EqualAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Larger_Equal, Expression_Larger_EqualAspectExpression_Larger_EqualAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Larger_Equal, org.k3.lua.dynamic.Expression_Larger_EqualAspectExpression_Larger_EqualAspectProperties>();
  
  public Map<Expression_Larger_Equal, Expression_Larger_EqualAspectExpression_Larger_EqualAspectProperties> getMap() {
    return map;
  }
}
