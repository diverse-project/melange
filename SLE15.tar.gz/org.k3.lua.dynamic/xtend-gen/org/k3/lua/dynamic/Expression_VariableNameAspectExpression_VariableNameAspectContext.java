package org.k3.lua.dynamic;

import activitydiagram.Expression_VariableName;
import java.util.Map;
import org.k3.lua.dynamic.Expression_VariableNameAspectExpression_VariableNameAspectProperties;

@SuppressWarnings("all")
public class Expression_VariableNameAspectExpression_VariableNameAspectContext {
  public final static Expression_VariableNameAspectExpression_VariableNameAspectContext INSTANCE = new Expression_VariableNameAspectExpression_VariableNameAspectContext();
  
  public static Expression_VariableNameAspectExpression_VariableNameAspectProperties getSelf(final Expression_VariableName _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_VariableNameAspectExpression_VariableNameAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_VariableName, Expression_VariableNameAspectExpression_VariableNameAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_VariableName, org.k3.lua.dynamic.Expression_VariableNameAspectExpression_VariableNameAspectProperties>();
  
  public Map<Expression_VariableName, Expression_VariableNameAspectExpression_VariableNameAspectProperties> getMap() {
    return map;
  }
}
