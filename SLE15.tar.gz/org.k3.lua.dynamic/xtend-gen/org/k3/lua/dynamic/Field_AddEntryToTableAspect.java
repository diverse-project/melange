package org.k3.lua.dynamic;

import activitydiagram.Field_AddEntryToTable;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.FieldAspect;
import org.k3.lua.dynamic.Field_AddEntryToTableAspectField_AddEntryToTableAspectProperties;

@Aspect(className = Field_AddEntryToTable.class)
@SuppressWarnings("all")
public class Field_AddEntryToTableAspect extends FieldAspect {
  public static void execute(final Field_AddEntryToTable _self, final Environment c) {
    org.k3.lua.dynamic.Field_AddEntryToTableAspectField_AddEntryToTableAspectProperties _self_ = org.k3.lua.dynamic.Field_AddEntryToTableAspectField_AddEntryToTableAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Field_AddEntryToTable){
     org.k3.lua.dynamic.Field_AddEntryToTableAspect._privk3_execute(_self_, (activitydiagram.Field_AddEntryToTable)_self,c);
    } else  if (_self instanceof activitydiagram.Field){
     org.k3.lua.dynamic.FieldAspect.execute((activitydiagram.Field)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Field_AddEntryToTableAspectField_AddEntryToTableAspectProperties _self_, final Field_AddEntryToTable _self, final Environment c) {
  }
}
