package org.k3.lua.dynamic;

import activitydiagram.Expression_And;
import java.util.Map;
import org.k3.lua.dynamic.Expression_AndAspectExpression_AndAspectProperties;

@SuppressWarnings("all")
public class Expression_AndAspectExpression_AndAspectContext {
  public final static Expression_AndAspectExpression_AndAspectContext INSTANCE = new Expression_AndAspectExpression_AndAspectContext();
  
  public static Expression_AndAspectExpression_AndAspectProperties getSelf(final Expression_And _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_AndAspectExpression_AndAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_And, Expression_AndAspectExpression_AndAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_And, org.k3.lua.dynamic.Expression_AndAspectExpression_AndAspectProperties>();
  
  public Map<Expression_And, Expression_AndAspectExpression_AndAspectProperties> getMap() {
    return map;
  }
}
