package org.k3.lua.dynamic;

import activitydiagram.Functioncall_Arguments;
import java.util.Map;
import org.k3.lua.dynamic.Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectProperties;

@SuppressWarnings("all")
public class Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectContext {
  public final static Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectContext INSTANCE = new Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectContext();
  
  public static Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectProperties getSelf(final Functioncall_Arguments _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Functioncall_Arguments, Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Functioncall_Arguments, org.k3.lua.dynamic.Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectProperties>();
  
  public Map<Functioncall_Arguments, Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectProperties> getMap() {
    return map;
  }
}
