package org.k3.lua.dynamic;

import activitydiagram.Expression_CallFunction;
import java.util.Map;
import org.k3.lua.dynamic.Expression_CallFunctionAspectExpression_CallFunctionAspectProperties;

@SuppressWarnings("all")
public class Expression_CallFunctionAspectExpression_CallFunctionAspectContext {
  public final static Expression_CallFunctionAspectExpression_CallFunctionAspectContext INSTANCE = new Expression_CallFunctionAspectExpression_CallFunctionAspectContext();
  
  public static Expression_CallFunctionAspectExpression_CallFunctionAspectProperties getSelf(final Expression_CallFunction _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_CallFunctionAspectExpression_CallFunctionAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_CallFunction, Expression_CallFunctionAspectExpression_CallFunctionAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_CallFunction, org.k3.lua.dynamic.Expression_CallFunctionAspectExpression_CallFunctionAspectProperties>();
  
  public Map<Expression_CallFunction, Expression_CallFunctionAspectExpression_CallFunctionAspectProperties> getMap() {
    return map;
  }
}
