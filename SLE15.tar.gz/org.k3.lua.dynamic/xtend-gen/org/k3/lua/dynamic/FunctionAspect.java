package org.k3.lua.dynamic;

import activitydiagram.Function;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.FunctionAspectFunctionAspectProperties;

@Aspect(className = Function.class)
@SuppressWarnings("all")
public class FunctionAspect {
  public static void execute(final Function _self, final Environment c) {
    org.k3.lua.dynamic.FunctionAspectFunctionAspectProperties _self_ = org.k3.lua.dynamic.FunctionAspectFunctionAspectContext.getSelf(_self);
    _privk3_execute(_self_, _self,c);
  }
  
  protected static void _privk3_execute(final FunctionAspectFunctionAspectProperties _self_, final Function _self, final Environment c) {
  }
}
