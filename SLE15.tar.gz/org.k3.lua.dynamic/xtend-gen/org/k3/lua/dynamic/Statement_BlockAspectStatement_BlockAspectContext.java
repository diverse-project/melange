package org.k3.lua.dynamic;

import activitydiagram.Statement_Block;
import java.util.Map;
import org.k3.lua.dynamic.Statement_BlockAspectStatement_BlockAspectProperties;

@SuppressWarnings("all")
public class Statement_BlockAspectStatement_BlockAspectContext {
  public final static Statement_BlockAspectStatement_BlockAspectContext INSTANCE = new Statement_BlockAspectStatement_BlockAspectContext();
  
  public static Statement_BlockAspectStatement_BlockAspectProperties getSelf(final Statement_Block _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Statement_BlockAspectStatement_BlockAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Statement_Block, Statement_BlockAspectStatement_BlockAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Statement_Block, org.k3.lua.dynamic.Statement_BlockAspectStatement_BlockAspectProperties>();
  
  public Map<Statement_Block, Statement_BlockAspectStatement_BlockAspectProperties> getMap() {
    return map;
  }
}
