package org.k3.lua.dynamic;

import activitydiagram.Expression_Exponentiation;
import java.util.Map;
import org.k3.lua.dynamic.Expression_ExponentiationAspectExpression_ExponentiationAspectProperties;

@SuppressWarnings("all")
public class Expression_ExponentiationAspectExpression_ExponentiationAspectContext {
  public final static Expression_ExponentiationAspectExpression_ExponentiationAspectContext INSTANCE = new Expression_ExponentiationAspectExpression_ExponentiationAspectContext();
  
  public static Expression_ExponentiationAspectExpression_ExponentiationAspectProperties getSelf(final Expression_Exponentiation _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_ExponentiationAspectExpression_ExponentiationAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Exponentiation, Expression_ExponentiationAspectExpression_ExponentiationAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Exponentiation, org.k3.lua.dynamic.Expression_ExponentiationAspectExpression_ExponentiationAspectProperties>();
  
  public Map<Expression_Exponentiation, Expression_ExponentiationAspectExpression_ExponentiationAspectProperties> getMap() {
    return map;
  }
}
