package org.k3.lua.dynamic;

import activitydiagram.LastStatement_Return;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.LastStatementAspect;
import org.k3.lua.dynamic.LastStatement_ReturnAspectLastStatement_ReturnAspectProperties;

@Aspect(className = LastStatement_Return.class)
@SuppressWarnings("all")
public class LastStatement_ReturnAspect extends LastStatementAspect {
  public static void execute(final LastStatement_Return _self, final Environment c) {
    org.k3.lua.dynamic.LastStatement_ReturnAspectLastStatement_ReturnAspectProperties _self_ = org.k3.lua.dynamic.LastStatement_ReturnAspectLastStatement_ReturnAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.LastStatement_ReturnWithValue){
     org.k3.lua.dynamic.LastStatement_ReturnWithValueAspect.execute((activitydiagram.LastStatement_ReturnWithValue)_self,c);
    } else  if (_self instanceof activitydiagram.LastStatement_Return){
     org.k3.lua.dynamic.LastStatement_ReturnAspect._privk3_execute(_self_, (activitydiagram.LastStatement_Return)_self,c);
    } else  if (_self instanceof activitydiagram.LastStatement){
     org.k3.lua.dynamic.LastStatementAspect.execute((activitydiagram.LastStatement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final LastStatement_ReturnAspectLastStatement_ReturnAspectProperties _self_, final LastStatement_Return _self, final Environment c) {
  }
}
