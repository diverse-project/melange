package org.k3.lua.dynamic;

import activitydiagram.Expression;
import activitydiagram.Expression_Concatenation;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.ExpressionAspect;
import org.k3.lua.dynamic.Expression_ConcatenationAspectExpression_ConcatenationAspectProperties;

@Aspect(className = Expression_Concatenation.class)
@SuppressWarnings("all")
public class Expression_ConcatenationAspect extends ExpressionAspect {
  public static void execute(final Expression_Concatenation _self, final Environment c) {
    org.k3.lua.dynamic.Expression_ConcatenationAspectExpression_ConcatenationAspectProperties _self_ = org.k3.lua.dynamic.Expression_ConcatenationAspectExpression_ConcatenationAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Expression_Concatenation){
     org.k3.lua.dynamic.Expression_ConcatenationAspect._privk3_execute(_self_, (activitydiagram.Expression_Concatenation)_self,c);
    } else  if (_self instanceof activitydiagram.Expression){
     org.k3.lua.dynamic.ExpressionAspect.execute((activitydiagram.Expression)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_FunctioncallOrAssignment){
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect.execute((activitydiagram.Statement_FunctioncallOrAssignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect.execute((activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Expression_ConcatenationAspectExpression_ConcatenationAspectProperties _self_, final Expression_Concatenation _self, final Environment c) {
    Expression _left = _self.getLeft();
    ExpressionAspect.execute(_left, c);
    Object _pop = c.values.pop();
    String left = ((String) _pop);
    Expression _right = _self.getRight();
    ExpressionAspect.execute(_right, c);
    Object _pop_1 = c.values.pop();
    String right = ((String) _pop_1);
    c.values.push((left + right));
  }
}
