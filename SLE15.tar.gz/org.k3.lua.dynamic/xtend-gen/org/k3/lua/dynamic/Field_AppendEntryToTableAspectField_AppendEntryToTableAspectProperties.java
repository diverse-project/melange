package org.k3.lua.dynamic;

@SuppressWarnings("all")
public class Field_AppendEntryToTableAspectField_AppendEntryToTableAspectProperties {
}
