package org.k3.lua.dynamic;

import activitydiagram.Expression_Multiplication;
import java.util.Map;
import org.k3.lua.dynamic.Expression_MultiplicationAspectExpression_MultiplicationAspectProperties;

@SuppressWarnings("all")
public class Expression_MultiplicationAspectExpression_MultiplicationAspectContext {
  public final static Expression_MultiplicationAspectExpression_MultiplicationAspectContext INSTANCE = new Expression_MultiplicationAspectExpression_MultiplicationAspectContext();
  
  public static Expression_MultiplicationAspectExpression_MultiplicationAspectProperties getSelf(final Expression_Multiplication _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_MultiplicationAspectExpression_MultiplicationAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Multiplication, Expression_MultiplicationAspectExpression_MultiplicationAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Multiplication, org.k3.lua.dynamic.Expression_MultiplicationAspectExpression_MultiplicationAspectProperties>();
  
  public Map<Expression_Multiplication, Expression_MultiplicationAspectExpression_MultiplicationAspectProperties> getMap() {
    return map;
  }
}
