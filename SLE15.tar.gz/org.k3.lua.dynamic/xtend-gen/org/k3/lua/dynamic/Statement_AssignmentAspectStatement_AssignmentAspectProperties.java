package org.k3.lua.dynamic;

@SuppressWarnings("all")
public class Statement_AssignmentAspectStatement_AssignmentAspectProperties {
}
