package org.k3.lua.dynamic;

import activitydiagram.Expression_TableConstructor;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.ExpressionAspect;
import org.k3.lua.dynamic.Expression_TableConstructorAspectExpression_TableConstructorAspectProperties;

@Aspect(className = Expression_TableConstructor.class)
@SuppressWarnings("all")
public class Expression_TableConstructorAspect extends ExpressionAspect {
  public static void execute(final Expression_TableConstructor _self, final Environment c) {
    org.k3.lua.dynamic.Expression_TableConstructorAspectExpression_TableConstructorAspectProperties _self_ = org.k3.lua.dynamic.Expression_TableConstructorAspectExpression_TableConstructorAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Expression_TableConstructor){
     org.k3.lua.dynamic.Expression_TableConstructorAspect._privk3_execute(_self_, (activitydiagram.Expression_TableConstructor)_self,c);
    } else  if (_self instanceof activitydiagram.Expression){
     org.k3.lua.dynamic.ExpressionAspect.execute((activitydiagram.Expression)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_FunctioncallOrAssignment){
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect.execute((activitydiagram.Statement_FunctioncallOrAssignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect.execute((activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Expression_TableConstructorAspectExpression_TableConstructorAspectProperties _self_, final Expression_TableConstructor _self, final Environment c) {
  }
}
