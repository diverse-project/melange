package org.k3.lua.dynamic;

import activitydiagram.Expression_Division;
import java.util.Map;
import org.k3.lua.dynamic.Expression_DivisionAspectExpression_DivisionAspectProperties;

@SuppressWarnings("all")
public class Expression_DivisionAspectExpression_DivisionAspectContext {
  public final static Expression_DivisionAspectExpression_DivisionAspectContext INSTANCE = new Expression_DivisionAspectExpression_DivisionAspectContext();
  
  public static Expression_DivisionAspectExpression_DivisionAspectProperties getSelf(final Expression_Division _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_DivisionAspectExpression_DivisionAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Division, Expression_DivisionAspectExpression_DivisionAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Division, org.k3.lua.dynamic.Expression_DivisionAspectExpression_DivisionAspectProperties>();
  
  public Map<Expression_Division, Expression_DivisionAspectExpression_DivisionAspectProperties> getMap() {
    return map;
  }
}
