package org.k3.lua.dynamic;

import activitydiagram.Expression_Minus;
import java.util.Map;
import org.k3.lua.dynamic.Expression_MinusAspectExpression_MinusAspectProperties;

@SuppressWarnings("all")
public class Expression_MinusAspectExpression_MinusAspectContext {
  public final static Expression_MinusAspectExpression_MinusAspectContext INSTANCE = new Expression_MinusAspectExpression_MinusAspectContext();
  
  public static Expression_MinusAspectExpression_MinusAspectProperties getSelf(final Expression_Minus _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_MinusAspectExpression_MinusAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Minus, Expression_MinusAspectExpression_MinusAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Minus, org.k3.lua.dynamic.Expression_MinusAspectExpression_MinusAspectProperties>();
  
  public Map<Expression_Minus, Expression_MinusAspectExpression_MinusAspectProperties> getMap() {
    return map;
  }
}
