package org.k3.lua.dynamic;

import activitydiagram.ActivitydiagramPackage;
import activitydiagram.Block;
import activitydiagram.Chunk;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.xtext.resource.XtextResourceSet;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.k3.lua.dynamic.BlockAspect;
import org.k3.lua.dynamic.Environment;
import org.xtext.LuaStandaloneSetup;

@SuppressWarnings("all")
public class Main {
  protected XtextResourceSet resourceSet;
  
  protected ResourceSet resourceSetxmi;
  
  public static void main(final String[] args) {
    Main _main = new Main();
    _main.run(args);
  }
  
  public void run(final String[] args) {
    try {
      XtextResourceSet _xtextResourceSet = new XtextResourceSet();
      this.resourceSet = _xtextResourceSet;
      ResourceSetImpl _resourceSetImpl = new ResourceSetImpl();
      this.resourceSetxmi = _resourceSetImpl;
      LuaStandaloneSetup.doSetup();
      boolean _containsKey = EPackage.Registry.INSTANCE.containsKey(ActivitydiagramPackage.eNS_URI);
      boolean _not = (!_containsKey);
      if (_not) {
        EPackage.Registry.INSTANCE.put(ActivitydiagramPackage.eNS_URI, ActivitydiagramPackage.eINSTANCE);
      }
      Map<String, Object> _extensionToFactoryMap = Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap();
      XMIResourceFactoryImpl _xMIResourceFactoryImpl = new XMIResourceFactoryImpl();
      _extensionToFactoryMap.put("xmi", _xMIResourceFactoryImpl);
      Block block = this.getBlock("test.lua");
      URI _createFileURI = URI.createFileURI("text.xmi");
      Resource resource = this.resourceSetxmi.createResource(_createFileURI);
      EList<EObject> _contents = resource.getContents();
      _contents.add(block);
      HashMap<Object, Object> _hashMap = new HashMap<Object, Object>();
      resource.save(_hashMap);
      long start = System.nanoTime();
      Environment c = new Environment();
      BlockAspect.execute(block, c);
      long stop = System.nanoTime();
      InputOutput.<String>println(("time to execute " + Long.valueOf((stop - start))));
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public Block getBlock(final String modelPath) {
    URI _createFileURI = this.createFileURI(modelPath);
    Resource resource = this.resourceSet.getResource(_createFileURI, true);
    EList<EObject> _contents = resource.getContents();
    EObject eObject = _contents.get(0);
    if ((eObject instanceof Chunk)) {
      Block ch = ((Block) eObject);
      return ch;
    }
    return null;
  }
  
  public URI createFileURI(final String path) {
    File _createFile = this.createFile(path);
    String _absolutePath = _createFile.getAbsolutePath();
    return URI.createFileURI(_absolutePath);
  }
  
  public Chunk getActivityfromXMI(final String modelPath) {
    URI _createFileURI = this.createFileURI(modelPath);
    Resource resource = this.resourceSetxmi.getResource(_createFileURI, true);
    EList<EObject> _contents = resource.getContents();
    EObject eObject = _contents.get(0);
    if ((eObject instanceof Chunk)) {
      Chunk ch = ((Chunk) eObject);
      return ch;
    }
    return null;
  }
  
  public File createFile(final String path) {
    return new File(path);
  }
}
