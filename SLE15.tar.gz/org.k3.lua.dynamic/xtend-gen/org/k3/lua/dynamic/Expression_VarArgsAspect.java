package org.k3.lua.dynamic;

import activitydiagram.Expression_VarArgs;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.ExpressionAspect;
import org.k3.lua.dynamic.Expression_VarArgsAspectExpression_VarArgsAspectProperties;

@Aspect(className = Expression_VarArgs.class)
@SuppressWarnings("all")
public class Expression_VarArgsAspect extends ExpressionAspect {
  public static void execute(final Expression_VarArgs _self, final Environment c) {
    org.k3.lua.dynamic.Expression_VarArgsAspectExpression_VarArgsAspectProperties _self_ = org.k3.lua.dynamic.Expression_VarArgsAspectExpression_VarArgsAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Expression_VarArgs){
     org.k3.lua.dynamic.Expression_VarArgsAspect._privk3_execute(_self_, (activitydiagram.Expression_VarArgs)_self,c);
    } else  if (_self instanceof activitydiagram.Expression){
     org.k3.lua.dynamic.ExpressionAspect.execute((activitydiagram.Expression)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_FunctioncallOrAssignment){
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect.execute((activitydiagram.Statement_FunctioncallOrAssignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect.execute((activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Expression_VarArgsAspectExpression_VarArgsAspectProperties _self_, final Expression_VarArgs _self, final Environment c) {
  }
}
