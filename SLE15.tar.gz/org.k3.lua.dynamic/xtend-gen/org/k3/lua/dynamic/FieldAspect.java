package org.k3.lua.dynamic;

import activitydiagram.Field;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.FieldAspectFieldAspectProperties;

@Aspect(className = Field.class)
@SuppressWarnings("all")
public class FieldAspect {
  public static void execute(final Field _self, final Environment c) {
    org.k3.lua.dynamic.FieldAspectFieldAspectProperties _self_ = org.k3.lua.dynamic.FieldAspectFieldAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Field_AddEntryToTable){
     org.k3.lua.dynamic.Field_AddEntryToTableAspect.execute((activitydiagram.Field_AddEntryToTable)_self,c);
    } else  if (_self instanceof activitydiagram.Field_AppendEntryToTable){
     org.k3.lua.dynamic.Field_AppendEntryToTableAspect.execute((activitydiagram.Field_AppendEntryToTable)_self,c);
    } else  if (_self instanceof activitydiagram.Field_AddEntryToTable_Brackets){
     org.k3.lua.dynamic.Field_AddEntryToTable_BracketsAspect.execute((activitydiagram.Field_AddEntryToTable_Brackets)_self,c);
    } else  if (_self instanceof activitydiagram.Field){
     org.k3.lua.dynamic.FieldAspect._privk3_execute(_self_, (activitydiagram.Field)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final FieldAspectFieldAspectProperties _self_, final Field _self, final Environment c) {
  }
}
