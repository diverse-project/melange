package org.k3.lua.dynamic;

import activitydiagram.Field_AddEntryToTable_Brackets;
import java.util.Map;
import org.k3.lua.dynamic.Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectProperties;

@SuppressWarnings("all")
public class Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectContext {
  public final static Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectContext INSTANCE = new Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectContext();
  
  public static Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectProperties getSelf(final Field_AddEntryToTable_Brackets _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Field_AddEntryToTable_Brackets, Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Field_AddEntryToTable_Brackets, org.k3.lua.dynamic.Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectProperties>();
  
  public Map<Field_AddEntryToTable_Brackets, Field_AddEntryToTable_BracketsAspectField_AddEntryToTable_BracketsAspectProperties> getMap() {
    return map;
  }
}
