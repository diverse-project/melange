package org.k3.lua.dynamic;

import activitydiagram.Statement;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.StatementAspectStatementAspectProperties;

@Aspect(className = Statement.class)
@SuppressWarnings("all")
public class StatementAspect {
  public static void execute(final Statement _self, final Environment c) {
    org.k3.lua.dynamic.StatementAspectStatementAspectProperties _self_ = org.k3.lua.dynamic.StatementAspectStatementAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Expression_Plus){
     org.k3.lua.dynamic.Expression_PlusAspect.execute((activitydiagram.Expression_Plus)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_TableConstructor){
     org.k3.lua.dynamic.Expression_TableConstructorAspect.execute((activitydiagram.Expression_TableConstructor)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Invert){
     org.k3.lua.dynamic.Expression_InvertAspect.execute((activitydiagram.Expression_Invert)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_CallFunction){
     org.k3.lua.dynamic.Statement_CallFunctionAspect.execute((activitydiagram.Statement_CallFunction)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_False){
     org.k3.lua.dynamic.Expression_FalseAspect.execute((activitydiagram.Expression_False)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_Repeat){
     org.k3.lua.dynamic.Statement_RepeatAspect.execute((activitydiagram.Statement_Repeat)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_If_Then_Else){
     org.k3.lua.dynamic.Statement_If_Then_ElseAspect.execute((activitydiagram.Statement_If_Then_Else)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Nil){
     org.k3.lua.dynamic.Expression_NilAspect.execute((activitydiagram.Expression_Nil)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_For_Numeric){
     org.k3.lua.dynamic.Statement_For_NumericAspect.execute((activitydiagram.Statement_For_Numeric)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_And){
     org.k3.lua.dynamic.Expression_AndAspect.execute((activitydiagram.Expression_And)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_AccessArray){
     org.k3.lua.dynamic.Expression_AccessArrayAspect.execute((activitydiagram.Expression_AccessArray)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Equal){
     org.k3.lua.dynamic.Expression_EqualAspect.execute((activitydiagram.Expression_Equal)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_Block){
     org.k3.lua.dynamic.Statement_BlockAspect.execute((activitydiagram.Statement_Block)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Smaller_Equal){
     org.k3.lua.dynamic.Expression_Smaller_EqualAspect.execute((activitydiagram.Expression_Smaller_Equal)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_VariableName){
     org.k3.lua.dynamic.Expression_VariableNameAspect.execute((activitydiagram.Expression_VariableName)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Or){
     org.k3.lua.dynamic.Expression_OrAspect.execute((activitydiagram.Expression_Or)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_CallFunction){
     org.k3.lua.dynamic.Expression_CallFunctionAspect.execute((activitydiagram.Expression_CallFunction)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Larger){
     org.k3.lua.dynamic.Expression_LargerAspect.execute((activitydiagram.Expression_Larger)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Concatenation){
     org.k3.lua.dynamic.Expression_ConcatenationAspect.execute((activitydiagram.Expression_Concatenation)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_String){
     org.k3.lua.dynamic.Expression_StringAspect.execute((activitydiagram.Expression_String)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Multiplication){
     org.k3.lua.dynamic.Expression_MultiplicationAspect.execute((activitydiagram.Expression_Multiplication)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Exponentiation){
     org.k3.lua.dynamic.Expression_ExponentiationAspect.execute((activitydiagram.Expression_Exponentiation)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_AccessMember){
     org.k3.lua.dynamic.Expression_AccessMemberAspect.execute((activitydiagram.Expression_AccessMember)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Minus){
     org.k3.lua.dynamic.Expression_MinusAspect.execute((activitydiagram.Expression_Minus)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_LocalFunction_Declaration){
     org.k3.lua.dynamic.Statement_LocalFunction_DeclarationAspect.execute((activitydiagram.Statement_LocalFunction_Declaration)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_Local_Variable_Declaration){
     org.k3.lua.dynamic.Statement_Local_Variable_DeclarationAspect.execute((activitydiagram.Statement_Local_Variable_Declaration)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_Assignment){
     org.k3.lua.dynamic.Statement_AssignmentAspect.execute((activitydiagram.Statement_Assignment)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Not_Equal){
     org.k3.lua.dynamic.Expression_Not_EqualAspect.execute((activitydiagram.Expression_Not_Equal)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_GlobalFunction_Declaration){
     org.k3.lua.dynamic.Statement_GlobalFunction_DeclarationAspect.execute((activitydiagram.Statement_GlobalFunction_Declaration)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_VarArgs){
     org.k3.lua.dynamic.Expression_VarArgsAspect.execute((activitydiagram.Expression_VarArgs)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_While){
     org.k3.lua.dynamic.Statement_WhileAspect.execute((activitydiagram.Statement_While)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_True){
     org.k3.lua.dynamic.Expression_TrueAspect.execute((activitydiagram.Expression_True)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Number){
     org.k3.lua.dynamic.Expression_NumberAspect.execute((activitydiagram.Expression_Number)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Length){
     org.k3.lua.dynamic.Expression_LengthAspect.execute((activitydiagram.Expression_Length)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_CallMemberFunction){
     org.k3.lua.dynamic.Statement_CallMemberFunctionAspect.execute((activitydiagram.Statement_CallMemberFunction)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_CallMemberFunction){
     org.k3.lua.dynamic.Expression_CallMemberFunctionAspect.execute((activitydiagram.Expression_CallMemberFunction)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Division){
     org.k3.lua.dynamic.Expression_DivisionAspect.execute((activitydiagram.Expression_Division)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_For_Generic){
     org.k3.lua.dynamic.Statement_For_GenericAspect.execute((activitydiagram.Statement_For_Generic)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Modulo){
     org.k3.lua.dynamic.Expression_ModuloAspect.execute((activitydiagram.Expression_Modulo)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Larger_Equal){
     org.k3.lua.dynamic.Expression_Larger_EqualAspect.execute((activitydiagram.Expression_Larger_Equal)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Function){
     org.k3.lua.dynamic.Expression_FunctionAspect.execute((activitydiagram.Expression_Function)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Smaller){
     org.k3.lua.dynamic.Expression_SmallerAspect.execute((activitydiagram.Expression_Smaller)_self,c);
    } else  if (_self instanceof activitydiagram.Expression_Negate){
     org.k3.lua.dynamic.Expression_NegateAspect.execute((activitydiagram.Expression_Negate)_self,c);
    } else  if (_self instanceof activitydiagram.Expression){
     org.k3.lua.dynamic.ExpressionAspect.execute((activitydiagram.Expression)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_FunctioncallOrAssignment){
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect.execute((activitydiagram.Statement_FunctioncallOrAssignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect._privk3_execute(_self_, (activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final StatementAspectStatementAspectProperties _self_, final Statement _self, final Environment c) {
  }
}
