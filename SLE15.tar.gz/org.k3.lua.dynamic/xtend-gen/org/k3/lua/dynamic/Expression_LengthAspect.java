package org.k3.lua.dynamic;

import activitydiagram.Expression;
import activitydiagram.Expression_Length;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.ExpressionAspect;
import org.k3.lua.dynamic.Expression_LengthAspectExpression_LengthAspectProperties;

@Aspect(className = Expression_Length.class)
@SuppressWarnings("all")
public class Expression_LengthAspect extends ExpressionAspect {
  public static void execute(final Expression_Length _self, final Environment c) {
    org.k3.lua.dynamic.Expression_LengthAspectExpression_LengthAspectProperties _self_ = org.k3.lua.dynamic.Expression_LengthAspectExpression_LengthAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Expression_Length){
     org.k3.lua.dynamic.Expression_LengthAspect._privk3_execute(_self_, (activitydiagram.Expression_Length)_self,c);
    } else  if (_self instanceof activitydiagram.Expression){
     org.k3.lua.dynamic.ExpressionAspect.execute((activitydiagram.Expression)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_FunctioncallOrAssignment){
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect.execute((activitydiagram.Statement_FunctioncallOrAssignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect.execute((activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Expression_LengthAspectExpression_LengthAspectProperties _self_, final Expression_Length _self, final Environment c) {
    Expression _exp = _self.getExp();
    ExpressionAspect.execute(_exp, c);
    Object _pop = c.values.pop();
    String left = ((String) _pop);
    int _length = left.length();
    c.values.push(Integer.valueOf(_length));
  }
}
