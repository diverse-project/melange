package org.k3.lua.dynamic;

import activitydiagram.Expression_Modulo;
import java.util.Map;
import org.k3.lua.dynamic.Expression_ModuloAspectExpression_ModuloAspectProperties;

@SuppressWarnings("all")
public class Expression_ModuloAspectExpression_ModuloAspectContext {
  public final static Expression_ModuloAspectExpression_ModuloAspectContext INSTANCE = new Expression_ModuloAspectExpression_ModuloAspectContext();
  
  public static Expression_ModuloAspectExpression_ModuloAspectProperties getSelf(final Expression_Modulo _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_ModuloAspectExpression_ModuloAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Modulo, Expression_ModuloAspectExpression_ModuloAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Modulo, org.k3.lua.dynamic.Expression_ModuloAspectExpression_ModuloAspectProperties>();
  
  public Map<Expression_Modulo, Expression_ModuloAspectExpression_ModuloAspectProperties> getMap() {
    return map;
  }
}
