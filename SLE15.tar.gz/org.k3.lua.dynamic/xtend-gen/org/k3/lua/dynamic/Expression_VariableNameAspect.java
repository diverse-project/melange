package org.k3.lua.dynamic;

import activitydiagram.Expression_VariableName;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.ExpressionAspect;
import org.k3.lua.dynamic.Expression_VariableNameAspectExpression_VariableNameAspectProperties;

@Aspect(className = Expression_VariableName.class)
@SuppressWarnings("all")
public class Expression_VariableNameAspect extends ExpressionAspect {
  public static void execute(final Expression_VariableName _self, final Environment c) {
    org.k3.lua.dynamic.Expression_VariableNameAspectExpression_VariableNameAspectProperties _self_ = org.k3.lua.dynamic.Expression_VariableNameAspectExpression_VariableNameAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Expression_VariableName){
     org.k3.lua.dynamic.Expression_VariableNameAspect._privk3_execute(_self_, (activitydiagram.Expression_VariableName)_self,c);
    } else  if (_self instanceof activitydiagram.Expression){
     org.k3.lua.dynamic.ExpressionAspect.execute((activitydiagram.Expression)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_FunctioncallOrAssignment){
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect.execute((activitydiagram.Statement_FunctioncallOrAssignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect.execute((activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Expression_VariableNameAspectExpression_VariableNameAspectProperties _self_, final Expression_VariableName _self, final Environment c) {
    String _variable = _self.getVariable();
    Object _get = c.variables.get(_variable);
    c.values.push(_get);
  }
}
