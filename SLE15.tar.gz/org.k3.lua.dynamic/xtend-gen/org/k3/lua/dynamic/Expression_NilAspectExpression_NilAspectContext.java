package org.k3.lua.dynamic;

import activitydiagram.Expression_Nil;
import java.util.Map;
import org.k3.lua.dynamic.Expression_NilAspectExpression_NilAspectProperties;

@SuppressWarnings("all")
public class Expression_NilAspectExpression_NilAspectContext {
  public final static Expression_NilAspectExpression_NilAspectContext INSTANCE = new Expression_NilAspectExpression_NilAspectContext();
  
  public static Expression_NilAspectExpression_NilAspectProperties getSelf(final Expression_Nil _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_NilAspectExpression_NilAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Nil, Expression_NilAspectExpression_NilAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Nil, org.k3.lua.dynamic.Expression_NilAspectExpression_NilAspectProperties>();
  
  public Map<Expression_Nil, Expression_NilAspectExpression_NilAspectProperties> getMap() {
    return map;
  }
}
