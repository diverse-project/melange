package org.k3.lua.dynamic;

@SuppressWarnings("all")
public class Functioncall_ArgumentsAspectFunctioncall_ArgumentsAspectProperties {
}
