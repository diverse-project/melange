package org.k3.lua.dynamic;

import activitydiagram.Block;
import activitydiagram.Expression;
import activitydiagram.Expression_VariableName;
import activitydiagram.Function;
import activitydiagram.Functioncall_Arguments;
import activitydiagram.Statement_CallFunction;
import com.google.common.base.Objects;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import java.util.ArrayList;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.k3.lua.dynamic.BlockAspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.ExpressionAspect;
import org.k3.lua.dynamic.Statement_CallFunctionAspectStatement_CallFunctionAspectProperties;
import org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect;

@Aspect(className = Statement_CallFunction.class)
@SuppressWarnings("all")
public class Statement_CallFunctionAspect extends Statement_FunctioncallOrAssignmentAspect {
  @OverrideAspectMethod
  public static void execute(final Statement_CallFunction _self, final Environment c) {
    org.k3.lua.dynamic.Statement_CallFunctionAspectStatement_CallFunctionAspectProperties _self_ = org.k3.lua.dynamic.Statement_CallFunctionAspectStatement_CallFunctionAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Statement_CallFunction){
     org.k3.lua.dynamic.Statement_CallFunctionAspect._privk3_execute(_self_, (activitydiagram.Statement_CallFunction)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_FunctioncallOrAssignment){
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect.execute((activitydiagram.Statement_FunctioncallOrAssignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect.execute((activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  private static void super_execute(final Statement_CallFunction _self, final Environment c) {
    org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspectStatement_FunctioncallOrAssignmentAspectProperties _self_ = org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspectStatement_FunctioncallOrAssignmentAspectContext.getSelf(_self);
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect._privk3_execute(_self_, _self,c);
  }
  
  protected static void _privk3_execute(final Statement_CallFunctionAspectStatement_CallFunctionAspectProperties _self_, final Statement_CallFunction _self, final Environment c) {
    Expression x = _self.getObject();
    boolean _matched = false;
    if (!_matched) {
      if (x instanceof Expression_VariableName) {
        String _variable = ((Expression_VariableName)x).getVariable();
        boolean _equals = _variable.equals("print");
        if (_equals) {
          _matched=true;
          Functioncall_Arguments _arguments = _self.getArguments();
          EList<Expression> _arguments_1 = _arguments.getArguments();
          Expression _get = _arguments_1.get(0);
          ExpressionAspect.execute(_get, c);
          Object _pop = c.values.pop();
          InputOutput.<Object>println(_pop);
          return;
        }
      }
    }
    Expression _object = _self.getObject();
    if ((_object instanceof Expression_VariableName)) {
      Expression _object_1 = _self.getObject();
      String _variable = ((Expression_VariableName) _object_1).getVariable();
      Function function = c.functions.get(_variable);
      boolean _notEquals = (!Objects.equal(function, null));
      if (_notEquals) {
        final ArrayList<Object> params = new ArrayList<Object>();
        Functioncall_Arguments _arguments = _self.getArguments();
        EList<Expression> _arguments_1 = _arguments.getArguments();
        final Consumer<Expression> _function = (Expression args) -> {
          ExpressionAspect.execute(args, c);
          Object _pop = c.values.pop();
          params.add(_pop);
        };
        _arguments_1.forEach(_function);
        Environment newC = new Environment();
        newC.parent = c;
        newC.variables.putAll(c.variables);
        newC.functions.putAll(c.functions);
        newC.values.addAll(c.values);
        for (int i = 0; (i < function.getParameters().size()); i++) {
          EList<String> _parameters = function.getParameters();
          String _get = _parameters.get(i);
          Object _get_1 = params.get(i);
          newC.variables.put(_get, _get_1);
        }
        Block _body = function.getBody();
        BlockAspect.execute(_body, newC);
        Object _pop = newC.values.pop();
        c.values.push(_pop);
      }
    }
  }
}
