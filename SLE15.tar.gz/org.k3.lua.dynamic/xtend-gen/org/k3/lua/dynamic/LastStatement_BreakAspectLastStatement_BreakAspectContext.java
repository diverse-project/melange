package org.k3.lua.dynamic;

import activitydiagram.LastStatement_Break;
import java.util.Map;
import org.k3.lua.dynamic.LastStatement_BreakAspectLastStatement_BreakAspectProperties;

@SuppressWarnings("all")
public class LastStatement_BreakAspectLastStatement_BreakAspectContext {
  public final static LastStatement_BreakAspectLastStatement_BreakAspectContext INSTANCE = new LastStatement_BreakAspectLastStatement_BreakAspectContext();
  
  public static LastStatement_BreakAspectLastStatement_BreakAspectProperties getSelf(final LastStatement_Break _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.LastStatement_BreakAspectLastStatement_BreakAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<LastStatement_Break, LastStatement_BreakAspectLastStatement_BreakAspectProperties> map = new java.util.WeakHashMap<activitydiagram.LastStatement_Break, org.k3.lua.dynamic.LastStatement_BreakAspectLastStatement_BreakAspectProperties>();
  
  public Map<LastStatement_Break, LastStatement_BreakAspectLastStatement_BreakAspectProperties> getMap() {
    return map;
  }
}
