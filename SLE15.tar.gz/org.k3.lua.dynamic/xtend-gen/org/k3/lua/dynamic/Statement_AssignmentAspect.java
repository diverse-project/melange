package org.k3.lua.dynamic;

import activitydiagram.Expression;
import activitydiagram.Expression_VariableName;
import activitydiagram.Statement_Assignment;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.common.util.EList;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.ExpressionAspect;
import org.k3.lua.dynamic.Statement_AssignmentAspectStatement_AssignmentAspectProperties;
import org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect;

@Aspect(className = Statement_Assignment.class)
@SuppressWarnings("all")
public class Statement_AssignmentAspect extends Statement_FunctioncallOrAssignmentAspect {
  public static void execute(final Statement_Assignment _self, final Environment c) {
    org.k3.lua.dynamic.Statement_AssignmentAspectStatement_AssignmentAspectProperties _self_ = org.k3.lua.dynamic.Statement_AssignmentAspectStatement_AssignmentAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Statement_Assignment){
     org.k3.lua.dynamic.Statement_AssignmentAspect._privk3_execute(_self_, (activitydiagram.Statement_Assignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_FunctioncallOrAssignment){
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect.execute((activitydiagram.Statement_FunctioncallOrAssignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect.execute((activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Statement_AssignmentAspectStatement_AssignmentAspectProperties _self_, final Statement_Assignment _self, final Environment c) {
    EList<Expression> _variable = _self.getVariable();
    Expression _get = _variable.get(0);
    String variableName = ((Expression_VariableName) _get).getVariable();
    EList<Expression> _values = _self.getValues();
    Expression _get_1 = _values.get(0);
    ExpressionAspect.execute(_get_1, c);
    Object value = c.values.pop();
    c.variables.put(((String) variableName), value);
  }
}
