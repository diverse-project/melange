package org.k3.lua.dynamic;

import activitydiagram.LastStatement_Break;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.LastStatementAspect;

@Aspect(className = LastStatement_Break.class)
@SuppressWarnings("all")
public class LastStatement_BreakAspect extends LastStatementAspect {
}
