package org.k3.lua.dynamic;

@SuppressWarnings("all")
public class Expression_Larger_EqualAspectExpression_Larger_EqualAspectProperties {
}
