package org.k3.lua.dynamic;

import activitydiagram.Expression;
import activitydiagram.Expression_Smaller_Equal;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.ExpressionAspect;
import org.k3.lua.dynamic.Expression_Smaller_EqualAspectExpression_Smaller_EqualAspectProperties;

@Aspect(className = Expression_Smaller_Equal.class)
@SuppressWarnings("all")
public class Expression_Smaller_EqualAspect extends ExpressionAspect {
  public static void execute(final Expression_Smaller_Equal _self, final Environment c) {
    org.k3.lua.dynamic.Expression_Smaller_EqualAspectExpression_Smaller_EqualAspectProperties _self_ = org.k3.lua.dynamic.Expression_Smaller_EqualAspectExpression_Smaller_EqualAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Expression_Smaller_Equal){
     org.k3.lua.dynamic.Expression_Smaller_EqualAspect._privk3_execute(_self_, (activitydiagram.Expression_Smaller_Equal)_self,c);
    } else  if (_self instanceof activitydiagram.Expression){
     org.k3.lua.dynamic.ExpressionAspect.execute((activitydiagram.Expression)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_FunctioncallOrAssignment){
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect.execute((activitydiagram.Statement_FunctioncallOrAssignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect.execute((activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Expression_Smaller_EqualAspectExpression_Smaller_EqualAspectProperties _self_, final Expression_Smaller_Equal _self, final Environment c) {
    Expression _left = _self.getLeft();
    ExpressionAspect.execute(_left, c);
    Object _pop = c.values.pop();
    Comparable left = ((Comparable) _pop);
    Expression _right = _self.getRight();
    ExpressionAspect.execute(_right, c);
    Object _pop_1 = c.values.pop();
    Comparable right = ((Comparable) _pop_1);
    int _compareTo = left.compareTo(right);
    boolean _lessEqualsThan = (_compareTo <= 0);
    c.values.push(Boolean.valueOf(_lessEqualsThan));
  }
}
