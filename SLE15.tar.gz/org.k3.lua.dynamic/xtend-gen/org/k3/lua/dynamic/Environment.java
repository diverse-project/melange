package org.k3.lua.dynamic;

import activitydiagram.Function;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

@SuppressWarnings("all")
public class Environment {
  public Environment parent;
  
  public Stack<Object> values = new Stack<Object>();
  
  public Map<String, Object> variables = new HashMap<String, Object>();
  
  public Map<String, Function> functions = new HashMap<String, Function>();
}
