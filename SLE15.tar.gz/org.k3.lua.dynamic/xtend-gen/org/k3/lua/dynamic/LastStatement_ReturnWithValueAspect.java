package org.k3.lua.dynamic;

import activitydiagram.Expression;
import activitydiagram.LastStatement_ReturnWithValue;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.EList;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.ExpressionAspect;
import org.k3.lua.dynamic.LastStatement_ReturnAspect;
import org.k3.lua.dynamic.LastStatement_ReturnWithValueAspectLastStatement_ReturnWithValueAspectProperties;

@Aspect(className = LastStatement_ReturnWithValue.class)
@SuppressWarnings("all")
public class LastStatement_ReturnWithValueAspect extends LastStatement_ReturnAspect {
  public static void execute(final LastStatement_ReturnWithValue _self, final Environment c) {
    org.k3.lua.dynamic.LastStatement_ReturnWithValueAspectLastStatement_ReturnWithValueAspectProperties _self_ = org.k3.lua.dynamic.LastStatement_ReturnWithValueAspectLastStatement_ReturnWithValueAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.LastStatement_ReturnWithValue){
     org.k3.lua.dynamic.LastStatement_ReturnWithValueAspect._privk3_execute(_self_, (activitydiagram.LastStatement_ReturnWithValue)_self,c);
    } else  if (_self instanceof activitydiagram.LastStatement_Return){
     org.k3.lua.dynamic.LastStatement_ReturnAspect.execute((activitydiagram.LastStatement_Return)_self,c);
    } else  if (_self instanceof activitydiagram.LastStatement){
     org.k3.lua.dynamic.LastStatementAspect.execute((activitydiagram.LastStatement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final LastStatement_ReturnWithValueAspectLastStatement_ReturnWithValueAspectProperties _self_, final LastStatement_ReturnWithValue _self, final Environment c) {
    EList<Expression> _returnValues = _self.getReturnValues();
    final Consumer<Expression> _function = (Expression e) -> {
      ExpressionAspect.execute(e, c);
    };
    _returnValues.forEach(_function);
  }
}
