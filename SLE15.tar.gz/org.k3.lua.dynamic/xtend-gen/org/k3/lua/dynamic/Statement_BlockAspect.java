package org.k3.lua.dynamic;

import activitydiagram.Statement_Block;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.StatementAspect;
import org.k3.lua.dynamic.Statement_BlockAspectStatement_BlockAspectProperties;

@Aspect(className = Statement_Block.class)
@SuppressWarnings("all")
public class Statement_BlockAspect extends StatementAspect {
  public static void execute(final Statement_Block _self, final Environment c) {
    org.k3.lua.dynamic.Statement_BlockAspectStatement_BlockAspectProperties _self_ = org.k3.lua.dynamic.Statement_BlockAspectStatement_BlockAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Statement_Block){
     org.k3.lua.dynamic.Statement_BlockAspect._privk3_execute(_self_, (activitydiagram.Statement_Block)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect.execute((activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Statement_BlockAspectStatement_BlockAspectProperties _self_, final Statement_Block _self, final Environment c) {
  }
}
