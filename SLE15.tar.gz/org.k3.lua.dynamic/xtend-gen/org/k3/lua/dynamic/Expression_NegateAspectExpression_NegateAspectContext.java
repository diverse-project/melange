package org.k3.lua.dynamic;

import activitydiagram.Expression_Negate;
import java.util.Map;
import org.k3.lua.dynamic.Expression_NegateAspectExpression_NegateAspectProperties;

@SuppressWarnings("all")
public class Expression_NegateAspectExpression_NegateAspectContext {
  public final static Expression_NegateAspectExpression_NegateAspectContext INSTANCE = new Expression_NegateAspectExpression_NegateAspectContext();
  
  public static Expression_NegateAspectExpression_NegateAspectProperties getSelf(final Expression_Negate _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_NegateAspectExpression_NegateAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_Negate, Expression_NegateAspectExpression_NegateAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_Negate, org.k3.lua.dynamic.Expression_NegateAspectExpression_NegateAspectProperties>();
  
  public Map<Expression_Negate, Expression_NegateAspectExpression_NegateAspectProperties> getMap() {
    return map;
  }
}
