package org.k3.lua.dynamic;

import activitydiagram.Expression;
import activitydiagram.Expression_AccessMember;
import activitydiagram.Expression_VariableName;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import java.util.Scanner;
import org.k3.lua.dynamic.Environment;
import org.k3.lua.dynamic.ExpressionAspect;
import org.k3.lua.dynamic.Expression_AccessMemberAspectExpression_AccessMemberAspectProperties;

@Aspect(className = Expression_AccessMember.class)
@SuppressWarnings("all")
public class Expression_AccessMemberAspect extends ExpressionAspect {
  public static void execute(final Expression_AccessMember _self, final Environment c) {
    org.k3.lua.dynamic.Expression_AccessMemberAspectExpression_AccessMemberAspectProperties _self_ = org.k3.lua.dynamic.Expression_AccessMemberAspectExpression_AccessMemberAspectContext.getSelf(_self);
     if (_self instanceof activitydiagram.Expression_AccessMember){
     org.k3.lua.dynamic.Expression_AccessMemberAspect._privk3_execute(_self_, (activitydiagram.Expression_AccessMember)_self,c);
    } else  if (_self instanceof activitydiagram.Expression){
     org.k3.lua.dynamic.ExpressionAspect.execute((activitydiagram.Expression)_self,c);
    } else  if (_self instanceof activitydiagram.Statement_FunctioncallOrAssignment){
     org.k3.lua.dynamic.Statement_FunctioncallOrAssignmentAspect.execute((activitydiagram.Statement_FunctioncallOrAssignment)_self,c);
    } else  if (_self instanceof activitydiagram.Statement){
     org.k3.lua.dynamic.StatementAspect.execute((activitydiagram.Statement)_self,c);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
  }
  
  protected static void _privk3_execute(final Expression_AccessMemberAspectExpression_AccessMemberAspectProperties _self_, final Expression_AccessMember _self, final Environment c) {
    String _memberName = _self.getMemberName();
    boolean _equals = _memberName.equals("read");
    if (_equals) {
      Expression x = _self.getObject();
      boolean _matched = false;
      if (!_matched) {
        if (x instanceof Expression_VariableName) {
          String _variable = ((Expression_VariableName)x).getVariable();
          boolean _equals_1 = _variable.equals("io");
          if (_equals_1) {
            _matched=true;
            Scanner scanIn = new Scanner(System.in);
            String in = scanIn.nextLine();
            scanIn.close();
            c.values.push(in);
          }
        }
      }
    }
  }
}
