package org.k3.lua.dynamic;

import activitydiagram.Expression_VarArgs;
import java.util.Map;
import org.k3.lua.dynamic.Expression_VarArgsAspectExpression_VarArgsAspectProperties;

@SuppressWarnings("all")
public class Expression_VarArgsAspectExpression_VarArgsAspectContext {
  public final static Expression_VarArgsAspectExpression_VarArgsAspectContext INSTANCE = new Expression_VarArgsAspectExpression_VarArgsAspectContext();
  
  public static Expression_VarArgsAspectExpression_VarArgsAspectProperties getSelf(final Expression_VarArgs _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.k3.lua.dynamic.Expression_VarArgsAspectExpression_VarArgsAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Expression_VarArgs, Expression_VarArgsAspectExpression_VarArgsAspectProperties> map = new java.util.WeakHashMap<activitydiagram.Expression_VarArgs, org.k3.lua.dynamic.Expression_VarArgsAspectExpression_VarArgsAspectProperties>();
  
  public Map<Expression_VarArgs, Expression_VarArgsAspectExpression_VarArgsAspectProperties> getMap() {
    return map;
  }
}
