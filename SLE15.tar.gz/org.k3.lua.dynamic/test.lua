print("Hello World")

  defines a factorial function
     function fact (n)
      if n == 0 then
         return 1
       else
         return n * fact(n-1)
      end
     end
    function toto (n)
      return 1 + n
    end
    
    print("enter a number:")
    a = io.read("*number")        -- read a number
    b = a + 1
    print(b)
    a = 1 <= 2
    print(a)
    print(toto(2))
    print(fact(b))
    
