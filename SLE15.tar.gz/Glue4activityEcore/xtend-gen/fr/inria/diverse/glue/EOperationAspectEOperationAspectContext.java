package fr.inria.diverse.glue;

import activitydiagram.EOperation;
import fr.inria.diverse.glue.EOperationAspectEOperationAspectProperties;
import java.util.Map;

@SuppressWarnings("all")
public class EOperationAspectEOperationAspectContext {
  public final static EOperationAspectEOperationAspectContext INSTANCE = new EOperationAspectEOperationAspectContext();
  
  public static EOperationAspectEOperationAspectProperties getSelf(final EOperation _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new fr.inria.diverse.glue.EOperationAspectEOperationAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<EOperation, EOperationAspectEOperationAspectProperties> map = new java.util.WeakHashMap<activitydiagram.EOperation, fr.inria.diverse.glue.EOperationAspectEOperationAspectProperties>();
  
  public Map<EOperation, EOperationAspectEOperationAspectProperties> getMap() {
    return map;
  }
}
