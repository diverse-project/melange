package fr.inria.diverse.glue;

import activitydiagram.Activity;
import activitydiagram.EOperation;
import fr.inria.diverse.glue.EOperationAspectEOperationAspectProperties;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;

@Aspect(className = EOperation.class)
@SuppressWarnings("all")
public class EOperationAspect {
  public static Activity behavior(final EOperation _self) {
    fr.inria.diverse.glue.EOperationAspectEOperationAspectProperties _self_ = fr.inria.diverse.glue.EOperationAspectEOperationAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_behavior(_self_, _self);
    return (activitydiagram.Activity)result;
  }
  
  public static void behavior(final EOperation _self, final Activity behavior) {
    fr.inria.diverse.glue.EOperationAspectEOperationAspectProperties _self_ = fr.inria.diverse.glue.EOperationAspectEOperationAspectContext.getSelf(_self);
    _privk3_behavior(_self_, _self,behavior);
  }
  
  protected static Activity _privk3_behavior(final EOperationAspectEOperationAspectProperties _self_, final EOperation _self) {
     return _self_.behavior; 
  }
  
  protected static void _privk3_behavior(final EOperationAspectEOperationAspectProperties _self_, final EOperation _self, final Activity behavior) {
    _self_.behavior = behavior; try {
    
    			for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    				if (m.getName().equals("set" + "Behavior")
    						&& m.getParameterTypes().length == 1) {
    					m.invoke(_self, behavior);
    
    				}
    			}
    		} catch (Exception e) {
    			// Chut !
    		} 
  }
}
