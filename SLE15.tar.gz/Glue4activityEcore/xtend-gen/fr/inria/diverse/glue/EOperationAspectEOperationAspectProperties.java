package fr.inria.diverse.glue;

import activitydiagram.Activity;

@SuppressWarnings("all")
public class EOperationAspectEOperationAspectProperties {
  public Activity behavior;
}
