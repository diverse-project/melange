package fr.inria.diverse.glue;

import activitydiagram.Block;

@SuppressWarnings("all")
public class ExpressionAspectExpressionAspectProperties {
  public Block lua;
}
