package fr.inria.diverse.glue;

import activitydiagram.Block;
import activitydiagram.Expression;
import fr.inria.diverse.glue.ExpressionAspectExpressionAspectProperties;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;

@Aspect(className = Expression.class)
@SuppressWarnings("all")
public class ExpressionAspect {
  public static Block lua(final Expression _self) {
    fr.inria.diverse.glue.ExpressionAspectExpressionAspectProperties _self_ = fr.inria.diverse.glue.ExpressionAspectExpressionAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_lua(_self_, _self);
    return (activitydiagram.Block)result;
  }
  
  public static void lua(final Expression _self, final Block lua) {
    fr.inria.diverse.glue.ExpressionAspectExpressionAspectProperties _self_ = fr.inria.diverse.glue.ExpressionAspectExpressionAspectContext.getSelf(_self);
    _privk3_lua(_self_, _self,lua);
  }
  
  protected static Block _privk3_lua(final ExpressionAspectExpressionAspectProperties _self_, final Expression _self) {
     return _self_.lua; 
  }
  
  protected static void _privk3_lua(final ExpressionAspectExpressionAspectProperties _self_, final Expression _self, final Block lua) {
    _self_.lua = lua; try {
    
    			for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    				if (m.getName().equals("set" + "Lua")
    						&& m.getParameterTypes().length == 1) {
    					m.invoke(_self, lua);
    
    				}
    			}
    		} catch (Exception e) {
    			// Chut !
    		} 
  }
}
