/**
 */
package activitydiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Last Statement Break</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see activitydiagram.ActivitydiagramPackage#getLastStatement_Break()
 * @model
 * @generated
 */
public interface LastStatement_Break extends LastStatement {
} // LastStatement_Break
